﻿Imports System.Data.OleDb

Public Class frmtest
    Dim registerno As Byte

    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click

        If con.State = ConnectionState.Closed Then
            con.Open()

        End If

        Dim examlogincm1 As New OleDbCommand("select * from examid", con)
        Dim examlogindr1 As OleDbDataReader
        examlogindr1 = examlogincm1.ExecuteReader
        While examlogindr1.Read

            If txtexamid.Text = examlogindr1.Item(0) And txtpassword.Text = examlogindr1.Item(1) Then
                registerno = examlogindr1.Item(2)
                gbexamlogin.Visible = False
                txtexamid.Clear()
                txtpassword.Clear()
                panmcq.Visible = True
                panmcq.Top = 30

                Call questionpaper()
                Exit While
            End If

        End While


        con.Close()
    End Sub


    Public Sub questionpaper()
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim paperid22 As Byte
        Dim examid22 As Byte
        Dim examidcm22 As New OleDbCommand("select examid from studentregi where registerno=" & registerno, con)
        Dim examiddr22 As OleDbDataReader
        examiddr22 = examidcm22.ExecuteReader
        While examiddr22.Read
            examid22 = examiddr22.Item(0)

        End While



        Dim paperidcm1 As New OleDbCommand("select TOP 1  *from exampaper where examid=" & examid22 & " ORDER BY RND(paperid)", con)
        Dim paperiddr1 As OleDbDataReader

        paperiddr1 = paperidcm1.ExecuteReader

        While paperiddr1.Read
            paperid22 = paperiddr1.Item(0)

        End While
        con.Close()
        MsgBox(paperid22)

    End Sub

End Class