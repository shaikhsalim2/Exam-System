﻿Imports System.Data.OleDb
Public Class truefalse
    Public bookid As Integer


    Dim truefalseda As New OleDbDataAdapter("select *from truefalse", con) 'define the truefalseda command

    Private Sub truefalse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

     
            truefalseda.MissingSchemaAction = MissingSchemaAction.AddWithKey
            truefalseda.Fill(ds, "truefalse")
            cmb = New OleDbCommandBuilder(truefalseda)
            n = ds.Tables("truefalse").Rows.Count - 1
            Call daa(n) 'call a daa()

            'open the connection
            con.Open()

            Call subjectid()

            Call questioncategory()


            btnsave.Enabled = False

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try


       
    End Sub
    Public Sub daa(ByVal tru1 As Byte) 'main function daa establish
        Try


            With ds.Tables("truefalse").Rows(tru1)
                txtquestionid.Text = .Item(0)
                cmbsubjectid.Text = .Item(1)
                txtquestion.Text = .Item(2)
                cmbans.Text = .Item(3)
                cmbquestioncategory.Text = .Item(4)


            End With

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub subjectid()
        Try

      
            Dim truefalsecm As New OleDbCommand("select * from bookmaster", con)
            Dim trufalsedr As OleDbDataReader
            trufalsedr = truefalsecm.ExecuteReader
            While trufalsedr.Read
                cmbsubjectid.Items.Add(trufalsedr.Item(1))

            End While
            'close the detareader dr
            trufalsedr.Close()

            'close the connection
            con.Close()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub
    Public Sub questioncategory()

        Try


            con.Open() 'open the connection
            Dim questioncatdr1 As OleDbDataReader 'establish the datareder
            Dim questioncatcm1 As New OleDbCommand("select questioncat from questioncategory", con)
            questioncatdr1 = questioncatcm1.ExecuteReader
            While questioncatdr1.Read
                cmbquestioncategory.Items.Add(questioncatdr1.Item(0))

            End While
            questioncatdr1.Close() 'close a datareder
            con.Close() 'close a connection
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Public Sub datagrid()
        'display selected subjectid  related question in datagridview
        Try

       
            Dim truefalsecm3 As New OleDbCommand("select *from truefalse where subjectid=" & bookid, con)
            Dim truefalsedr3 As OleDbDataReader
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            truefalsedr3 = truefalsecm3.ExecuteReader
            While truefalsedr3.Read
                dgtruefalse.Rows.Add(truefalsedr3.Item(0), truefalsedr3.Item(1), truefalsedr3.Item(2), truefalsedr3.Item(3))

            End While
            truefalsedr3.Close() 'close the datareasder
            con.Close() 'close the connection
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub subjectid2()
        Try

      
            con.Open() 'connection open
            'accssing the subject id 
            Dim truefalsecm2 As New OleDbCommand("select  bookid from bookmaster where bookname like '" & Trim(cmbsubjectid.Text) & "'", con)
            Dim truefalsedr2 As OleDbDataReader
            truefalsedr2 = truefalsecm2.ExecuteReader
            While truefalsedr2.Read 'datareader read
                bookid = truefalsedr2.Item(0) 'store subject id into subid

            End While
            con.Close() 'close the connection
            truefalsedr2.Close() 'close the datareader
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub Btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

      
          
            If txtquestion.Text = "" & questionid = 0 & bookid = 0 Then

                btnsave.Enabled = False
            Else
                btnsave.Enabled = True

            End If



            Dim r As DataRow
            r = ds.Tables("truefalse").NewRow
            r.Item(0) = txtquestionid.Text
            r.Item(1) = bookid
            r.Item(2) = txtquestion.Text
            r.Item(3) = cmbans.Text
            r.Item(4) = questionid
            ds.Tables("truefalse").Rows.Add(r)
            truefalseda.Update(ds, "truefalse")
            MsgBox("record save")
            dgtruefalse.Update()


        Catch ex As IndexOutOfRangeException

            MsgBox("ok")
        Catch ex1 As ConstraintException
            MsgBox("dublicate id")

        Catch ex3 As Exception
            MsgBox(ex3)

        End Try


    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

      

            If con.State = ConnectionState.Closed Then
                con.Open()
            End If

            Dim truefalsecm1 As New OleDbCommand("select questionid from teurfalse", con)
            Dim truefalseda1 As OleDbDataReader
            truefalseda1 = truefalsecm1.ExecuteReader
            While truefalseda1.Read
                txtquestionid.Text = truefalseda1.Item(0) + 1

            End While

            con.Close()

            txtquestion.Clear()
            cmbans.SelectedIndex = 0
        Catch ex As Exception
            MsgBox(ex)
        End Try

    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try


            Dim a As Byte
            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configuration")

            If a = 1 Then
                ds.Tables("truefalse").Rows(n).Delete()

                truefalseda.Update(ds, "truefalse")
                MsgBox("delete row")
                n = 1
                dgtruefalse.Update()

                Call daa(n)

            Else
                Call daa(n)


            End If


        Catch ex As Exception
            MsgBox(ex)

        End Try
    End Sub

    Private Sub cmbsubjectid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbsubjectid.KeyPress
        MsgBox("donot enter only select")
    End Sub

    Private Sub cmbsubjectid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbsubjectid.SelectedIndexChanged
        Call subjectid2()
        dgtruefalse.Rows.Clear()
        Call datagrid()

       
    End Sub


    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

      
            ds.Tables("truefalse").Rows(n).Item(1) = bookid
            ds.Tables("truefalse").Rows(n).Item(2) = txtquestion.Text
            ds.Tables("truefalse").Rows(n).Item(3) = cmbans.Text
            ds.Tables("truefalse").Rows(n).Item(4) = questionid
            truefalseda.Update(ds, "truefalse")
            dgtruefalse.Update()

            MsgBox("updated ")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

       
            If n < ds.Tables("truefalse").Rows.Count - 1 Then
                n = n + 1
                Call daa(n)
            Else
                MsgBox("last record")
            End If

        Catch ex As Exception
            MsgBox(ex)

        End Try
    End Sub

    Private Sub btnprivios_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprivios.Click
        Try

      
            If n > 0 Then
                n = n - 1
                Call daa(n)
            Else
                MsgBox("first record")


            End If

        Catch ex As Exception
            MsgBox(ex)
        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click



        Dim eno2 As Integer
        eno2 = InputBox("enter quesionid")



        Try
            dgtruefalse.Rows.Clear()

            Dim truefalsecm3 As New OleDbCommand("select *from truefalse where id=" & eno2, con)
            Dim truefalsedr3 As OleDbDataReader
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            truefalsedr3 = truefalsecm3.ExecuteReader
            While truefalsedr3.Read
                dgtruefalse.Rows.Add(truefalsedr3.Item(0), truefalsedr3.Item(1), truefalsedr3.Item(2), truefalsedr3.Item(3))

            End While
            truefalsedr3.Close() 'close the datareasder
            con.Close() 'close the connection
           

        Catch ex As InvalidCastException
            MsgBox("enter only number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex2 As OverflowException
            MsgBox("sorry your no is high")

      
        End Try
    End Sub

    Private Sub dgtruefalse_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgtruefalse.CellContentClick
        Dim r As Integer
        r = dgtruefalse.CurrentRow.Index
        txtquestionid.Text = dgtruefalse.Item(0, r).Value
        cmbsubjectid.Text = dgtruefalse.Item(1, r).Value
        txtquestion.Text = dgtruefalse.Item(2, r).Value
        cmbans.Text = dgtruefalse.Item(3, r).Value


    End Sub

    Private Sub cmbans_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbans.KeyPress
        MsgBox("donot enter plese only select")

    End Sub

    Private Sub cmbans_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbans.SelectedIndexChanged
        btnsave.Enabled = True
    End Sub

    Private Sub cmbquestioncategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbquestioncategory.SelectedIndexChanged
        Try

       
            'retrive the questioncategory id
            con.Open() 'open the connection
            Dim questioncategorycm2 As New OleDbCommand("select questionid from questioncategory where questioncat like'" & Trim(cmbquestioncategory.Text) & "'", con)
            Dim questioncategorydr2 As OleDbDataReader
            questioncategorydr2 = questioncategorycm2.ExecuteReader
            While questioncategorydr2.Read
                questionid = questioncategorydr2.Item(0)


            End While
            con.Close()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        Try

        
            n = 0
            Call daa(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        Try

       
            n = ds.Tables("truefalse").Rows.Count - 1
            Call daa(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub
End Class