﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class compatativeexammatser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnadd = New System.Windows.Forms.Button
        Me.dgcexamaster = New System.Windows.Forms.DataGridView
        Me.txtcexamid = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtcexamname = New System.Windows.Forms.TextBox
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnupdate = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnsearch = New System.Windows.Forms.Button
        Me.btnnext = New System.Windows.Forms.Button
        Me.btnprevious = New System.Windows.Forms.Button
        Me.dgsearch = New System.Windows.Forms.DataGridView
        Me.examid = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.examname = New System.Windows.Forms.DataGridViewTextBoxColumn
        CType(Me.dgcexamaster, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgsearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(12, 235)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 23)
        Me.btnadd.TabIndex = 3
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'dgcexamaster
        '
        Me.dgcexamaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgcexamaster.Location = New System.Drawing.Point(385, 2)
        Me.dgcexamaster.Name = "dgcexamaster"
        Me.dgcexamaster.Size = New System.Drawing.Size(313, 325)
        Me.dgcexamaster.TabIndex = 1
        '
        'txtcexamid
        '
        Me.txtcexamid.Location = New System.Drawing.Point(112, 12)
        Me.txtcexamid.Name = "txtcexamid"
        Me.txtcexamid.Size = New System.Drawing.Size(100, 20)
        Me.txtcexamid.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Cexamid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Cexamname"
        '
        'txtcexamname
        '
        Me.txtcexamname.Location = New System.Drawing.Point(112, 60)
        Me.txtcexamname.Name = "txtcexamname"
        Me.txtcexamname.Size = New System.Drawing.Size(100, 20)
        Me.txtcexamname.TabIndex = 2
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(137, 235)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 4
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(284, 235)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 23)
        Me.btnupdate.TabIndex = 5
        Me.btnupdate.Text = "Update"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btndelete
        '
        Me.btndelete.Location = New System.Drawing.Point(12, 304)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(75, 23)
        Me.btndelete.TabIndex = 6
        Me.btndelete.Text = "Delete"
        Me.btndelete.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(137, 304)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(75, 23)
        Me.btnsearch.TabIndex = 7
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'btnnext
        '
        Me.btnnext.Location = New System.Drawing.Point(284, 304)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(75, 23)
        Me.btnnext.TabIndex = 8
        Me.btnnext.Text = "Next"
        Me.btnnext.UseVisualStyleBackColor = True
        '
        'btnprevious
        '
        Me.btnprevious.Location = New System.Drawing.Point(12, 350)
        Me.btnprevious.Name = "btnprevious"
        Me.btnprevious.Size = New System.Drawing.Size(75, 23)
        Me.btnprevious.TabIndex = 9
        Me.btnprevious.Text = "Previous"
        Me.btnprevious.UseVisualStyleBackColor = True
        '
        'dgsearch
        '
        Me.dgsearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgsearch.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.examid, Me.examname})
        Me.dgsearch.Location = New System.Drawing.Point(25, 119)
        Me.dgsearch.Name = "dgsearch"
        Me.dgsearch.Size = New System.Drawing.Size(249, 115)
        Me.dgsearch.TabIndex = 10
        '
        'examid
        '
        Me.examid.HeaderText = "examid"
        Me.examid.Name = "examid"
        Me.examid.ReadOnly = True
        '
        'examname
        '
        Me.examname.HeaderText = "examname"
        Me.examname.Name = "examname"
        Me.examname.ReadOnly = True
        '
        'compatativeexammatser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(727, 394)
        Me.Controls.Add(Me.dgsearch)
        Me.Controls.Add(Me.btnprevious)
        Me.Controls.Add(Me.btnnext)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.txtcexamname)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtcexamid)
        Me.Controls.Add(Me.dgcexamaster)
        Me.Controls.Add(Me.btnadd)
        Me.Name = "compatativeexammatser"
        Me.Text = "compatativeexammatser"
        CType(Me.dgcexamaster, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgsearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents dgcexamaster As System.Windows.Forms.DataGridView
    Friend WithEvents txtcexamid As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtcexamname As System.Windows.Forms.TextBox
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents btnnext As System.Windows.Forms.Button
    Friend WithEvents btnprevious As System.Windows.Forms.Button
    Friend WithEvents dgsearch As System.Windows.Forms.DataGridView
    Friend WithEvents examid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents examname As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
