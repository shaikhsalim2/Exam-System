﻿Public Class masterpage

    Private Sub MCQToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MCQToolStripMenuItem.Click
        mcq.Show()
        n = 0
        Call mcq.dataa(n)

    End Sub

    Private Sub FillingTheBlankToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FillingTheBlankToolStripMenuItem.Click
        fbq.Show()
        n = 0
        Call fbq.fbqtt(n)
    End Sub

    Private Sub TrueFalseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrueFalseToolStripMenuItem.Click
        truefalse.Show()
        n = 0
        Call truefalse.daa(n)
    End Sub

    Private Sub SubjectMasterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubjectMasterToolStripMenuItem.Click
        bookmaster.Show()
       
    End Sub

    Private Sub ExamMasterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExamMasterToolStripMenuItem.Click
        compatativeexammatser.Show()
        n = 0
        Call compatativeexammatser.cexam(n)

    End Sub

    Private Sub PublicatioToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PublicatioToolStripMenuItem.Click
        publisher.Show()
        n = 0
        Call publisher.publication(n)

    End Sub

    Private Sub UseraddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UseraddToolStripMenuItem.Click
        frmuseradd.Show()
       
    End Sub

    Private Sub SIgnOUTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIgnOUTToolStripMenuItem.Click
        frmlogin.Show()

    End Sub

    Private Sub QuestionCategoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuestionCategoryToolStripMenuItem.Click
        question_chategory.Show()
       
    End Sub

    Private Sub RegistretionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegistretionToolStripMenuItem.Click
        registration.Show()
      

    End Sub

    Private Sub TalukaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TalukaToolStripMenuItem.Click
        taluka.Show()

    End Sub

    Private Sub DIstToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DIstToolStripMenuItem.Click
        frmdist.Show()

    End Sub

    
    Private Sub PacticleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PacticleToolStripMenuItem.Click
        practical.Show()

    End Sub

    Private Sub SetAPapersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetAPapersToolStripMenuItem.Click
        frmsetpaper.show()

    End Sub
End Class