﻿Imports System.Data.OleDb
Module Module1
    Public con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\28-12-2017\System exam\exam.accdb")
    Public cmb As OleDbCommandBuilder
    Public ds As New DataSet
    Public n As Byte
    Public a As Byte
    Public dr As OleDbDataReader
    Public questionid As Byte

   
  
End Module
