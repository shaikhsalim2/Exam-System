﻿Imports System.Data.OleDb

Public Class frmdist
    Dim da As New OleDbDataAdapter("select *from dist", con)

  

    Private Sub frmdist_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            pandist.Enabled = False
       
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "dist")
            dgdist.DataSource = ds.Tables("dist")
            cmb = New OleDbCommandBuilder(da)
            Call dist(n)
            txtdistid.Enabled = False

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Private Sub dist(ByVal d1 As Byte)
        Try

       
            With ds.Tables("dist").Rows(d1)
                txtdistid.Text = .Item(0)
                txtdistname.Text = .Item(1)

            End With


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

       
            If n < ds.Tables("dist").Rows.Count - 1 Then
                n = n + 1
                Call dist(n)
            End If


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            pandist.Enabled = True
            Dim eno As New Integer

            eno = InputBox("enter the questionid ")
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim distcm4 As New OleDbCommand("select *from dist where distid=" & eno, con)
            Dim distdr4 As OleDbDataReader
            distdr4 = distcm4.ExecuteReader
            While distdr4.Read
                dgsearch.Rows.Add(distdr4.Item(0), distdr4.Item(1))

            End While
            con.Close()

        Catch ex As InvalidCastException


            MsgBox("enter the number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        Try

      
            n = 0
            Call dist(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

    
            Dim r As DataRow
            r = ds.Tables("dist").NewRow
            r.Item(0) = txtdistid.Text
            r.Item(1) = txtdistname.Text
            ds.Tables("dist").Rows.Add(r)
            da.Update(ds, "dist")
            MsgBox("record save")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim distcm3 As New OleDbCommand("select *from dist", con)
            Dim distdr3 As OleDbDataReader
            distdr3 = distcm3.ExecuteReader
            While distdr3.Read
                txtdistid.Text = distdr3.Item(0) + 1

            End While
            con.Close()
            txtdistname.Clear()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try

    
            Dim t4 As Integer
            t4 = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure")
            If t4 = 1 Then
                ds.Tables("dist").Rows(n).Delete()
                da.Update(ds, "dist")
                MsgBox("record delete")

            Else
                MsgBox("ok")

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        Try

       
            n = ds.Tables("dist").Rows.Count - 1
            Call dist(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

      
            ds.Tables("dist").Rows(n).Item(1) = txtdistname.Text
            da.Update(ds, "dist")
            MsgBox("record updated")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click
        Try

      
            If n > 0 Then


                n = n - 1
                Call dist(n)
            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgsearch.CellContentClick

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub
End Class