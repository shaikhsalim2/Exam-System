﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmtest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtexamid = New System.Windows.Forms.TextBox
        Me.txtpassword = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.gbexamlogin = New System.Windows.Forms.GroupBox
        Me.btncancel = New System.Windows.Forms.Button
        Me.btnlogin = New System.Windows.Forms.Button
        Me.panmcq = New System.Windows.Forms.Panel
        Me.lblquestionid = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.rb4 = New System.Windows.Forms.RadioButton
        Me.rb3 = New System.Windows.Forms.RadioButton
        Me.rb2 = New System.Windows.Forms.RadioButton
        Me.rb1 = New System.Windows.Forms.RadioButton
        Me.lblquestion = New System.Windows.Forms.Label
        Me.Panexamcontrol = New System.Windows.Forms.Panel
        Me.lblanswer = New System.Windows.Forms.Label
        Me.btnsubmmit = New System.Windows.Forms.Button
        Me.btnpexamrevious = New System.Windows.Forms.Button
        Me.btncancel1 = New System.Windows.Forms.Button
        Me.btnexamnext = New System.Windows.Forms.Button
        Me.gbexamlogin.SuspendLayout()
        Me.panmcq.SuspendLayout()
        Me.Panexamcontrol.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtexamid
        '
        Me.txtexamid.Location = New System.Drawing.Point(121, 19)
        Me.txtexamid.Name = "txtexamid"
        Me.txtexamid.Size = New System.Drawing.Size(166, 20)
        Me.txtexamid.TabIndex = 1
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(121, 59)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(166, 20)
        Me.txtpassword.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(30, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Examid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Exam password"
        '
        'gbexamlogin
        '
        Me.gbexamlogin.Controls.Add(Me.btncancel)
        Me.gbexamlogin.Controls.Add(Me.btnlogin)
        Me.gbexamlogin.Controls.Add(Me.txtexamid)
        Me.gbexamlogin.Controls.Add(Me.Label2)
        Me.gbexamlogin.Controls.Add(Me.txtpassword)
        Me.gbexamlogin.Controls.Add(Me.Label1)
        Me.gbexamlogin.Location = New System.Drawing.Point(147, 12)
        Me.gbexamlogin.Name = "gbexamlogin"
        Me.gbexamlogin.Size = New System.Drawing.Size(355, 133)
        Me.gbexamlogin.TabIndex = 5
        Me.gbexamlogin.TabStop = False
        Me.gbexamlogin.Text = "login"
        '
        'btncancel
        '
        Me.btncancel.Location = New System.Drawing.Point(222, 110)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(75, 23)
        Me.btncancel.TabIndex = 7
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btnlogin
        '
        Me.btnlogin.Location = New System.Drawing.Point(36, 104)
        Me.btnlogin.Name = "btnlogin"
        Me.btnlogin.Size = New System.Drawing.Size(75, 23)
        Me.btnlogin.TabIndex = 6
        Me.btnlogin.Text = "Login"
        Me.btnlogin.UseVisualStyleBackColor = True
        '
        'panmcq
        '
        Me.panmcq.Controls.Add(Me.lblquestionid)
        Me.panmcq.Controls.Add(Me.btncancel1)
        Me.panmcq.Controls.Add(Me.btnsubmmit)
        Me.panmcq.Controls.Add(Me.Label4)
        Me.panmcq.Controls.Add(Me.btnpexamrevious)
        Me.panmcq.Controls.Add(Me.btnexamnext)
        Me.panmcq.Controls.Add(Me.rb4)
        Me.panmcq.Controls.Add(Me.rb3)
        Me.panmcq.Controls.Add(Me.rb2)
        Me.panmcq.Controls.Add(Me.rb1)
        Me.panmcq.Controls.Add(Me.lblquestion)
        Me.panmcq.Location = New System.Drawing.Point(12, 176)
        Me.panmcq.Name = "panmcq"
        Me.panmcq.Size = New System.Drawing.Size(882, 247)
        Me.panmcq.TabIndex = 6
        '
        'lblquestionid
        '
        Me.lblquestionid.AutoSize = True
        Me.lblquestionid.Location = New System.Drawing.Point(35, 48)
        Me.lblquestionid.Name = "lblquestionid"
        Me.lblquestionid.Size = New System.Drawing.Size(39, 13)
        Me.lblquestionid.TabIndex = 14
        Me.lblquestionid.Text = "Label4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(9, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(161, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Solve the Question"
        '
        'rb4
        '
        Me.rb4.AutoSize = True
        Me.rb4.Location = New System.Drawing.Point(80, 175)
        Me.rb4.Name = "rb4"
        Me.rb4.Size = New System.Drawing.Size(90, 17)
        Me.rb4.TabIndex = 4
        Me.rb4.TabStop = True
        Me.rb4.Text = "RadioButton4"
        Me.rb4.UseVisualStyleBackColor = True
        '
        'rb3
        '
        Me.rb3.AutoSize = True
        Me.rb3.Location = New System.Drawing.Point(80, 141)
        Me.rb3.Name = "rb3"
        Me.rb3.Size = New System.Drawing.Size(90, 17)
        Me.rb3.TabIndex = 3
        Me.rb3.TabStop = True
        Me.rb3.Text = "RadioButton3"
        Me.rb3.UseVisualStyleBackColor = True
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.Location = New System.Drawing.Point(80, 114)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(90, 17)
        Me.rb2.TabIndex = 2
        Me.rb2.TabStop = True
        Me.rb2.Text = "RadioButton2"
        Me.rb2.UseVisualStyleBackColor = True
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.Location = New System.Drawing.Point(80, 91)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(90, 17)
        Me.rb1.TabIndex = 1
        Me.rb1.TabStop = True
        Me.rb1.Text = "RadioButton1"
        Me.rb1.UseVisualStyleBackColor = True
        '
        'lblquestion
        '
        Me.lblquestion.AutoSize = True
        Me.lblquestion.Location = New System.Drawing.Point(89, 48)
        Me.lblquestion.Name = "lblquestion"
        Me.lblquestion.Size = New System.Drawing.Size(39, 13)
        Me.lblquestion.TabIndex = 0
        Me.lblquestion.Text = "Label4"
        '
        'Panexamcontrol
        '
        Me.Panexamcontrol.Controls.Add(Me.lblanswer)
        Me.Panexamcontrol.Location = New System.Drawing.Point(12, 429)
        Me.Panexamcontrol.Name = "Panexamcontrol"
        Me.Panexamcontrol.Size = New System.Drawing.Size(882, 39)
        Me.Panexamcontrol.TabIndex = 16
        '
        'lblanswer
        '
        Me.lblanswer.AutoSize = True
        Me.lblanswer.Location = New System.Drawing.Point(900, 0)
        Me.lblanswer.Name = "lblanswer"
        Me.lblanswer.Size = New System.Drawing.Size(39, 13)
        Me.lblanswer.TabIndex = 14
        Me.lblanswer.Text = "Label7"
        '
        'btnsubmmit
        '
        Me.btnsubmmit.Location = New System.Drawing.Point(564, 221)
        Me.btnsubmmit.Name = "btnsubmmit"
        Me.btnsubmmit.Size = New System.Drawing.Size(75, 23)
        Me.btnsubmmit.TabIndex = 13
        Me.btnsubmmit.Text = "Submit"
        Me.btnsubmmit.UseVisualStyleBackColor = True
        '
        'btnpexamrevious
        '
        Me.btnpexamrevious.Location = New System.Drawing.Point(135, 221)
        Me.btnpexamrevious.Name = "btnpexamrevious"
        Me.btnpexamrevious.Size = New System.Drawing.Size(75, 23)
        Me.btnpexamrevious.TabIndex = 6
        Me.btnpexamrevious.Text = "<"
        Me.btnpexamrevious.UseVisualStyleBackColor = True
        '
        'btncancel1
        '
        Me.btncancel1.Location = New System.Drawing.Point(751, 221)
        Me.btncancel1.Name = "btncancel1"
        Me.btncancel1.Size = New System.Drawing.Size(75, 23)
        Me.btncancel1.TabIndex = 12
        Me.btncancel1.Text = "Cancel"
        Me.btncancel1.UseVisualStyleBackColor = True
        '
        'btnexamnext
        '
        Me.btnexamnext.Location = New System.Drawing.Point(357, 221)
        Me.btnexamnext.Name = "btnexamnext"
        Me.btnexamnext.Size = New System.Drawing.Size(75, 23)
        Me.btnexamnext.TabIndex = 7
        Me.btnexamnext.Text = ">"
        Me.btnexamnext.UseVisualStyleBackColor = True
        '
        'frmtest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(906, 480)
        Me.Controls.Add(Me.Panexamcontrol)
        Me.Controls.Add(Me.panmcq)
        Me.Controls.Add(Me.gbexamlogin)
        Me.Name = "frmtest"
        Me.Text = "frmtest"
        Me.gbexamlogin.ResumeLayout(False)
        Me.gbexamlogin.PerformLayout()
        Me.panmcq.ResumeLayout(False)
        Me.panmcq.PerformLayout()
        Me.Panexamcontrol.ResumeLayout(False)
        Me.Panexamcontrol.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txtexamid As System.Windows.Forms.TextBox
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents gbexamlogin As System.Windows.Forms.GroupBox
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnlogin As System.Windows.Forms.Button
    Friend WithEvents panmcq As System.Windows.Forms.Panel
    Friend WithEvents lblquestionid As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents rb4 As System.Windows.Forms.RadioButton
    Friend WithEvents rb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents lblquestion As System.Windows.Forms.Label
    Friend WithEvents Panexamcontrol As System.Windows.Forms.Panel
    Friend WithEvents lblanswer As System.Windows.Forms.Label
    Friend WithEvents btnsubmmit As System.Windows.Forms.Button
    Friend WithEvents btnpexamrevious As System.Windows.Forms.Button
    Friend WithEvents btncancel1 As System.Windows.Forms.Button
    Friend WithEvents btnexamnext As System.Windows.Forms.Button
End Class
