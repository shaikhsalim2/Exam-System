﻿Imports System.Data.OleDb
Public Class fbq
    Dim bookid As Integer



    Dim da As New OleDbDataAdapter("select *from fbqt", con)

    Private Sub fbq_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

       
            ds.Clear() 'clear the dataset
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey

            da.Fill(ds, "fbqt")
            cmb = New OleDbCommandBuilder(da)



            n = ds.Tables("fbqt").Rows.Count - 1

            Call fbqtt(n) 'caling the main function fbqt

            Call subjectid() 'caling the subjectid retrive the  subject name in cmbsubjectid

            Call questioncategory() 'caling the questioncategory retrive the questincat

            btnsave.Enabled = False

            txtquestionid.Enabled = False


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
       
    End Sub
    Public Sub fbqtt(ByVal fb1 As Byte)
        Try

       
            With ds.Tables("fbqt").Rows(fb1)


                txtquestionid.Text = .Item(0)
                con.Open()


                cmbsubjectid.Text = .Item(1)




                con.Close()



                txtquestion.Text = .Item(2)
                txtanswer.Text = .Item(3)
                cmbquestioncategory.Text = .Item(4)


            End With


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub questioncategory()
        Try

       
            con.Open()
            Dim questioncatdr1 As OleDbDataReader
            Dim questioncatcm1 As New OleDbCommand("select questioncat from questioncategory", con)
            questioncatdr1 = questioncatcm1.ExecuteReader
            While questioncatdr1.Read
                cmbquestioncategory.Items.Add(questioncatdr1.Item(0))

            End While
            questioncatdr1.Close()
            con.Close()


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub subjectid()
        Try

       
            con.Open()
            Dim fbqcm As New OleDbCommand("select * from bookmaster", con)
            Dim fbqdr As OleDbDataReader
            fbqdr = fbqcm.ExecuteReader
            While fbqdr.Read
                cmbsubjectid.Items.Add(fbqdr.Item(1))

            End While
            con.Close()

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub subjectid2()
        Try

       
            con.Open()
            Dim fbqcm2 As New OleDbCommand("select  bookid from bookmaster where bookname like '" & Trim(cmbsubjectid.Text) & "'", con)
            Dim fbqdr2 As OleDbDataReader
            fbqdr2 = fbqcm2.ExecuteReader
            While fbqdr2.Read
                bookid = fbqdr2.Item(0)

            End While

            con.Close()

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub
    Public Sub datagrid()
        Try

      
            dgfbq.Rows.Clear()


            Dim fbqcm3 As New OleDbCommand("select *from fbqt where subjectid=" & bookid, con)
            Dim fbqdr3 As OleDbDataReader
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If

            fbqdr3 = fbqcm3.ExecuteReader
            While fbqdr3.Read
                dgfbq.Rows.Add(fbqdr3.Item(0), fbqdr3.Item(1), fbqdr3.Item(2), fbqdr3.Item(3))

            End While
            fbqdr3.Close()

            con.Close()

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub cmbsubjectid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbsubjectid.KeyPress
        MsgBox("donot enter plese only select")
    End Sub

    Private Sub cmbsubjectid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbsubjectid.SelectedIndexChanged
        Call subjectid2()
        Call datagrid()

      
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

       
            txtquestionid.Text = ds.Tables("fbqt").Rows.Count + 1
            txtquestion.Clear()
            txtanswer.Clear()
            cmbsubjectid.SelectedIndex = 0
        Catch ex As Exception
            MsgBox(ex)
        End Try


    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If txtquestion.Text.Trim <> "" Then
            'not empty
       


            Try



                Dim r As DataRow
                r = ds.Tables("fbqt").NewRow
                r.Item(0) = txtquestionid.Text
                r.Item(1) = bookid
                r.Item(2) = txtquestion.Text
                r.Item(3) = txtanswer.Text
                r.Item(4) = questionid
                ds.Tables("fbqt").Rows.Add(r)
                da.Update(ds, "fbqt")
                dgfbq.Update()

                MsgBox("save")


            Catch ex As IndexOutOfRangeException
                MsgBox("ok")
            Catch ex As ConstraintException
                MsgBox("not allowed dublicate value this id allredy present")

            Catch ex As Exception
                MsgBox(Convert.ToString(ex))
            End Try
        End If


    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try

       
            a = 0
            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "ok")
            If a = 1 Then
                ds.Tables("fbqt").Rows(n).Delete()
                da.Update(ds, "fbqt")
                MsgBox("delete")
                dgfbq.Update()

            Else
                MsgBox("ok")

            End If


        Catch ex As RowNotInTableException
            MsgBox("row not found")


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

      
            If n < ds.Tables("fbqt").Rows.Count - 1 Then
                n = n + 1
                Call fbqtt(n)
            Else
                MsgBox("first record")


            End If
        Catch ex As Exception
            MsgBox(ex)

        End Try
    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click
        Try

       
            If n > 0 Then
                n = n - 1
                Call fbqtt(n)
            Else
                MsgBox("first record")

            End If

        Catch ex As Exception
            MsgBox(ex)

        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try

       
            dgfbq.Rows.Clear()

            Dim eno2 As Integer
            eno2 = InputBox("enter the questionid")
            Dim fbqcm3 As New OleDbCommand("select *from fbqt where questionid=" & eno2, con)
            Dim fbqdr3 As OleDbDataReader
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If

            fbqdr3 = fbqcm3.ExecuteReader
            While fbqdr3.Read
                dgfbq.Rows.Add(fbqdr3.Item(0), fbqdr3.Item(1), fbqdr3.Item(2), fbqdr3.Item(3))

            End While
            fbqdr3.Close()

            con.Close()

        Catch ex As InvalidCastException


            MsgBox("enter the number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgfbq.CellContentClick
        Try

            Dim r As Integer
            r = dgfbq.CurrentRow.Index
            txtquestionid.Text = dgfbq.Item(0, r).Value
            cmbsubjectid.Text = dgfbq.Item(1, r).Value
            txtquestion.Text = dgfbq.Item(2, r).Value
            txtanswer.Text = dgfbq.Item(3, r).Value


        Catch ex As Exception
            MsgBox(ex)

        End Try


    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

     
            ds.Tables("fbqt").Rows(n).Item(1) = bookid
            ds.Tables("fbqt").Rows(n).Item(2) = txtquestion.Text
            ds.Tables("fbqt").Rows(n).Item(3) = txtanswer.Text
            ds.Tables("fbqt").Rows(n).Item(4) = questionid
            dgfbq.Update()

            da.Update(ds, "fbqt")
            MsgBox("record update")
        Catch ex As Exception
            MsgBox(ex)

        End Try
    End Sub

    Private Sub txtanswer_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtanswer.KeyPress


    End Sub

    Private Sub txtanswer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtanswer.TextChanged
        If txtquestion.Text.Trim <> "" Then
            'not empty
        End If

        btnsave.Enabled = True

    End Sub

    Private Sub cmbquestioncategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbquestioncategory.SelectedIndexChanged
        con.Open()
        Dim questioncategorycm2 As New OleDbCommand("select questionid from questioncategory where questioncat like'" & Trim(cmbquestioncategory.Text) & "'", con)
        Dim questioncategorydr2 As OleDbDataReader
        questioncategorydr2 = questioncategorycm2.ExecuteReader
        While questioncategorydr2.Read
            questionid = questioncategorydr2.Item(0)


        End While
        con.Close()

    End Sub

    Private Sub txtquestion_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtquestion.TextChanged

    End Sub
End Class