﻿Imports System.Data.OleDb

Public Class compatativeexammatser
    Dim da As New OleDb.OleDbDataAdapter("select *from cexammaster", con)

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click

        Try

            dgsearch.Rows.Clear()



            Dim eno2 As Integer

            eno2 = InputBox("enter the examid")
            Dim cexcm3 As New OleDbCommand("select * from cexammaster where examid =" & eno2, con)
            Dim cexdr3 As OleDbDataReader
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If


            cexdr3 = cexcm3.ExecuteReader
            While cexdr3.Read
                dgsearch.Rows.Add(cexdr3.Item(0), cexdr3.Item(1))

            End While
            cexdr3.Close()
            con.Close()

        Catch ex As InvalidCastException


            MsgBox("enter the number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))

        End Try

    End Sub

    Private Sub compatativeexammatser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

       
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey

            da.Fill(ds, "cexammaster")
            cmb = New OleDb.OleDbCommandBuilder(da)
            n = ds.Tables("cexammaster").Rows.Count - 1

            Call cexam(n)
            dgcexamaster.DataSource = ds.Tables("cexammaster")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Public Sub cexam(ByVal c As Byte)
        Try

      
            With ds.Tables("cexammaster").Rows(c)
                txtcexamid.Text = .Item(0)
                txtcexamname.Text = .Item(1)

            End With

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim cexamcm As New OleDbCommand("select examid from cexammaster", con)
            Dim cexamda As OleDbDataReader
            cexamda = cexamcm.ExecuteReader
            While cexamda.Read
                txtcexamid.Text = cexamda.Item(0) + 1

            End While
            txtcexamname.Clear()
            btnsave.Enabled = False
            con.Close()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try


            Dim r As DataRow
            If txtcexamname.Text = "" Then
                btnsave.Enabled = False
            Else
                btnsave.Enabled = True

            End If

            r = ds.Tables("cexammaster").NewRow

            r.Item(0) = Val(txtcexamid.Text)
            r.Item(1) = txtcexamname.Text
            ds.Tables("cexammaster").Rows.Add(r)
            da.Update(ds, "cexammaster")
            MsgBox("record save")
            n = Val(txtcexamid.Text)
            dgcexamaster.Update()

            Call cexam(n)




        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

       
            Dim e1 As Short
            e1 = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure")

            txtcexamid.Enabled = False
            If e1 = 1 Then


                ds.Tables("cexammaster").Rows(n).Item(1) = txtcexamname.Text
                dgcexamaster.Update()

            Else
                MsgBox("ok")

            End If



        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try


            a = 0
            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "ok")
            If a = 1 Then
                ds.Tables("cexammaster").Rows(n).Delete()
                da.Update(ds, "cexammaster")
                MsgBox("delete")
                dgcexamaster.Update()

                Call cexam(n - 2)


            Else
                MsgBox("ok")
                Call cexam(n)



            End If

        Catch ex As RowNotInTableException
            MsgBox("record not found")


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

      
            If n < ds.Tables("cexammaster").Rows.Count - 1 Then
                n = n + 1
                Call cexam(n)
            Else

                MsgBox("last record")


            End If


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click
        Try

       
            If n > 0 Then
                n = n - 1
                Call cexam(n)
            Else
                MsgBox("first record")
            End If

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub txtcexamname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtcexamname.KeyPress
        btnsave.Enabled = True

    End Sub

    Private Sub txtcexamname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcexamname.TextChanged

    End Sub
End Class