﻿Imports System.Data.OleDb

Public Class practical
    Dim cmblevels As Integer
    Dim countrow As Integer
    Dim examid As Integer
    Dim bookid As Integer
    Dim mcq1 As Integer
    Dim exammcq1 As Integer
    Dim fbq1 As Integer
    Dim examfbq1 As Integer
    Dim type As Integer
    Dim truefalse1 As Integer
    Dim examtruefalse1 As Integer
    Dim checkopetion As String
    Dim questioncatid As Byte
    Dim t1 As Byte
    Dim range As Byte
    Dim d As New Byte
    Dim j, p As Byte
    Dim row1 As Byte














    Private Sub rb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2.CheckedChanged

    End Sub

    Private Sub practical_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblcoosequestiontype.Visible = False
        cmblavel.Visible = False

        lbllevel.Visible = False


        lblquestionid.Visible = False


        lblanswer.Visible = False

        Panexamcontrol.Visible = False

        Call examname()
        btnstart.Enabled = False

        lblinformation.Visible = False

        panpassword.Visible = False
        panmcq.Visible = False
        Panpractcontrol.Visible = False

        cmbbook.Enabled = False
        cmbquestioncat.Enabled = False

        txtcorrectanswer.Visible = False

        btnstartexam.Visible = False
        t1 = 0

        d = 3


    End Sub



    Private Sub panchecked_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles panchecked.Paint


    End Sub

    Private Sub rbmcq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbmcq.CheckedChanged

    End Sub

    Private Sub rbmcq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbmcq.Click
        If rbmcq.Checked Then
            type = 1

        End If
        panselect.Visible = True



    End Sub

    Private Sub rbfbq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbfbq.CheckedChanged

    End Sub

    Private Sub rbfbq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbfbq.Click
        If rbfbq.Checked Then
            type = 2

        End If

        panselect.Visible = True


    End Sub

    Private Sub rbtruefalse_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtruefalse.CheckedChanged



    End Sub

    Private Sub cmbcexamname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcexamname.SelectedIndexChanged
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmbbook.Items.Clear()
            'retrive examid in cmbexam matser using 

            Dim practicalexamcm2 As New OleDbCommand("select  examid from cexammaster where examname like '" & Trim(cmbcexamname.Text) & "'", con)
            Dim practicalexamdr2 As OleDbDataReader
            practicalexamdr2 = practicalexamcm2.ExecuteReader
            While practicalexamdr2.Read
                examid = practicalexamdr2.Item(0)
                MsgBox(examid)
            End While

            'retrive book name related to exam name
            Dim practicalbookcm As New OleDbCommand("select bookname from bookmaster where examid=" & examid, con)
            Dim practicalbookdr As OleDbDataReader
            practicalbookdr = practicalbookcm.ExecuteReader
            While practicalbookdr.Read
                cmbbook.Items.Add(practicalbookdr.Item(0))

            End While
            cmbbook.Enabled = True

            con.Close()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub
    Public Sub examname()
        Try

            If con.State = ConnectionState.Closed Then   'retrive exam name in exammaster
                con.Open()

            End If
            Dim subjectexamidcm As New OleDbCommand("select examname from cexammaster", con)
            Dim subjectexamdr As OleDbDataReader
            subjectexamdr = subjectexamidcm.ExecuteReader
            While subjectexamdr.Read
                cmbcexamname.Items.Add(subjectexamdr.Item(0))

            End While
            con.Close() 'connection close

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub cmbbook_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbbook.Move

    End Sub



    Private Sub cmbbook_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbbook.SelectedIndexChanged
        Try


            cmbquestioncat.Items.Clear()


            If con.State = ConnectionState.Closed Then
                con.Open()                                  'retrive bookid in selecte cmbbook name
            End If
            Dim practicalbookcm3 As New OleDbCommand("select  bookid from bookmaster where bookname like '" & Trim(cmbbook.Text) & "'", con)
            Dim practicalbookdr3 As OleDbDataReader
            practicalbookdr3 = practicalbookcm3.ExecuteReader
            While practicalbookdr3.Read
                bookid = practicalbookdr3.Item(0)


            End While
            con.Close()


            If rbmcq.Checked Then


                If con.State = ConnectionState.Closed Then      'add item in cmbquestioncategory using bookid
                    con.Open()

                End If
                Dim practicalquestioncatcm As New OleDbCommand("select   questioncat from questioncategory where questionid IN (select distinct(question_cat_id) from mcq where subjectid=" & bookid & ")", con)
                Dim practicalquestioncatdr As OleDbDataReader
                practicalquestioncatdr = practicalquestioncatcm.ExecuteReader()
                While practicalquestioncatdr.Read
                    cmbquestioncat.Items.Add(practicalquestioncatdr.Item(0))

                End While
                con.Close()

            ElseIf rbfbq.Checked Then
                If con.State = ConnectionState.Closed Then 'add item in cmbquestioncategory using bookid
                    con.Open()
                End If
                Dim practicalquestioncatcm2 As New OleDbCommand("select questioncat from questioncategory where questionid IN(select  distinct( question_cat_id ) from fbqt where subjectid=" & bookid & ")", con)
                Dim practicalquestioncatdr2 As OleDbDataReader
                practicalquestioncatdr2 = practicalquestioncatcm2.ExecuteReader()
                While practicalquestioncatdr2.Read
                    cmbquestioncat.Items.Add(practicalquestioncatdr2.Item(0))

                End While
                con.Close()


            ElseIf rbtruefalse.Checked Then
                If con.State = ConnectionState.Closed Then       'add item in cmbquestioncategory using bookid
                    con.Open()
                End If
                Dim practicalquestioncatcm3 As New OleDbCommand("select questioncat from questioncategory where questionid IN(select  distinct( question_cat_id ) from truefalse where subjectid=" & bookid & ")", con)
                Dim practicalquestioncatdr3 As OleDbDataReader
                practicalquestioncatdr3 = practicalquestioncatcm3.ExecuteReader()
                While practicalquestioncatdr3.Read
                    cmbquestioncat.Items.Add(practicalquestioncatdr3.Item(0))

                End While
                con.Close()
            End If
            cmbquestioncat.Enabled = True


        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub panmcq_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles panmcq.Paint

    End Sub

    Private Sub btnstart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstart.Click



        Try

            'retrive question usin bookid aand question category



            If type = 1 Then

                Call mcqquestion()

            ElseIf type = 2 Then

                Call fbqquestion()



            ElseIf type = 3 Then

                Call truefalsequestion()

            End If

        Catch ex As OutOfMemoryException
            MsgBox("sorrry")
        Catch ex1 As IndexOutOfRangeException
            MsgBox("information not available")

        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))

        End Try
        'visisble and unvisible controls related to question
        panmcq.Visible = True
        panchecked.Visible = False
        Panpractcontrol.Visible = True
        If type = 1 Then
            'disable oprtion button
            rb1.Visible = True
            rb2.Visible = True
            rb3.Visible = True
            rb4.Visible = True
            txtfillanswer.Visible = False

        ElseIf type = 2 Then
            'disable oprtion button
            rb1.Visible = False
            rb2.Visible = False
            rb3.Visible = False
            rb4.Visible = False
            txtfillanswer.Visible = True


        ElseIf type = 3 Then

            rb1.Visible = True
            rb2.Visible = True
            rb3.Visible = False
            rb4.Visible = False
            txtfillanswer.Visible = False

        End If



        'paninformation show

        panselect.Visible = False
        lblinformation.Top = 0

        lblinformation.Visible = True
        panmcq.Visible = True
        panmcq.Top = 30

    End Sub
    Public Sub mcqquestion()

        If type = 1 Then
            Dim mcqda As New OleDbDataAdapter("select *from mcq where subjectid=" & bookid & "and question_cat_id=" & questioncatid, con)
            mcqda.Fill(ds, "mcq")
            cmb = New OleDbCommandBuilder(mcqda)


            mcqda.MissingSchemaAction = MissingSchemaAction.AddWithKey

            mcq1 = 0
            Call mcqpractical(mcq1)
        End If
    End Sub
    Public Sub exammcqquestion()

        ds.Clear()

        If type = 1 Then

            Dim exammcqda As New OleDbDataAdapter("select *from mcq where subjectid=" & bookid & "and question_cat_id=" & questioncatid, con)
            exammcqda.Fill(ds, "mcq")
            cmb = New OleDbCommandBuilder(exammcqda)


            exammcqda.MissingSchemaAction = MissingSchemaAction.AddWithKey
            countrow = ds.Tables("mcq").Rows.Count


            cmblavel.Items.Clear()


            While countrow > 0
                d = countrow / 3
                While d > 0
                    cmblavel.Items.Add("lavel" & cmblavel.Items.Count.ToString)

                    d = d - 1
                    countrow = 0
                End While

            End While

            exammcq1 = 0

        End If
    End Sub
    Public Sub examfbqquestion()
        ds.Clear()
        If type = 2 Then


            Dim fbqtda As New OleDbDataAdapter("select *from fbqt where subjectid =" & bookid & "and question_cat_id=" & questioncatid, con)
            fbqtda.Fill(ds, "fbqt")
            cmb = New OleDbCommandBuilder(fbqtda)

            fbqtda.MissingSchemaAction = MissingSchemaAction.AddWithKey
            countrow = ds.Tables("fbqt").Rows.Count

            While countrow > 0
                d = countrow / 3
                While d > 0
                    cmblavel.Items.Add("lavel" & cmblavel.Items.Count.ToString)

                    d = d - 1
                    countrow = 0
                End While

            End While
            examfbq1 = 0
        End If
    End Sub
    Public Sub examtruefalsequestion()
        ds.Clear()
        If type = 3 Then


            Dim truefalseda As New OleDbDataAdapter("select *from truefalse where subjectid=" & bookid & "and question_cat_id=" & questioncatid, con)
            truefalseda.Fill(ds, "truefalse")
            cmb = New OleDbCommandBuilder(truefalseda)
            truefalseda.MissingSchemaAction = MissingSchemaAction.AddWithKey
            countrow = ds.Tables("truefalse").Rows.Count
            While countrow > 0
                d = countrow / 3
                While d > 0
                    cmblavel.Items.Add("lavel" & cmblavel.Items.Count.ToString)

                    d = d - 1
                    countrow = 0
                End While

            End While
            examtruefalse1 = 0
        End If
    End Sub
    Public Sub fbqquestion()
        Dim fbqtda As New OleDbDataAdapter("select *from fbqt where subjectid =" & bookid & "and question_cat_id=" & questioncatid, con)
        fbqtda.Fill(ds, "fbqt")
        cmb = New OleDbCommandBuilder(fbqtda)

        fbqtda.MissingSchemaAction = MissingSchemaAction.AddWithKey
        fbq1 = 0

        Call fbqtpractical(fbq1)

    End Sub
    Public Sub truefalsequestion()
        Dim truefalseda As New OleDbDataAdapter("select *from truefalse where subjectid=" & bookid & " and question_cat_id=" & questioncatid, con)
        truefalseda.Fill(ds, "truefalse")
        cmb = New OleDbCommandBuilder(truefalseda)
        truefalseda.MissingSchemaAction = MissingSchemaAction.AddWithKey
        truefalse1 = 0
        Call truefalsepractical(truefalse1)
    End Sub

    Private Sub mcqpractical(ByVal a As Byte)


        Try


            With ds.Tables("mcq").Rows(a)
                lblquestionid.Text = .Item(0)
                lblquestion.Text = .Item(2)
                rb1.Text = .Item(3)
                rb2.Text = .Item(4)
                rb3.Text = .Item(5)
                rb4.Text = .Item(6)
                txtcorrectanswer.Text = .Item(7)

            End With
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub
    Private Sub fbqtpractical(ByVal b As Byte)
        Try


            With ds.Tables("fbqt").Rows(b)
                lblquestionid.Text = .Item(0)
                lblquestion.Text = .Item(2)
                txtcorrectanswer.Text = .Item(3)

            End With

        Catch ex As IndexOutOfRangeException
            MsgBox("record not find")

        End Try
    End Sub
    Private Sub truefalsepractical(ByVal c As Byte)
        Try


            With ds.Tables("truefalse").Rows(c)
                lblquestionid.Text = .Item(0)
                lblquestion.Text = .Item(2)
                txtcorrectanswer.Text = .Item(3)

            End With

        Catch ex As IndexOutOfRangeException
            MsgBox("record not find")

        End Try
    End Sub









    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        txtcorrectanswer.Visible = False
        Try


            If type = 1 Then
                mcq1 = 0
                Call mcqpractical(mcq1)

            ElseIf type = 2 Then
                fbq1 = 0
                Call fbqtpractical(fbq1)
                txtfillanswer.Clear()
            ElseIf type = 3 Then
                truefalse1 = 0
                Call truefalsepractical(truefalse1)

            End If

        Catch ex As NullReferenceException
            MsgBox("you don not select any book or questioncategory")

        Catch ex1 As Exception
            MsgBox(Convert.ToString(ex1))

        End Try

    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click
        txtcorrectanswer.Visible = False
        Try

            If type = 1 Then
                If mcq1 > 0 Then
                    mcq1 = mcq1 - 1
                    Call mcqpractical(mcq1)
                Else
                    MsgBox("first question")
                End If



            ElseIf type = 2 Then
                If fbq1 > 0 Then
                    fbq1 = fbq1 - 1
                    Call fbqtpractical(fbq1)
                    txtfillanswer.Clear()
                Else
                    MsgBox("first record")
                End If

            ElseIf type = 3 Then
                If truefalse1 > 0 Then

                    truefalse1 = truefalse1 - 1
                    Call truefalsepractical(truefalse1)
                Else
                    MsgBox("first record")
                End If
            End If
        Catch ex2 As NullReferenceException
            MsgBox("you don not select any book or questioncategory")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click

        txtcorrectanswer.Visible = False
        Try


            If type = 1 Then
                If mcq1 < ds.Tables("mcq").Rows.Count - 1 Then
                    mcq1 = mcq1 + 1
                    Call mcqpractical(mcq1)
                Else
                    MsgBox("last question")

                End If


            ElseIf type = 2 Then
                If fbq1 < ds.Tables("fbqt").Rows.Count - 1 Then
                    fbq1 = fbq1 + 1
                    Call fbqtpractical(fbq1)
                    txtfillanswer.Clear()
                Else
                    MsgBox("last question")

                End If

            ElseIf type = 3 Then
                If truefalse1 < ds.Tables("truefalse").Rows.Count - 1 Then
                    truefalse1 = truefalse1 + 1
                    Call truefalsepractical(truefalse1)

                Else
                    MsgBox("last question")

                End If

            End If
        Catch ex2 As NullReferenceException
            MsgBox("you don not select any book or questioncategory")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        txtcorrectanswer.Visible = False
        Try




            If type = 1 Then
                mcq1 = ds.Tables("mcq").Rows.Count - 1

                Call mcqpractical(mcq1)
                MsgBox("laste question")
            ElseIf type = 2 Then
                fbq1 = ds.Tables("fbqt").Rows.Count - 1
                Call fbqtpractical(fbq1)
                txtfillanswer.Clear()
                MsgBox("laste question")
            ElseIf type = 3 Then
                truefalse1 = ds.Tables("fbqt").Rows.Count - 1
                Call truefalsepractical(truefalse1)

                MsgBox("laste question")
            End If
        Catch ex2 As NullReferenceException
            MsgBox("you don not select any book or questioncategory")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub rb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1.CheckedChanged

    End Sub

    Private Sub rb1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb1.Click
        If rb1.Checked Then

        End If
    End Sub

    Private Sub rb2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb2.Click

    End Sub

    Private Sub rb3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb3.CheckedChanged

    End Sub


    Private Sub rb4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb4.Click

    End Sub

    Private Sub rb3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb3.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try


            If type = 1 Then
                'check the answer is correct or not
                If rb1.Checked Then


                    If txtcorrectanswer.Text = rb1.Text Then
                        MsgBox("answer is correct")
                    Else
                        MsgBox("sorry not correct")
                    End If
                End If

                If rb2.Checked Then


                    If rb2.Text = txtcorrectanswer.Text Then
                        MsgBox("answer is correct")
                    Else
                        MsgBox("sorry not correct")
                    End If

                End If

                If rb3.Checked Then


                    If rb3.Text = txtcorrectanswer.Text Then
                        MsgBox("answer is correct")
                    Else
                        MsgBox("sorry not correct")
                    End If

                End If

                If rb4.Checked Then


                    If rb4.Text = txtcorrectanswer.Text Then
                        MsgBox("answer is correct")
                    Else
                        MsgBox("sorry not correct")
                    End If
                End If

            ElseIf type = 2 Then
                If txtfillanswer.Text = txtcorrectanswer.Text Then

                    MsgBox("answer is correct")
                Else
                    MsgBox("sorry not correct")

                End If



            ElseIf type = 3 Then
                If rb1.Checked Then
                    If rb1.Text = txtcorrectanswer.Text Then


                        MsgBox("answer is correct")
                    Else
                        MsgBox("answer is not correct")

                    End If

                End If


                If rb2.Checked Then
                    If rb2.Text = txtcorrectanswer.Text Then


                        MsgBox("answer is correct")
                    Else
                        MsgBox("answer is not correct")

                    End If
                End If
            End If

        Catch ex2 As NullReferenceException
            MsgBox("you don not select any book or questioncategory")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MsgBox(txtcorrectanswer.Text)
    End Sub

    Private Sub btncamcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncamcel.Click
        Try


            If type = 1 Then
                ds.Tables("mcq").Rows.Clear()  'cancel row in dataset

            ElseIf type = 2 Then
                ds.Tables("fbqt").Rows.Clear() 'cancel row in dataset

            ElseIf type = 3 Then
                ds.Tables("truefalse").Rows.Clear()  'cancel row in dataset

            End If


        Catch ex As NullReferenceException
            MsgBox("no information present")
        Catch ex1 As Exception
            MsgBox(Convert.ToString(ex1))


        End Try

        'disable and undisable

        panchecked.Visible = True
        panselect.Visible = False
        panmcq.Visible = False

    End Sub

    Private Sub cmbquestioncat_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbquestioncat.Resize

    End Sub

    Private Sub cmbquestioncat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbquestioncat.SelectedIndexChanged
        cmblavel.Items.Clear()

        btnstart.Enabled = True
        'retrive question id from question category table

        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim questioncatcm As New OleDbCommand("select questionid from questioncategory where questioncat like '" & Trim(cmbquestioncat.Text) & "'", con)
        Dim questioncatdr As OleDbDataReader
        questioncatdr = questioncatcm.ExecuteReader
        While questioncatdr.Read
            questioncatid = questioncatdr.Item(0)

        End While
        con.Close()
        If type = 1 Then

            Call exammcqquestion()

        ElseIf type = 2 Then
            Call examfbqquestion()
        ElseIf type = 3 Then
            Call examtruefalsequestion()


        End If
        p = 0
        j = 0

    End Sub

    Private Sub rbtruefalse_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtruefalse.Click
        If rbtruefalse.Checked Then
            type = 3


        End If

        rb1.Text = True
        rb2.Text = False
        panselect.Visible = True

    End Sub

    Private Sub panselect_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles panselect.Paint

    End Sub

    Private Sub btnstart_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnstart.Validated

    End Sub

    Private Sub btnstart_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles btnstart.Validating




    End Sub

    Private Sub cmbquestioncat_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbquestioncat.Validated


    End Sub

    Private Sub cmbbook_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbbook.Validated


    End Sub

    Private Sub rb4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb4.CheckedChanged

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        lblinformation.Left += 22



    End Sub

    Private Sub lblinformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblinformation.Click

    End Sub

    Private Sub btntest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntest.Click
        panpassword.Visible = True
        panchecked.Visible = False
        panselect.Visible = False
        btntest.Visible = False
    End Sub


    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click


        'login code
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If

        Dim logincm1 As New OleDbCommand("select *from login", con)
        Dim logindr1 As OleDbDataReader
        logindr1 = logincm1.ExecuteReader

        While logindr1.Read


            If logindr1.Item(0) = txtusername.Text And logindr1.Item(1) = txtpassword.Text Then
                btnstartexam.Visible = True
                lblcoosequestiontype.Visible = True
                panpassword.Visible = False
                panchecked.Visible = True
                btnstart.Visible = False
                cmblavel.Visible = True
                lbllevel.Visible = True

            End If
        End While
        con.Close()
        'closing the connection

    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        panpassword.Visible = False
        MsgBox("ok go to practical question")
        panchecked.Visible = True
        panselect.Visible = True
        btntest.Visible = True
    End Sub

    Private Sub btncancel_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncancel.Validated

    End Sub

    Private Sub btnstartexam_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartexam.Click

        p = 3
        j = 0

        Dim ds23 As New DataSet

        If type = 1 Then
          
            cmblevels = cmblavel.Items.Count
            Dim i As Byte
            i = 0
            exammcq1 = 0
            While i <= cmblevels
                If cmblavel.SelectedIndex = i Then
                    Exit While
                End If
                i = i + 1

            End While
            MsgBox(i)
            While i <= cmblevels
                exammcq1 = i * 3
                Exit While

            End While

            Call exammcqnext()


        ElseIf type = 2 Then

            cmblevels = cmblavel.Items.Count
            Dim i As Byte
            i = 0
            examfbq1 = 0
            While i <= cmblevels
                If cmblavel.SelectedIndex = i Then
                    Exit While
                End If
                i = i + 1

            End While
            MsgBox(i)
            While i <= cmblevels
                examfbq1 = i * 3
                Exit While

            End While

            Call examfbqtnext()
        ElseIf type = 3 Then
            j = 0
            cmblevels = cmblavel.Items.Count
            Dim i As Byte
            i = 0
            examtruefalse1 = 0
            While i <= cmblevels
                If cmblavel.SelectedIndex = i Then
                    Exit While
                End If
                i = i + 1

            End While
            MsgBox(i)
            While i <= cmblevels
                examtruefalse1 = i * 3
                Exit While

            End While
            Call examtruefalsenext()


        End If



        btncancel1.Enabled = True



        Panexamcontrol.Visible = True

        panmcq.Visible = True
       


        Panpractcontrol.Visible = False
        Panexamcontrol.Visible = True
        If type = 1 Then
            'disable oprtion button
            rb1.Visible = True
            rb2.Visible = True
            rb3.Visible = True
            rb4.Visible = True
            txtfillanswer.Visible = False

        ElseIf type = 2 Then
            'disable oprtion button
            rb1.Visible = False
            rb2.Visible = False
            rb3.Visible = False
            rb4.Visible = False
            txtfillanswer.Visible = True


        ElseIf type = 3 Then

            rb1.Visible = True
            rb2.Visible = True
            rb3.Visible = False
            rb4.Visible = False
            txtfillanswer.Visible = False

        End If
        panchecked.Visible = False
        panselect.Visible = False
        panmcq.Top = 30
        'Created a table runtime

        Panexamcontrol.Visible = True

        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
       
        Try

line:

            Dim ctcm As New OleDbCommand("CREATE TABLE practicleexam (questionid INTEGER primary key, [currectAnswer] varchar,[submitanswer] varchar)", con)

            ctcm.ExecuteNonQuery()


            con.Close()

        Catch ex As OleDbException
            Dim ans As Byte

            ans = MsgBox("first record delete or not", MsgBoxStyle.OkOnly + MsgBoxStyle.DefaultButton1 + MsgBoxStyle.Critical, "ok")
            If ans = 1 Then
                frmresult.DataGridView1.Rows.Clear()

                frmresult.DataGridView1.Update()


                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                Dim ctcm1 As New OleDbCommand(" delete *from practicleexam", con)
                ctcm1.ExecuteNonQuery()
                Dim decm As New OleDbCommand("drop table practicleexam", con)
                decm.ExecuteNonQuery()

                GoTo line


            Else


            End If

        End Try

    End Sub



























































































































































































































    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        MsgBox("are you sure ")

    End Sub

    Private Sub btnexamfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)




       
        

    End Sub

    Private Sub btnpexamrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpexamrevious.Click

        If type = 1 Then

          

            If p < 3 Then
                If exammcq1 >= 0 Then
                    exammcq1 = exammcq1 - 1
                    Call mcqpractical(exammcq1)
                    p = p + 1
                    If j > 0 Then
                        j = j - 1
                    End If
                Else
                    MsgBox("record finish")
                End If


            Else
                MsgBox("first question")
            End If

           




        ElseIf type = 2 Then
          
           
            If p < 3 Then
                If examfbq1 >= 0 Then
                    examfbq1 = examfbq1 - 1
                    Call fbqtpractical(examfbq1)
                    p = p + 1
                    If j > 0 Then
                        j = j - 1
                    End If
                Else
                    MsgBox("record finish")
                End If


            Else
                MsgBox("first question")
            End If

           
        ElseIf type = 3 Then
           
            If p < 3 Then
                If examtruefalse1 >= 0 Then
                    examtruefalse1 = examtruefalse1 - 1
                    Call truefalsepractical(examtruefalse1)
                    p = p + 1
                    If j > 0 Then
                        j = j - 1
                    End If
                Else
                    MsgBox("record finish")
                End If


            Else
                MsgBox("first question")
            End If

        End If

    End Sub
    Public Sub exammcqnext()


        If exammcq1 < ds.Tables("mcq").Rows.Count - 1 Then

            Call mcqpractical(exammcq1)
            exammcq1 = exammcq1 + 1
        Else
            MsgBox("last question")

        End If

    End Sub
    Public Sub examfbqtnext()
        If examfbq1 < ds.Tables("fbqt").Rows.Count - 1 Then

            Call fbqtpractical(examfbq1)
            examfbq1 = examfbq1 + 1
        Else
            MsgBox("last question")

        End If
    End Sub
    Public Sub examtruefalsenext()
        If examtruefalse1 < ds.Tables("truefalse").Rows.Count - 1 Then
            Call truefalsepractical(examtruefalse1)
            examtruefalse1 = examtruefalse1 + 1
        Else
            MsgBox("last question")

        End If
    End Sub

    Private Sub btnexamnext_Click() Handles btnexamnext.Click


        If type = 1 Then


            j = j + 1

            If p > 0 Then
                p = p - 1
                If j <= 2 Then
                    Call exammcqnext()
                Else
                    MsgBox("please select new lavel")
                    row1 = 5
                End If
            Else
                MsgBox("last record")

            End If




        ElseIf type = 2 Then
            j = j + 1

            If p > 0 Then
                p = p - 1
                If j <= 2 Then
                    Call examfbqtnext()
                Else
                    MsgBox("please select new lavel")
                    row1 = 5
                End If
            Else
                MsgBox("last record")

            End If



        ElseIf type = 3 Then
            j = j + 1

            If p > 0 Then
                p = p - 1
                If j <= 2 Then
                    Call examtruefalsenext()
                Else
                    MsgBox("please select new lavel")
                    row1 = 5

                End If
            Else
                MsgBox("last record")

            End If
        End If

    End Sub

    Private Sub btnexamlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)




      
    End Sub

    Private Sub cmblavel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmblavel.SelectedIndexChanged
       


    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel1.Click


        frmresult.DataGridView1.Rows.Clear()

        frmresult.DataGridView1.Update()

        Try

      
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim ctcm1 As New OleDbCommand(" delete *from practicleexam", con)
            ctcm1.ExecuteNonQuery()
            Dim decm As New OleDbCommand("drop table practicleexam", con)
            decm.ExecuteNonQuery()
            MsgBox("delete table")

        Catch ex As OleDbException
            MsgBox("pelse start exam")


        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
        panselect.Top = 30

        btnstartexam.Visible = True

        frmresult.DataGridView1.Rows.Clear()

        panselect.Visible = True
        panmcq.Visible = False
        btncancel1.Enabled = False


    End Sub

    Private Sub Panexamcontrol_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panexamcontrol.Paint

    End Sub

    Private Sub txtfillanswer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtfillanswer.TextChanged

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsubmmit.Click
      



        'insert a record into a
        If rb1.Checked Then
            lblanswer.Text = rb1.Text
        ElseIf rb2.Checked Then
            lblanswer.Text = rb2.Text
        ElseIf rb3.Checked Then
            lblanswer.Text = rb4.Text
        ElseIf rb4.Checked Then
            lblanswer.Text = rb4.Text

        End If

        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Try


            Dim cm As New OleDbCommand("insert into practicleexam values('" & lblquestionid.Text & "','" & txtcorrectanswer.Text & "','" & lblanswer.Text & "')", con)
            cm.ExecuteNonQuery()

            'record insert in datagriedview

            'frmresult.DataGridView1.Rows.Add(lblquestion.Text, txtcorrectanswer.Text, lblanswer.Text)


            'record  insert query throw
            If type = 1 Then
                Dim recm1 As New OleDbCommand("select questions from mcq where questionid =" & lblquestionid.Text, con)
                Dim redr1 As OleDbDataReader
                redr1 = recm1.ExecuteReader
                While redr1.Read
                    frmresult.DataGridView1.Rows.Add(redr1.Item(0), txtcorrectanswer.Text, lblanswer.Text)


                End While
            ElseIf type = 2 Then
                Dim recm2 As New OleDbCommand("select questions from mcq where questionid =" & lblquestionid.Text, con)
                Dim redr2 As OleDbDataReader
                redr2 = recm2.ExecuteReader
                While redr2.Read
                    frmresult.DataGridView1.Rows.Add(redr2.Item(0), txtcorrectanswer.Text, lblanswer.Text)


                End While

            ElseIf type = 3 Then
                Dim recm3 As New OleDbCommand("select questions from mcq where questionid =" & lblquestionid.Text, con)
                Dim redr3 As OleDbDataReader
                redr3 = recm3.ExecuteReader
                While redr3.Read
                    frmresult.DataGridView1.Rows.Add(redr3.Item(0), txtcorrectanswer.Text, lblanswer.Text)


                End While

            End If


            con.Close()

            If txtcorrectanswer.Text = lblanswer.Text Then
                frmresult.lblmark.Text = Val(frmresult.lblmark.Text) + 1

            End If

            Call btnexamnext_Click()





        Catch ex1 As OleDbException
            MsgBox("you have solve")



        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btnresult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnresult.Click
      

        If row1 = 5 Then
            frmresult.Show()
            row1 = 0
        Else
            MsgBox("please solve all question")
        End If
      
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblcoosequestiontype.Click
        Panexamcontrol.Visible = False

        panchecked.Visible = True
        panselect.Visible = False
        cmbbook.Text = ""
        cmbquestioncat.Text = ""
        cmbcexamname.Text = ""
        btnstartexam.Enabled = False

    End Sub
End Class