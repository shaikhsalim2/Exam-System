﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmsetpaper
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnlast = New System.Windows.Forms.Button
        Me.btnfirst = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.btninsert = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.btnsearch = New System.Windows.Forms.Button
        Me.btnnext = New System.Windows.Forms.Button
        Me.gbaddpaper = New System.Windows.Forms.GroupBox
        Me.lblexamname = New System.Windows.Forms.Label
        Me.cmbexamname = New System.Windows.Forms.ComboBox
        Me.lbltruequestion = New System.Windows.Forms.Label
        Me.lblfbqquestion = New System.Windows.Forms.Label
        Me.lblmcqquestion = New System.Windows.Forms.Label
        Me.txttruefalse = New System.Windows.Forms.TextBox
        Me.txtfbq = New System.Windows.Forms.TextBox
        Me.txtmcq = New System.Windows.Forms.TextBox
        Me.dgpaperinformation = New System.Windows.Forms.DataGridView
        Me.lblpaperid = New System.Windows.Forms.Label
        Me.txtpaperid = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnsave1 = New System.Windows.Forms.Button
        Me.btnupdate1 = New System.Windows.Forms.Button
        Me.btndelete1 = New System.Windows.Forms.Button
        Me.btnadd1 = New System.Windows.Forms.Button
        Me.btnnext1 = New System.Windows.Forms.Button
        Me.cmbpaerid = New System.Windows.Forms.ComboBox
        Me.gbquestiontype = New System.Windows.Forms.GroupBox
        Me.rbtruefalse = New System.Windows.Forms.RadioButton
        Me.rbfbq = New System.Windows.Forms.RadioButton
        Me.rbmcq = New System.Windows.Forms.RadioButton
        Me.lblselectpaperid = New System.Windows.Forms.Label
        Me.dgquestion = New System.Windows.Forms.DataGridView
        Me.question = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Answer = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.option1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.option2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.optino3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.option4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.checkedboxco = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.cmbbookname = New System.Windows.Forms.ComboBox
        Me.lblbook = New System.Windows.Forms.Label
        Me.btnseequestion = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.gbaddpaper.SuspendLayout()
        CType(Me.dgpaperinformation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.gbquestiontype.SuspendLayout()
        CType(Me.dgquestion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnlast)
        Me.GroupBox1.Controls.Add(Me.btnfirst)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.btninsert)
        Me.GroupBox1.Controls.Add(Me.btndelete)
        Me.GroupBox1.Controls.Add(Me.btnadd)
        Me.GroupBox1.Controls.Add(Me.btnsearch)
        Me.GroupBox1.Controls.Add(Me.btnnext)
        Me.GroupBox1.Location = New System.Drawing.Point(18, 479)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(695, 70)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        '
        'btnlast
        '
        Me.btnlast.Location = New System.Drawing.Point(330, 31)
        Me.btnlast.Name = "btnlast"
        Me.btnlast.Size = New System.Drawing.Size(75, 23)
        Me.btnlast.TabIndex = 11
        Me.btnlast.Tag = "11"
        Me.btnlast.Text = "Last"
        Me.btnlast.UseVisualStyleBackColor = True
        '
        'btnfirst
        '
        Me.btnfirst.Location = New System.Drawing.Point(411, 31)
        Me.btnfirst.Name = "btnfirst"
        Me.btnfirst.Size = New System.Drawing.Size(75, 23)
        Me.btnfirst.TabIndex = 7
        Me.btnfirst.Tag = "7"
        Me.btnfirst.Text = "first"
        Me.btnfirst.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(573, 31)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 12
        Me.Button4.Tag = "12"
        Me.Button4.Text = "UPDATE"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'btninsert
        '
        Me.btninsert.Location = New System.Drawing.Point(87, 31)
        Me.btninsert.Name = "btninsert"
        Me.btninsert.Size = New System.Drawing.Size(75, 23)
        Me.btninsert.TabIndex = 5
        Me.btninsert.Text = "INSERT"
        Me.btninsert.UseVisualStyleBackColor = True
        '
        'btndelete
        '
        Me.btndelete.Location = New System.Drawing.Point(168, 31)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(75, 23)
        Me.btndelete.TabIndex = 10
        Me.btndelete.Tag = "10"
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(6, 31)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 23)
        Me.btnadd.TabIndex = 9
        Me.btnadd.Tag = "9"
        Me.btnadd.Text = "ADD"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(492, 31)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(75, 23)
        Me.btnsearch.TabIndex = 8
        Me.btnsearch.Tag = "8"
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'btnnext
        '
        Me.btnnext.Location = New System.Drawing.Point(249, 31)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(75, 23)
        Me.btnnext.TabIndex = 6
        Me.btnnext.Tag = "6"
        Me.btnnext.Text = "next"
        Me.btnnext.UseVisualStyleBackColor = True
        '
        'gbaddpaper
        '
        Me.gbaddpaper.Controls.Add(Me.lblexamname)
        Me.gbaddpaper.Controls.Add(Me.cmbexamname)
        Me.gbaddpaper.Controls.Add(Me.lbltruequestion)
        Me.gbaddpaper.Controls.Add(Me.lblfbqquestion)
        Me.gbaddpaper.Controls.Add(Me.lblmcqquestion)
        Me.gbaddpaper.Controls.Add(Me.txttruefalse)
        Me.gbaddpaper.Controls.Add(Me.txtfbq)
        Me.gbaddpaper.Controls.Add(Me.txtmcq)
        Me.gbaddpaper.Controls.Add(Me.dgpaperinformation)
        Me.gbaddpaper.Controls.Add(Me.lblpaperid)
        Me.gbaddpaper.Controls.Add(Me.txtpaperid)
        Me.gbaddpaper.Controls.Add(Me.GroupBox2)
        Me.gbaddpaper.Location = New System.Drawing.Point(12, 12)
        Me.gbaddpaper.Name = "gbaddpaper"
        Me.gbaddpaper.Size = New System.Drawing.Size(883, 185)
        Me.gbaddpaper.TabIndex = 19
        Me.gbaddpaper.TabStop = False
        Me.gbaddpaper.Text = "ADD PAPER"
        '
        'lblexamname
        '
        Me.lblexamname.AutoSize = True
        Me.lblexamname.Location = New System.Drawing.Point(302, 21)
        Me.lblexamname.Name = "lblexamname"
        Me.lblexamname.Size = New System.Drawing.Size(74, 13)
        Me.lblexamname.TabIndex = 26
        Me.lblexamname.Text = "Select a exam"
        '
        'cmbexamname
        '
        Me.cmbexamname.FormattingEnabled = True
        Me.cmbexamname.Location = New System.Drawing.Point(382, 22)
        Me.cmbexamname.Name = "cmbexamname"
        Me.cmbexamname.Size = New System.Drawing.Size(121, 21)
        Me.cmbexamname.TabIndex = 27
        '
        'lbltruequestion
        '
        Me.lbltruequestion.AutoSize = True
        Me.lbltruequestion.Location = New System.Drawing.Point(10, 99)
        Me.lbltruequestion.Name = "lbltruequestion"
        Me.lbltruequestion.Size = New System.Drawing.Size(127, 13)
        Me.lbltruequestion.TabIndex = 29
        Me.lbltruequestion.Text = "NO of Truefalse Question"
        '
        'lblfbqquestion
        '
        Me.lblfbqquestion.AutoSize = True
        Me.lblfbqquestion.Location = New System.Drawing.Point(11, 77)
        Me.lblfbqquestion.Name = "lblfbqquestion"
        Me.lblfbqquestion.Size = New System.Drawing.Size(99, 13)
        Me.lblfbqquestion.TabIndex = 28
        Me.lblfbqquestion.Text = "No of Fbq Question"
        '
        'lblmcqquestion
        '
        Me.lblmcqquestion.AutoSize = True
        Me.lblmcqquestion.Location = New System.Drawing.Point(11, 51)
        Me.lblmcqquestion.Name = "lblmcqquestion"
        Me.lblmcqquestion.Size = New System.Drawing.Size(101, 13)
        Me.lblmcqquestion.TabIndex = 27
        Me.lblmcqquestion.Text = "No of mcq Question"
        '
        'txttruefalse
        '
        Me.txttruefalse.Location = New System.Drawing.Point(143, 96)
        Me.txttruefalse.Name = "txttruefalse"
        Me.txttruefalse.Size = New System.Drawing.Size(178, 20)
        Me.txttruefalse.TabIndex = 26
        '
        'txtfbq
        '
        Me.txtfbq.Location = New System.Drawing.Point(118, 70)
        Me.txtfbq.Name = "txtfbq"
        Me.txtfbq.Size = New System.Drawing.Size(178, 20)
        Me.txtfbq.TabIndex = 25
        '
        'txtmcq
        '
        Me.txtmcq.Location = New System.Drawing.Point(118, 44)
        Me.txtmcq.Name = "txtmcq"
        Me.txtmcq.Size = New System.Drawing.Size(178, 20)
        Me.txtmcq.TabIndex = 24
        '
        'dgpaperinformation
        '
        Me.dgpaperinformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgpaperinformation.Location = New System.Drawing.Point(509, 4)
        Me.dgpaperinformation.Name = "dgpaperinformation"
        Me.dgpaperinformation.Size = New System.Drawing.Size(368, 175)
        Me.dgpaperinformation.TabIndex = 20
        '
        'lblpaperid
        '
        Me.lblpaperid.AutoSize = True
        Me.lblpaperid.Location = New System.Drawing.Point(11, 25)
        Me.lblpaperid.Name = "lblpaperid"
        Me.lblpaperid.Size = New System.Drawing.Size(42, 13)
        Me.lblpaperid.TabIndex = 23
        Me.lblpaperid.Text = "paperid"
        '
        'txtpaperid
        '
        Me.txtpaperid.Location = New System.Drawing.Point(118, 18)
        Me.txtpaperid.Name = "txtpaperid"
        Me.txtpaperid.Size = New System.Drawing.Size(178, 20)
        Me.txtpaperid.TabIndex = 21
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnsave1)
        Me.GroupBox2.Controls.Add(Me.btnupdate1)
        Me.GroupBox2.Controls.Add(Me.btndelete1)
        Me.GroupBox2.Controls.Add(Me.btnadd1)
        Me.GroupBox2.Controls.Add(Me.btnnext1)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 114)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(497, 49)
        Me.GroupBox2.TabIndex = 20
        Me.GroupBox2.TabStop = False
        '
        'btnsave1
        '
        Me.btnsave1.Location = New System.Drawing.Point(125, 19)
        Me.btnsave1.Name = "btnsave1"
        Me.btnsave1.Size = New System.Drawing.Size(75, 23)
        Me.btnsave1.TabIndex = 5
        Me.btnsave1.Text = "SAVE"
        Me.btnsave1.UseVisualStyleBackColor = True
        '
        'btnupdate1
        '
        Me.btnupdate1.Location = New System.Drawing.Point(411, 19)
        Me.btnupdate1.Name = "btnupdate1"
        Me.btnupdate1.Size = New System.Drawing.Size(75, 23)
        Me.btnupdate1.TabIndex = 12
        Me.btnupdate1.Tag = "12"
        Me.btnupdate1.Text = "UPDATE"
        Me.btnupdate1.UseVisualStyleBackColor = True
        '
        'btndelete1
        '
        Me.btndelete1.Location = New System.Drawing.Point(230, 19)
        Me.btndelete1.Name = "btndelete1"
        Me.btndelete1.Size = New System.Drawing.Size(75, 23)
        Me.btndelete1.TabIndex = 10
        Me.btndelete1.Tag = "10"
        Me.btndelete1.Text = "DELETE"
        Me.btndelete1.UseVisualStyleBackColor = True
        '
        'btnadd1
        '
        Me.btnadd1.Location = New System.Drawing.Point(29, 20)
        Me.btnadd1.Name = "btnadd1"
        Me.btnadd1.Size = New System.Drawing.Size(75, 23)
        Me.btnadd1.TabIndex = 9
        Me.btnadd1.Tag = "9"
        Me.btnadd1.Text = "ADD"
        Me.btnadd1.UseVisualStyleBackColor = True
        '
        'btnnext1
        '
        Me.btnnext1.Location = New System.Drawing.Point(330, 19)
        Me.btnnext1.Name = "btnnext1"
        Me.btnnext1.Size = New System.Drawing.Size(75, 23)
        Me.btnnext1.TabIndex = 6
        Me.btnnext1.Tag = "6"
        Me.btnnext1.Text = "next"
        Me.btnnext1.UseVisualStyleBackColor = True
        '
        'cmbpaerid
        '
        Me.cmbpaerid.FormattingEnabled = True
        Me.cmbpaerid.Location = New System.Drawing.Point(121, 199)
        Me.cmbpaerid.Name = "cmbpaerid"
        Me.cmbpaerid.Size = New System.Drawing.Size(121, 21)
        Me.cmbpaerid.TabIndex = 20
        '
        'gbquestiontype
        '
        Me.gbquestiontype.Controls.Add(Me.rbtruefalse)
        Me.gbquestiontype.Controls.Add(Me.rbfbq)
        Me.gbquestiontype.Controls.Add(Me.rbmcq)
        Me.gbquestiontype.Location = New System.Drawing.Point(248, 187)
        Me.gbquestiontype.Name = "gbquestiontype"
        Me.gbquestiontype.Size = New System.Drawing.Size(560, 39)
        Me.gbquestiontype.TabIndex = 21
        Me.gbquestiontype.TabStop = False
        Me.gbquestiontype.Text = "choose the question type"
        '
        'rbtruefalse
        '
        Me.rbtruefalse.AutoSize = True
        Me.rbtruefalse.Location = New System.Drawing.Point(435, 19)
        Me.rbtruefalse.Name = "rbtruefalse"
        Me.rbtruefalse.Size = New System.Drawing.Size(75, 17)
        Me.rbtruefalse.TabIndex = 2
        Me.rbtruefalse.TabStop = True
        Me.rbtruefalse.Text = "True False"
        Me.rbtruefalse.UseVisualStyleBackColor = True
        '
        'rbfbq
        '
        Me.rbfbq.AutoSize = True
        Me.rbfbq.Location = New System.Drawing.Point(221, 16)
        Me.rbfbq.Name = "rbfbq"
        Me.rbfbq.Size = New System.Drawing.Size(46, 17)
        Me.rbfbq.TabIndex = 1
        Me.rbfbq.TabStop = True
        Me.rbfbq.Text = "FBQ"
        Me.rbfbq.UseVisualStyleBackColor = True
        '
        'rbmcq
        '
        Me.rbmcq.AutoSize = True
        Me.rbmcq.Location = New System.Drawing.Point(25, 21)
        Me.rbmcq.Name = "rbmcq"
        Me.rbmcq.Size = New System.Drawing.Size(45, 17)
        Me.rbmcq.TabIndex = 0
        Me.rbmcq.TabStop = True
        Me.rbmcq.Text = "mcq"
        Me.rbmcq.UseVisualStyleBackColor = True
        '
        'lblselectpaperid
        '
        Me.lblselectpaperid.AutoSize = True
        Me.lblselectpaperid.Location = New System.Drawing.Point(21, 202)
        Me.lblselectpaperid.Name = "lblselectpaperid"
        Me.lblselectpaperid.Size = New System.Drawing.Size(77, 13)
        Me.lblselectpaperid.TabIndex = 24
        Me.lblselectpaperid.Text = "Select a Paper"
        '
        'dgquestion
        '
        Me.dgquestion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgquestion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.question, Me.Answer, Me.option1, Me.option2, Me.optino3, Me.option4, Me.checkedboxco})
        Me.dgquestion.Location = New System.Drawing.Point(18, 252)
        Me.dgquestion.Name = "dgquestion"
        Me.dgquestion.Size = New System.Drawing.Size(790, 252)
        Me.dgquestion.TabIndex = 25
        '
        'question
        '
        Me.question.HeaderText = "Question"
        Me.question.Name = "question"
        '
        'Answer
        '
        Me.Answer.HeaderText = "Answer"
        Me.Answer.Name = "Answer"
        '
        'option1
        '
        Me.option1.HeaderText = "option1"
        Me.option1.Name = "option1"
        '
        'option2
        '
        Me.option2.HeaderText = "option2"
        Me.option2.Name = "option2"
        '
        'optino3
        '
        Me.optino3.HeaderText = "option3"
        Me.optino3.Name = "optino3"
        '
        'option4
        '
        Me.option4.HeaderText = "option4"
        Me.option4.Name = "option4"
        '
        'checkedboxco
        '
        Me.checkedboxco.HeaderText = "selected"
        Me.checkedboxco.Name = "checkedboxco"
        '
        'cmbbookname
        '
        Me.cmbbookname.FormattingEnabled = True
        Me.cmbbookname.Location = New System.Drawing.Point(121, 225)
        Me.cmbbookname.Name = "cmbbookname"
        Me.cmbbookname.Size = New System.Drawing.Size(121, 21)
        Me.cmbbookname.TabIndex = 26
        '
        'lblbook
        '
        Me.lblbook.AutoSize = True
        Me.lblbook.Location = New System.Drawing.Point(23, 228)
        Me.lblbook.Name = "lblbook"
        Me.lblbook.Size = New System.Drawing.Size(62, 13)
        Me.lblbook.TabIndex = 27
        Me.lblbook.Text = "select book"
        '
        'btnseequestion
        '
        Me.btnseequestion.Location = New System.Drawing.Point(697, 510)
        Me.btnseequestion.Name = "btnseequestion"
        Me.btnseequestion.Size = New System.Drawing.Size(130, 23)
        Me.btnseequestion.TabIndex = 28
        Me.btnseequestion.Text = "Show the question"
        Me.btnseequestion.UseVisualStyleBackColor = True
        '
        'frmsetpaper
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(907, 561)
        Me.Controls.Add(Me.btnseequestion)
        Me.Controls.Add(Me.lblbook)
        Me.Controls.Add(Me.cmbbookname)
        Me.Controls.Add(Me.dgquestion)
        Me.Controls.Add(Me.lblselectpaperid)
        Me.Controls.Add(Me.gbquestiontype)
        Me.Controls.Add(Me.cmbpaerid)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gbaddpaper)
        Me.Name = "frmsetpaper"
        Me.Text = "frmsetpaper"
        Me.GroupBox1.ResumeLayout(False)
        Me.gbaddpaper.ResumeLayout(False)
        Me.gbaddpaper.PerformLayout()
        CType(Me.dgpaperinformation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.gbquestiontype.ResumeLayout(False)
        Me.gbquestiontype.PerformLayout()
        CType(Me.dgquestion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnlast As System.Windows.Forms.Button
    Friend WithEvents btnfirst As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents btninsert As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents btnnext As System.Windows.Forms.Button
    Friend WithEvents gbaddpaper As System.Windows.Forms.GroupBox
    Friend WithEvents lblpaperid As System.Windows.Forms.Label
    Friend WithEvents txtpaperid As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnsave1 As System.Windows.Forms.Button
    Friend WithEvents btnupdate1 As System.Windows.Forms.Button
    Friend WithEvents btndelete1 As System.Windows.Forms.Button
    Friend WithEvents btnadd1 As System.Windows.Forms.Button
    Friend WithEvents btnnext1 As System.Windows.Forms.Button
    Friend WithEvents dgpaperinformation As System.Windows.Forms.DataGridView
    Friend WithEvents cmbpaerid As System.Windows.Forms.ComboBox
    Friend WithEvents gbquestiontype As System.Windows.Forms.GroupBox
    Friend WithEvents rbtruefalse As System.Windows.Forms.RadioButton
    Friend WithEvents rbfbq As System.Windows.Forms.RadioButton
    Friend WithEvents rbmcq As System.Windows.Forms.RadioButton
    Friend WithEvents lblselectpaperid As System.Windows.Forms.Label
    Friend WithEvents dgquestion As System.Windows.Forms.DataGridView
    Friend WithEvents lbltruequestion As System.Windows.Forms.Label
    Friend WithEvents lblfbqquestion As System.Windows.Forms.Label
    Friend WithEvents lblmcqquestion As System.Windows.Forms.Label
    Friend WithEvents txttruefalse As System.Windows.Forms.TextBox
    Friend WithEvents txtfbq As System.Windows.Forms.TextBox
    Friend WithEvents txtmcq As System.Windows.Forms.TextBox
    Friend WithEvents lblexamname As System.Windows.Forms.Label
    Friend WithEvents cmbexamname As System.Windows.Forms.ComboBox
    Friend WithEvents cmbbookname As System.Windows.Forms.ComboBox
    Friend WithEvents lblbook As System.Windows.Forms.Label
    Friend WithEvents question As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Answer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents option1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents option2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents optino3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents option4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents checkedboxco As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents btnseequestion As System.Windows.Forms.Button
End Class
