﻿Imports System.Data.OleDb


Public Class mcq
    Dim b1 As Integer
    Dim bookid As Integer

    Dim da As New OleDbDataAdapter("select *from mcq", con)





    Private Sub mcq_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            txtanswer.Enabled = False

            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "mcq")
            cmb = New OleDbCommandBuilder(da)
            n = ds.Tables("mcq").Rows.Count - 1

            Call dataa(n)
            If con.State = ConnectionState.Closed Then  'connection open
                con.Open()
            End If

            btnsave.Enabled = False

            Call bookkid()
            Call questioncategory()



        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub
    Public Sub dataa(ByVal mc1 As Byte)
        Try


            With ds.Tables("mcq").Rows(mc1)

                txtquestionid.Text = .Item(0)
                cmbsubjectid.Text = .Item(1)


                txtquestion.Text = .Item(2)
                txtoption1.Text = .Item(3)
                txtoption2.Text = .Item(4)
                txtoption3.Text = .Item(5)
                txtoption4.Text = .Item(6)
                txtanswer.Text = .Item(7)


                cmbquestioncategory.Text = .Item(8)





            End With
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub bookkid()
        Try

            Dim mcqcm As New OleDbCommand("select bookname from bookmaster", con) 'establish command
            Dim mcqdr As OleDbDataReader 'define datareader
            mcqdr = mcqcm.ExecuteReader
            While mcqdr.Read
                cmbsubjectid.Items.Add(mcqdr.Item(0))  'add items in cmbsubjectid

            End While
            mcqdr.Close() 'cose the mcqdr(datareader

            con.Close()  'close connection
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub questioncategory()
        Try


            'retrive the questioncategory name

            If con.State = ConnectionState.Closed Then
                con.Open() 'open the connectio
            End If

            Dim questioncatdr1 As OleDbDataReader
            Dim questioncatcm1 As New OleDbCommand("select questioncat from questioncategory", con)
            questioncatdr1 = questioncatcm1.ExecuteReader
            While questioncatdr1.Read
                cmbquestioncategory.Items.Add(questioncatdr1.Item(0))

            End While
            questioncatdr1.Close()  'close the datereader

            con.Close()  'close the connection
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub retrivebookid()
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            'retrive the subjectid using subjectname
            Dim mcqcm2 As New OleDbCommand("select  bookid from bookmaster where bookname like '" & Trim(cmbsubjectid.Text) & "'", con)
            Dim mcqdr2 As OleDbDataReader  'define datareader
            mcqdr2 = mcqcm2.ExecuteReader  'read the database
            While mcqdr2.Read
                bookid = mcqdr2.Item(0) 'store selected item in subjectid
            End While
            mcqdr2.Close() 'close the datareader
            con.Close() 'close the connection
            dgmcq.Rows.Clear()  'clear the all reows in datagridview
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub datagrid()

        'retrive mcq question related to subjectid
        Dim mcqcm3 As New OleDbCommand("select * from mcq where subjectid=" & bookid, con)
        Dim mcqdr3 As OleDbDataReader
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        mcqdr3 = mcqcm3.ExecuteReader
        While mcqdr3.Read
            dgmcq.Rows.Add(mcqdr3.Item(0), mcqdr3.Item(1), mcqdr3.Item(2), mcqdr3.Item(3), mcqdr3.Item(4), mcqdr3.Item(5), mcqdr3.Item(6))
        End While
        mcqdr3.Close()
        con.Close()
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

            txtquestionid.Enabled = False
            btnsave.Enabled = True

            txtquestionid.Text = ds.Tables("mcq").Rows.Count + 1
            txtquestion.Clear()
            txtoption1.Clear()
            txtoption2.Clear()
            txtoption3.Clear()
            txtoption4.Clear()
            txtanswer.Clear()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

    

            If txtanswer.Text = "" Then
                MsgBox("currectanswer fill")

            ElseIf txtoption1.Text = "" Then
                MsgBox("fanswer fill")

            ElseIf txtoption2.Text = "'" Then
                MsgBox("secondanswer fill")
            ElseIf txtoption3.Text = "" Then
                MsgBox("third answer fill")
            ElseIf txtoption4.Text = "" Then
                MsgBox("fourth answerb fill")

            ElseIf txtquestion.Text = "" Then
                MsgBox("question fill")


            Else

                Dim r As DataRow
                r = ds.Tables("mcq").NewRow
                r.Item(0) = Val(txtquestionid.Text)
                r.Item(1) = bookid
                r.Item(2) = txtquestion.Text
                r.Item(3) = txtoption1.Text
                r.Item(4) = txtoption2.Text
                r.Item(5) = txtoption3.Text
                r.Item(6) = txtoption4.Text
                r.Item(7) = txtanswer.Text
                r.Item(8) = questionid
                ds.Tables("mcq").Rows.Add(r)
                da.Update(ds, "mcq")
                MsgBox("record save")
                dgmcq.Update()
                n = 0
                Call dataa(n)
            End If

       
        Catch ex As IndexOutOfRangeException

            MsgBox("ok")
        Catch ex1 As ConstraintException
            MsgBox("dublicate id")

        Catch ex3 As Exception
            MsgBox(ex3)

        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)





    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try


            If n < ds.Tables("mcq").Rows.Count - 1 Then
                n = n + 1
                Call dataa(n)
            Else
                MsgBox("last record")

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnupdated_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdated.Click
        Try

            a = 0
            ds.Tables("mcq").Rows(n).Item(1) = bookid
            ds.Tables("mcq").Rows(n).Item(2) = txtquestion.Text
            ds.Tables("mcq").Rows(n).Item(3) = txtoption1.Text
            ds.Tables("mcq").Rows(n).Item(4) = txtoption2.Text
            ds.Tables("mcq").Rows(n).Item(5) = txtoption3.Text
            ds.Tables("mcq").Rows(n).Item(6) = txtoption4.Text
            ds.Tables("mcq").Rows(n).Item(7) = txtanswer.Text()
            ds.Tables("mcq").Rows(n).Item(8) = questionid
            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure")
            If a = 1 Then
                da.Update(ds, "mcq")
                MsgBox("updated")
                dgmcq.Update()

            Else
                n = 0

                Call dataa(n)
            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))


        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try


            dgmcq.Rows.Clear()


            Dim eno As Byte
            eno = InputBox("enter question id")

            'retrive mcq question related to subjectid
            Dim mcqcm3 As New OleDbCommand("select * from mcq where questionid=" & eno, con)
            Dim mcqdr3 As OleDbDataReader
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            mcqdr3 = mcqcm3.ExecuteReader
            While mcqdr3.Read
                dgmcq.Rows.Add(mcqdr3.Item(0), mcqdr3.Item(1), mcqdr3.Item(2), mcqdr3.Item(3), mcqdr3.Item(4), mcqdr3.Item(5), mcqdr3.Item(6))
            End While
            mcqdr3.Close()
            con.Close()


        Catch ex As InvalidCastException


            MsgBox("enter the number")

        Catch ex2 As RowNotInTableException
            MsgBox("row is not presented")
        Catch ex1 As Exception
            MsgBox(Convert.ToString(ex1))
        End Try


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btndelete.Click
        Try


            Dim t As Byte
            t = MsgBox("are you su", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "ok")
            If t = 1 Then
                ds.Tables("mcq").Rows(n).Delete()
                da.Update(ds, "mcq")
                MsgBox("delete row")
                n = 1
                Call dataa(n)
                dgmcq.Update()

            End If
        Catch ex As RowNotInTableException
            MsgBox("record is not found")

        End Try
    End Sub

    Private Sub cmbsubjectid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbsubjectid.KeyPress
        MsgBox("only select")

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbsubjectid.SelectedIndexChanged

        Call retrivebookid()

        Call datagrid()


    End Sub

    Private Sub dgmcq_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgmcq.CellContentClick
        Dim r As Integer
        r = dgmcq.CurrentRow.Index
        txtquestionid.Text = dgmcq.Item(0, r).Value
        cmbsubjectid.Text = dgmcq.Item(1, r).Value
        txtquestion.Text = dgmcq.Item(2, r).Value
        txtoption1.Text = dgmcq.Item(3, r).Value
        txtoption2.Text = dgmcq.Item(4, r).Value
        txtoption3.Text = dgmcq.Item(5, r).Value

        txtoption4.Text = dgmcq.Item(6, r).Value

        txtanswer.Text = dgmcq.Item(7, r).Value




    End Sub


    Private Sub cmbquestioncategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbquestioncategory.SelectedIndexChanged
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim questioncategorycm2 As New OleDbCommand("select questionid from questioncategory where questioncat like'" & Trim(cmbquestioncategory.Text) & "'", con)
            Dim questioncategorydr2 As OleDbDataReader
            questioncategorydr2 = questioncategorycm2.ExecuteReader
            While questioncategorydr2.Read
                questionid = questioncategorydr2.Item(0)


            End While
            questioncategorydr2.Close()

            con.Close()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub txtcurrectanswer_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)

    End Sub

    Private Sub txtcurrectanswer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        Try


            n = ds.Tables("mcq").Rows.Count - 1
            Call dataa(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub txtquestion_StyleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtquestion.StyleChanged

    End Sub

    Private Sub txtquestion_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtquestion.TextChanged

    End Sub

    Private Sub txtquestion_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtquestion.Validating

    End Sub

    Private Sub rb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1.CheckedChanged

    End Sub

    Private Sub rb1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb1.Click
        If rb1.Checked Then
            txtanswer.Text = txtoption1.Text


        End If
    End Sub

    Private Sub txtoption4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtoption4.TextChanged

    End Sub

    Private Sub rb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2.CheckedChanged

    End Sub

    Private Sub rb3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb3.CheckedChanged
        
    End Sub

    Private Sub rb3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb3.Click
        If rb3.Checked Then
            txtanswer.Text = txtoption3.Text

        End If
    End Sub

    Private Sub rb2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb2.Click
        If rb2.Checked Then
            txtanswer.Text = txtoption2.Text

        End If
    End Sub

    Private Sub rb4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb4.CheckedChanged

    End Sub

    Private Sub rb4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb4.Click
        If rb4.Checked Then
            txtanswer.Text = txtoption4.Text

        End If
    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        n = 0
        Call dataa(n)
    End Sub
End Class