﻿Imports System.Data.OleDb

Public Class frmsetpaper
    Dim type As Byte
    Dim examid As Byte
    Dim bookid As Byte
    Dim examname As String
    Dim da As New OleDbDataAdapter("select *from exampaper", con)


    Private Sub frmsetpaper_Load() Handles MyBase.Load
        btnsave1.Visible = False
        cmbpaerid.Items.Clear()

        Try

            da.Fill(ds, "exampaper")
            cmb = New OleDbCommandBuilder(da)
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            n = 0
            Call paperid(n)
            dgpaperinformation.DataSource = ds.Tables("exampaper")




            'insert a paperid in cmbpaperid
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim apicm As New OleDbCommand("select *from exampaper", con)
            Dim apidr As OleDbDataReader
            apidr = apicm.ExecuteReader
            While apidr.Read
                cmbpaerid.Items.Add(apidr.Item(0))
            End While
            con.Close()
        



            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim excm As New OleDbCommand("select  examname from cexammaster", con)
            Dim exdr As OleDbDataReader
            exdr = excm.ExecuteReader
            While exdr.Read
                cmbexamname.Items.Add(exdr.Item(0))

            End While
            con.Close()

          

        Catch ex As Exception

        End Try
    End Sub
    Public Sub examid1()
        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim examidcm As New OleDbCommand("select examid from cexammaster where examname like'" & Trim(cmbexamname.Text) & "'", con)
        Dim examiddr As OleDbDataReader
        examiddr = examidcm.ExecuteReader
        While examiddr.Read
            examid = examiddr.Item(0)

        End While
        con.Close()
        MsgBox(examid)



    End Sub
   

    
    Public Sub paperid(ByVal rno As Byte)
        Try

       
            With ds.Tables("exampaper").Rows(rno)
                txtpaperid.Text = .Item(0)
                txtmcq.Text = .Item(2)
                txtfbq.Text = .Item(3)
                txttruefalse.Text = .Item(4)
                cmbexamname.Text = .Item(1)
            End With

        Catch ex As IndexOutOfRangeException



        End Try

    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click

    End Sub


    Private Sub btnadd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd1.Click
        btnsave1.Visible = True
        Try

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim pacm As New OleDbCommand("create table exampaper ([paperid] varchar primary key,[examid] INTEGER ,[mcqquestion] INTEGER,[fbqQuestion] INTEGER,[truequestion]  INTEGER)", con)
            pacm.ExecuteNonQuery()
            MsgBox("table create")

            Dim pacma As New OleDbCommand("ALTER TABLE [exampaper] ADD FOREIGN KEY (examid) REFERENCES cexammaster(examid)", con)
            MsgBox("table alter")
            con.Close()

        Catch ex As Exception
            txtpaperid.Clear()
            txtmcq.Clear()
            txtfbq.Clear()
            txttruefalse.Clear()



        End Try



    End Sub

    Private Sub btnsave1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave1.Click



        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim pacm1 As New OleDbCommand("insert into exampaper values('" & txtpaperid.Text & "','" & examid & "','" & txtmcq.Text & "','" & txtfbq.Text & "','" & txttruefalse.Text & "')", con)
        pacm1.ExecuteNonQuery()

        Call frmsetpaper_Load()
        dgpaperinformation.Update()

        con.Close()
        n = 0
        Call paperid(n)


    End Sub

    Private Sub btndelete1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete1.Click
        Try



            Dim de As Byte
            de = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "ok")
            If de = 1 Then
                ds.Tables("exampaper").Rows(n).Delete()
                da.Update(ds, "exampaper")
            Else
                MsgBox("ok")

            End If
            n = 0
            Call paperid(n)

            dgpaperinformation.Update()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnnext1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext1.Click

        Try


       
            If n < ds.Tables("exampaper").Rows.Count - 1 Then
                n = n + 1
                Call paperid(n)
            Else
                MsgBox("last paper")

            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnupdate1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate1.Click
        Try

       
            ds.Tables("exampaper").Rows(n).Item(0) = txtpaperid.Text
            da.Update(ds, "exampaper")
            MsgBox("record update")
            Call paperid(n)
            dgpaperinformation.Update()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub gbaddpaper_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gbaddpaper.Enter

    End Sub

    Private Sub cmbpaerid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbpaerid.SelectedIndexChanged
        Try

            cmbbookname.Items.Clear()


            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim examidcm2 As New OleDbCommand("select examid from exampaper where paperid like '" & cmbpaerid.Text & "'", con)
            Dim examiddr2 As OleDbDataReader
            examiddr2 = examidcm2.ExecuteReader
            While examiddr2.Read
                examname = examiddr2.Item(0)
            End While




            Dim bookcm As New OleDbCommand("select  bookname from bookmaster where examid =" & examname, con)
            Dim bookdr As OleDbDataReader
            bookdr = bookcm.ExecuteReader
            While bookdr.Read
                cmbbookname.Items.Add(bookdr.Item(0))

            End While

            con.Close()
        Catch ex As Exception

        End Try




    End Sub

    Private Sub rbmcq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbmcq.CheckedChanged
        If rbmcq.Checked Then


            dgquestion.Rows.Clear()
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim mcqquestioncm As New OleDbCommand("select questions ,fans,sans,tans,foans,cans from mcq where subjectid= " & bookid, con)
            Dim mcqquestiondr As OleDbDataReader
            mcqquestiondr = mcqquestioncm.ExecuteReader
            While mcqquestiondr.Read

                dgquestion.Rows.Add(mcqquestiondr.Item(0), mcqquestiondr.Item(5), mcqquestiondr.Item(1), mcqquestiondr.Item(2), mcqquestiondr.Item(3), mcqquestiondr.Item(4))

            End While



        End If
    End Sub

    Private Sub rbmcq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbmcq.Click
        If rbmcq.Checked = True Then
            type = 1

        End If
    End Sub

    Private Sub rbfbq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbfbq.CheckedChanged
        If rbfbq.Checked Then
           
            dgquestion.Rows.Clear()
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim fbqquestioncm As New OleDbCommand("select  *from fbqt where subjectid=" & bookid, con)
            Dim fbqquestiondr As OleDbDataReader
            fbqquestiondr = fbqquestioncm.ExecuteReader
            While fbqquestiondr.Read

                dgquestion.Rows.Add(fbqquestiondr.Item(2), fbqquestiondr.Item(3))

            End While
            con.Close()


        End If
    End Sub

    Private Sub rbfbq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbfbq.Click
        If rbfbq.Checked = True Then
            type = 2
        End If
    End Sub

    Private Sub rbtruefalse_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtruefalse.CheckedChanged
        If rbtruefalse.Checked Then


            dgquestion.Rows.Clear()
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If

            Dim fbqquestioncm As New OleDbCommand("select  *from truefalse  where subjectid=" & bookid, con)
            Dim fbqquestiondr As OleDbDataReader
            fbqquestiondr = fbqquestioncm.ExecuteReader
            While fbqquestiondr.Read

                dgquestion.Rows.Add(fbqquestiondr.Item(2), fbqquestiondr.Item(3))

            End While
            con.Close()


        End If
    End Sub

    Private Sub rbtruefalse_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtruefalse.Click
        If rbtruefalse.Checked = True Then
            type = 3

        End If
    End Sub

    Private Sub cmbsubject_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbbookname.SelectedIndexChanged
        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        rbfbq.Checked = False
        rbmcq.Checked = False
        rbtruefalse.Checked = False

        Dim bookidcm As New OleDbCommand("select bookid from bookmaster where bookname like'" & cmbbookname.Text & "'", con)
        Dim bookiddr As OleDbDataReader
        bookiddr = bookidcm.ExecuteReader
        While bookiddr.Read
            bookid = bookiddr.Item(0)

        End While
        con.Close()

        MsgBox(bookid)


    End Sub

    Private Sub cmbexamname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbexamname.SelectedIndexChanged
        Call examid1()

    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click



        Try

      


            If type = 1 Then




                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If
                Dim crpqcm As New OleDbCommand("create table mcqquestionpaper (paparid varchar,Question varchar  primary key ,Answer varchar,opt1 varchar,opt2 varchar ,opt3 varchar ,opt4 varchar)", con)
                crpqcm.ExecuteNonQuery()

                con.Close()
            ElseIf type = 2 Then
                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If
                Dim crpcm2 As New OleDbCommand("create table fbqquestionpaper(paperid varchar,Queetion varchar primary key,Answer varchar)", con)
                crpcm2.ExecuteNonQuery()

                con.Close()

            ElseIf type = 3 Then
                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If
                Dim crpcm3 As New OleDbCommand("create table truefalsequestionpaper(paperid varchar,Queetion varchar primary key,Answer varchar)", con)
                crpcm3.ExecuteNonQuery()
                MsgBox("table create")
                con.Close()



            End If





line:


            Dim inserted As Integer = 0
            For Each row As DataGridViewRow In dgquestion.Rows
                Dim isSelected As Boolean = Convert.ToBoolean(row.Cells("checkedboxco").Value)









                If isSelected Then
                    If type = 1 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If
                        Dim insertcm As New OleDbCommand("insert into  mcqquestionpaper  values(paparid,Question,Answer,opt1,opt2,opt3,opt4)", con)
                        insertcm.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        insertcm.Parameters.AddWithValue("Question", row.Cells("Question").Value)
                        insertcm.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)
                        insertcm.Parameters.AddWithValue("opt1", row.Cells("option1").Value)
                        insertcm.Parameters.AddWithValue("opt2", row.Cells("option2").Value)
                        insertcm.Parameters.AddWithValue("opt3", row.Cells("optino3").Value)
                        insertcm.Parameters.AddWithValue("opt4", row.Cells("option4").Value)

                        insertcm.ExecuteNonQuery()

                        inserted = inserted + 1
                        con.Close()
                    ElseIf type = 2 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If
                        Dim insertcm2 As New OleDbCommand("insert into fbqquestionpaper values(paperid ,Question,Answer)", con)
                        insertcm2.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        insertcm2.Parameters.AddWithValue("Question", row.Cells("Question").Value)
                        insertcm2.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)
                        insertcm2.ExecuteNonQuery()

                        inserted = inserted + 1
                        con.Close()

                    ElseIf type = 3 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If

                        Dim insertcm3 As New OleDbCommand("insert into truefalsequestionpaper values(paperid,Question,Answer)", con)
                        insertcm3.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        insertcm3.Parameters.AddWithValue("Question", row.Cells("Question").Value)
                        insertcm3.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)
                        con.Close()

                    End If
                Else
                    Exit For


                End If

                'insert record in fbq table 



            Next





        Catch ex As Exception
            GoTo line
        End Try



    End Sub

    Private Sub dgquestion_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgquestion.CellContentClick

    End Sub

    Private Sub dgquestion_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgquestion.CellMouseClick

    End Sub
End Class