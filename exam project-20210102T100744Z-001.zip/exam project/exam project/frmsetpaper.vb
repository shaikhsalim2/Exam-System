﻿Imports System.Data.OleDb

Public Class frmsetpaper
    Dim type As Byte
    Dim examid As Byte
    Dim bookid As Byte
    Dim examname As Byte
    Dim da As New OleDbDataAdapter("select *from exampaper", con)


    Private Sub frmsetpaper_Load() Handles MyBase.Load
        Try

            cmbexamname.Items.Clear()
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim excm As New OleDbCommand("select  examname from cexammaster", con)
            Dim exdr As OleDbDataReader
            exdr = excm.ExecuteReader
            While exdr.Read
                cmbexamname.Items.Add(exdr.Item(0))

            End While
            con.Close()

            btnsave1.Visible = False
            cmbpaerid.Items.Clear()



            da.Fill(ds, "exampaper")
            cmb = New OleDbCommandBuilder(da)
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            n = 0
            Call paperid(n)
            dgpaperinformation.DataSource = ds.Tables("exampaper")



            cmbpaerid.Items.Clear()
            'insert a paperid in cmbpaperid
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim apicm As New OleDbCommand("select *from exampaper", con)
            Dim apidr As OleDbDataReader
            apidr = apicm.ExecuteReader
            While apidr.Read
                cmbpaerid.Items.Add(apidr.Item(0))
            End While
            con.Close()




           

        Catch ex2 As InvalidExpressionException


        Catch ex As Exception
            MsgBox("create a exampaper")
        End Try


    End Sub
    Public Sub examid1()
        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim examidcm As New OleDbCommand("select examid from cexammaster where examname like'" & Trim(cmbexamname.Text) & "'", con)
        Dim examiddr As OleDbDataReader
        examiddr = examidcm.ExecuteReader
        While examiddr.Read
            examid = examiddr.Item(0)

        End While
        con.Close()
        MsgBox(examid)



    End Sub
   

    
    Public Sub paperid(ByVal rno As Byte)
        Try

       
            With ds.Tables("exampaper").Rows(rno)
                txtpaperid.Text = .Item(0)
                txtmcq.Text = .Item(2)
                txtfbq.Text = .Item(3)
                txttruefalse.Text = .Item(4)
                cmbexamname.Text = .Item(1)
                txthourse.Text = .Item(5)
                txtminute.Text = .Item(6)
            End With

        Catch ex As IndexOutOfRangeException



        End Try

    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click

    End Sub


    Private Sub btnadd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd1.Click
        btnsave1.Visible = True
        Try

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim pacm As New OleDbCommand("create table exampaper ([paperid] INTEGER primary key,[examid] INTEGER ,[mcqquestion] INTEGER,[fbqQuestion] INTEGER,[truequestion]  INTEGER,phourse INTEGER,pminute INTEGER)", con)
            pacm.ExecuteNonQuery()
            MsgBox("table create")

            Dim pacma As New OleDbCommand("ALTER TABLE [exampaper] ADD FOREIGN KEY (examid) REFERENCES cexammaster(examid)", con)
            MsgBox("table alter")
            con.Close()

        Catch ex As Exception
            txtpaperid.Clear()
            txtmcq.Clear()
            txtfbq.Clear()
            txttruefalse.Clear()



        End Try



    End Sub

    Private Sub btnsave1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave1.Click
        Try

      


        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim pacm1 As New OleDbCommand("insert into exampaper values('" & txtpaperid.Text & "','" & examid & "','" & txtmcq.Text & "','" & txtfbq.Text & "','" & txttruefalse.Text & "','" & txthourse.Text & "','" & txtminute.Text & "')", con)
        pacm1.ExecuteNonQuery()

        Call frmsetpaper_Load()
        dgpaperinformation.Update()

        con.Close()
        n = 0
        Call paperid(n)


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btndelete1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete1.Click

        Try

            If con.State = ConnectionState.Closed Then
                con.Open()
            End If

            Dim de As Byte
            de = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "ok")
            If de = 1 Then
                ds.Tables("exampaper").Rows(n).Delete()
                da.Update(ds, "exampaper")
                Dim deletequetionlistcm As New OleDbCommand("delete *from quesionpaperlist where paparid=" & txtpaperid.Text, con)
                deletequetionlistcm.ExecuteNonQuery()
                MsgBox("delete")
                con.Close()

            Else
                MsgBox("ok")
                con.Close()
            End If
            n = 0
            Call paperid(n)

            dgpaperinformation.Update()


        Catch ex As RowNotInTableException
            MsgBox("row not found")


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btnnext1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext1.Click

        Try


       
            If n < ds.Tables("exampaper").Rows.Count - 1 Then
                n = n + 1
                Call paperid(n)
            Else
                MsgBox("last paper")

            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnupdate1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate1.Click

        Try

     

        ds.Tables("exampaper").Rows(n).Item(0) = txtpaperid.Text
        ds.Tables("exampaper").Rows(n).Item(5) = txthourse.Text
        ds.Tables("exampaper").Rows(n).Item(6) = txtminute.Text
        ds.Tables("exampaper").Rows(n).Item(2) = txtmcq.Text
        ds.Tables("exampaper").Rows(n).Item(3) = txtfbq.Text

        ds.Tables("exampaper").Rows(n).Item(4) = txttruefalse.Text

        da.Update(ds, "exampaper")
        MsgBox("record update")
        Call paperid(n)
        dgpaperinformation.Update()
        Catch ex As Exception
            MsgBox("not sure")
        End Try
    End Sub

    Private Sub gbaddpaper_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gbaddpaper.Enter

    End Sub

    Private Sub cmbpaerid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbpaerid.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

    Private Sub cmbpaerid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbpaerid.SelectedIndexChanged
        Try

       
        cmbbookname.Items.Clear()



        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim examidcm2 As New OleDbCommand("select examid from exampaper where paperid like '" & cmbpaerid.Text & "'", con)
        Dim examiddr2 As OleDbDataReader
        examiddr2 = examidcm2.ExecuteReader
        While examiddr2.Read
            examname = examiddr2.Item(0)
        End While




        Dim bookcm1 As New OleDbCommand("select  bookname from bookmaster where examid =" & examname, con)
        Dim bookdr1 As OleDbDataReader
        bookdr1 = bookcm1.ExecuteReader
        While bookdr1.Read
            cmbbookname.Items.Add(bookdr1.Item(0))

        End While

        con.Close()
      

        Catch ex As Exception
            MsgBox("sorry book or exam not fount")
        End Try



    End Sub

    Private Sub rbmcq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbmcq.CheckedChanged
        Try

            If rbmcq.Checked Then


                dgquestion.Rows.Clear()
                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If
                'Dim mcqquestioncm As New OleDbCommand("select questions ,fans,sans,tans,foans,cans from mcq where subjectid= " & bookid, con)
                'Dim mcqquestiondr As OleDbDataReader
                'mcqquestiondr = mcqquestioncm.ExecuteReader
                'While mcqquestiondr.Read

                '    dgquestion.Rows.Add(mcqquestiondr.Item(0), mcqquestiondr.Item(5), mcqquestiondr.Item(1), mcqquestiondr.Item(2), mcqquestiondr.Item(3), mcqquestiondr.Item(4))

                'End While

                Dim mcqquestioncm As New OleDbCommand("select QuestionID,questions ,fans,sans,tans,foans,cans from mcq where subjectid= " & bookid, con)
                Dim mcqquestiondr As OleDbDataReader
                mcqquestiondr = mcqquestioncm.ExecuteReader
                While mcqquestiondr.Read

                    dgquestion.Rows.Add(mcqquestiondr.Item(0), mcqquestiondr.Item(1), mcqquestiondr.Item(6), mcqquestiondr.Item(2), mcqquestiondr.Item(3), mcqquestiondr.Item(4), mcqquestiondr.Item(5))

                End While


            End If






        Catch ex As Exception

        End Try

    End Sub

    Private Sub rbmcq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbmcq.Click
        If rbmcq.Checked = True Then
            type = 1
            MsgBox("add")
        End If
    End Sub

    Private Sub rbfbq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbfbq.CheckedChanged

        Try

            If rbfbq.Checked Then

                dgquestion.Rows.Clear()
                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If
                Dim fbqquestioncm As New OleDbCommand("select  *from fbqt where subjectid=" & bookid, con)
                Dim fbqquestiondr As OleDbDataReader
                fbqquestiondr = fbqquestioncm.ExecuteReader
                While fbqquestiondr.Read

                    dgquestion.Rows.Add(fbqquestiondr.Item(0), fbqquestiondr.Item(2), fbqquestiondr.Item(3), "-", "-", "-", "-")

                End While
                con.Close()


            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub rbfbq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbfbq.Click
        If rbfbq.Checked = True Then
            type = 2
        End If
    End Sub

    Private Sub rbtruefalse_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtruefalse.CheckedChanged
        Try

            If rbtruefalse.Checked Then


                dgquestion.Rows.Clear()
                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If

                Dim truequestioncm As New OleDbCommand("select  *from truefalse  where subjectid=" & bookid, con)
                Dim truequestiondr As OleDbDataReader
                truequestiondr = truequestioncm.ExecuteReader
                While truequestiondr.Read

                    dgquestion.Rows.Add(truequestiondr.Item(0), truequestiondr.Item(2), truequestiondr.Item(3), "true", "false", "-", "-")

                End While
                con.Close()



            End If


        Catch ex As Exception

        End Try



    End Sub

    Private Sub rbtruefalse_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtruefalse.Click
        If rbtruefalse.Checked = True Then
            type = 3

        End If
    End Sub

    Private Sub cmbbookname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbbookname.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

    Private Sub cmbsubject_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbbookname.SelectedIndexChanged
        Try

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            rbfbq.Checked = False
            rbmcq.Checked = False
            rbtruefalse.Checked = False

            Dim bookidcm As New OleDbCommand("select bookid from bookmaster where bookname like'" & cmbbookname.Text & "'", con)
            Dim bookiddr As OleDbDataReader
            bookiddr = bookidcm.ExecuteReader
            While bookiddr.Read
                bookid = bookiddr.Item(0)

            End While
            con.Close()

            'MsgBox(bookid)


        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmbexamname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbexamname.SelectedIndexChanged
        Call examid1()

    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim crpqcm As New OleDbCommand("create table quesionpaperlist (paparid INTEGER ,questiontype INTEGER,Questionid INTEGER ,Answer varchar,opt1 varchar default 0,opt2 varchar default 0 ,opt3 varchar default 0 ,opt4 varchar default 0)", con)
            crpqcm.ExecuteNonQuery()


            Dim crpqcm1 As New OleDbCommand("ALTER TABLE [quesionpaperlist] ADD FOREIGN KEY (paparid) REFERENCES exampapar(paperid)", con)
            MsgBox("table alter")
            con.Close()









line:














            If con.State = ConnectionState.Closed Then
                con.Open()
            End If

            Dim mcqlimit, fbqlimit, truelimit As Byte
            Dim limitcm As New OleDbCommand("select *from exampaper where paperid=" & cmbpaerid.Text, con)
            Dim limitdr As OleDbDataReader
            limitdr = limitcm.ExecuteReader
            While limitdr.Read

                mcqlimit = limitdr.Item(2)
                fbqlimit = limitdr.Item(3)
                truelimit = limitdr.Item(4)

            End While
            con.Close()


            Dim inserted As Integer = 0
vr:
            For Each row As DataGridViewRow In dgquestion.Rows
                Dim isSelected As Boolean = Convert.ToBoolean(row.Cells("checkedboxco").Value = True)










                If isSelected Then

                    If con.State = ConnectionState.Closed Then
                        con.Open()
                    End If
                    ' chack dublication question or not

                    Dim checmdqcm As New OleDbCommand("select *from quesionpaperlist where paparid=" & txtpaperid.Text, con)
                    Dim checkdqdr As OleDbDataReader
                    checkdqdr = checmdqcm.ExecuteReader
                    While checkdqdr.Read

                        If checkdqdr.Item(1) = type And checkdqdr.Item(2) = row.Cells("Questionid").Value Then
                            MsgBox(" row is allredy present hence remove thise row" & inserted + 1 & " no rows")
                            dgquestion.Rows(inserted).Cells(7).Value = False

                            inserted = inserted + 1

                            GoTo vr

                        End If


                    End While
                    con.Close()




                    If type = 1 Then


                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If


                        Dim noquestion As Byte
                        Dim checkquecm As New OleDbCommand("select count(questiontype) from quesionpaperlist where questiontype=" & type & " and paparid=" & cmbpaerid.Text, con)
                        noquestion = checkquecm.ExecuteScalar()




                        If mcqlimit = noquestion Then
                            MsgBox("sorry you cross the limit plase modify a paperset")
                            Exit For

                        End If



                        Dim insertcm As New OleDbCommand("insert into  quesionpaperlist  values(paparid,questiontype,Questionid,Answer,opt1,opt2,opt3,opt4)", con)
                        insertcm.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        insertcm.Parameters.AddWithValue("questiontype", type)
                        insertcm.Parameters.AddWithValue("Questionid", row.Cells("Questionid").Value)
                        insertcm.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)
                        insertcm.Parameters.AddWithValue("opt1", row.Cells("option1").Value)
                        insertcm.Parameters.AddWithValue("opt2", row.Cells("option2").Value)
                        insertcm.Parameters.AddWithValue("opt3", row.Cells("optino3").Value)
                        insertcm.Parameters.AddWithValue("opt4", row.Cells("option4").Value)

                        insertcm.ExecuteNonQuery()




                        Dim questionno As Byte
                        Dim mcqdacm As New OleDbCommand("select questionno from mcqdata", con)
                        Dim mcqdadr As OleDbDataReader
                        mcqdadr = mcqdacm.ExecuteReader
                        While mcqdadr.Read
                            questionno = mcqdadr.Item(0)

                        End While
                        MsgBox(questionno)





                        Dim mcqinsertcm As New OleDbCommand("insert into mcqdata values(questionno,paparid,Questionid,Answer,opt1,opt2,opt3,opt4)", con)

                        mcqinsertcm.Parameters.AddWithValue("questionno", questionno + 1)
                        mcqinsertcm.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        mcqinsertcm.Parameters.AddWithValue("Questionid", row.Cells("Questionid").Value)
                        mcqinsertcm.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)
                        mcqinsertcm.Parameters.AddWithValue("opt1", row.Cells("option1").Value)
                        mcqinsertcm.Parameters.AddWithValue("opt2", row.Cells("option2").Value)
                        mcqinsertcm.Parameters.AddWithValue("opt3", row.Cells("optino3").Value)
                        mcqinsertcm.Parameters.AddWithValue("opt4", row.Cells("option4").Value)

                        mcqinsertcm.ExecuteNonQuery()

                        MsgBox("add")




                        inserted = inserted + 1
                        con.Close()
                    ElseIf type = 2 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If

                        Dim noquestionfbq As Byte
                        Dim checkquecm As New OleDbCommand("select count(questiontype) from quesionpaperlist where questiontype=" & type & " and paparid=" & cmbpaerid.Text, con)
                        noquestionfbq = checkquecm.ExecuteScalar()




                        If fbqlimit = noquestionfbq Then
                            MsgBox("sorry you cross the limit plase modify a paperset")
                            Exit For

                        End If



                        Dim questionno1 As Byte
                        Dim fbqdacm As New OleDbCommand("select questionno from fbqdata", con)
                        Dim fbqdadr As OleDbDataReader
                        fbqdadr = fbqdacm.ExecuteReader
                        While fbqdadr.Read
                            questionno1 = fbqdadr.Item(0)

                        End While
                        MsgBox(questionno1)




                        Dim insertcm2 As New OleDbCommand("insert into quesionpaperlist  values(paperid ,questiontype,Questionid,Answer,opt1,opt2,opt3,opt4)", con)
                        insertcm2.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        insertcm2.Parameters.AddWithValue("questiontype", type)
                        insertcm2.Parameters.AddWithValue("Questionid", row.Cells("Questionid").Value)
                        insertcm2.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)

                        insertcm2.Parameters.AddWithValue("opt1", row.Cells("option1").Value)
                        insertcm2.Parameters.AddWithValue("opt2", row.Cells("option2").Value)
                        insertcm2.Parameters.AddWithValue("opt3", row.Cells("optino3").Value)
                        insertcm2.Parameters.AddWithValue("opt4", row.Cells("option4").Value)

                        insertcm2.ExecuteNonQuery()



                        Dim fbqinsertcm As New OleDbCommand("insert into fbqdata values(questionno,paparid,Questionid,Answer)", con)

                        fbqinsertcm.Parameters.AddWithValue("questionno", questionno1 + 1)
                        fbqinsertcm.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        fbqinsertcm.Parameters.AddWithValue("Questionid", row.Cells("Questionid").Value)
                        fbqinsertcm.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)

                        fbqinsertcm.ExecuteNonQuery()

                        MsgBox("add")







                        inserted = inserted + 1
                        con.Close()

                    ElseIf type = 3 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If
                        Dim noquestiontrue As Byte
                        Dim checkquecm As New OleDbCommand("select count(questiontype) from quesionpaperlist where questiontype=" & type & " and paparid=" & cmbpaerid.Text, con)
                        noquestiontrue = checkquecm.ExecuteScalar()




                        If truelimit = noquestiontrue Then
                            MsgBox("sorry you cross the limit plase modify a paperset")
                            Exit For

                        End If


                        Dim questionno2 As Byte
                        Dim truedacm As New OleDbCommand("select questionno from truedata", con)
                        Dim truedadr As OleDbDataReader
                        truedadr = truedacm.ExecuteReader
                        While truedadr.Read
                            questionno2 = truedadr.Item(0)

                        End While
                        MsgBox(questionno2)




                        Dim insertcm3 As New OleDbCommand("insert into quesionpaperlist values(paperid,questiontype,Questionid,Answer,opt1,opt2,opt3,opt4)", con)
                        insertcm3.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        insertcm3.Parameters.AddWithValue("questiontype", type)
                        insertcm3.Parameters.AddWithValue("Questionid", row.Cells("Questionid").Value)
                        insertcm3.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)

                        insertcm3.Parameters.AddWithValue("opt1", row.Cells("option1").Value)
                        insertcm3.Parameters.AddWithValue("opt2", row.Cells("option2").Value)
                        insertcm3.Parameters.AddWithValue("opt3", row.Cells("optino3").Value)
                        insertcm3.Parameters.AddWithValue("opt4", row.Cells("option4").Value)

                        insertcm3.ExecuteNonQuery()
                        inserted = inserted + 1



                        Dim trueinsertcm As New OleDbCommand("insert into truedata values(questionno,paparid,Questionid,Answer)", con)

                        trueinsertcm.Parameters.AddWithValue("questionno", questionno2 + 1)
                        trueinsertcm.Parameters.AddWithValue("paparid", cmbpaerid.Text)
                        trueinsertcm.Parameters.AddWithValue("Questionid", row.Cells("Questionid").Value)
                        trueinsertcm.Parameters.AddWithValue("Answer", row.Cells("Answer").Value)

                        trueinsertcm.ExecuteNonQuery()

                        MsgBox("add")




                        con.Close()

                    End If





                End If

            Next




        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")




        Catch ex As Exception
            GoTo line
        End Try




    End Sub

    



    Private Sub dgquestion_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgquestion.CellContentClick

    End Sub

    Private Sub dgquestion_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgquestion.CellMouseClick

    End Sub

    Private Sub gbquestiontype_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gbquestiontype.Enter

    End Sub

    Private Sub btnseequestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnseequestion.Click

    End Sub

    Private Sub frmsetpaper_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        cmbexamname.Items.Clear()
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim excm As New OleDbCommand("select  examname from cexammaster", con)
        Dim exdr As OleDbDataReader
        exdr = excm.ExecuteReader
        While exdr.Read
            cmbexamname.Items.Add(exdr.Item(0))

        End While
        con.Close()

        btnsave1.Visible = False
        cmbpaerid.Items.Clear()



        da.Fill(ds, "exampaper")
        cmb = New OleDbCommandBuilder(da)
        da.MissingSchemaAction = MissingSchemaAction.AddWithKey
        n = 0
        Call paperid(n)
        dgpaperinformation.DataSource = ds.Tables("exampaper")




        'insert a paperid in cmbpaperid
        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim apicm As New OleDbCommand("select *from exampaper", con)
        Dim apidr As OleDbDataReader
        apidr = apicm.ExecuteReader
        While apidr.Read
            cmbpaerid.Items.Add(apidr.Item(0))
        End While
        con.Close()






      
    End Sub

    Private Sub txthourse_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txthourse.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txthourse_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txthourse.TextChanged

    End Sub

    Private Sub txtminute_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtminute.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txtminute_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtminute.TextChanged

    End Sub

    Private Sub txtmcq_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtmcq.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txtmcq_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtmcq.TextChanged

    End Sub

    Private Sub txtfbq_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtfbq.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txtfbq_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtfbq.TextChanged

    End Sub

    Private Sub txttruefalse_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttruefalse.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txttruefalse_SystemColorsChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txttruefalse.SystemColorsChanged

    End Sub

    Private Sub txttruefalse_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttruefalse.TextChanged

    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click


        Try
            Dim inserted As Integer = 0

            For Each row As DataGridViewRow In dgquestion.Rows
                Dim isSelected As Boolean = Convert.ToBoolean(row.Cells("checkedboxco").Value = True)










                If isSelected Then

                    If con.State = ConnectionState.Closed Then
                        con.Open()
                    End If
                    If type = 1 Then


                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If


                        Dim insertcm2 As New OleDbCommand("delete *from quesionpaperlist where questiontype= " & type & "and Questionid=" & row.Cells("Questionid").Value, con)

                        insertcm2.ExecuteNonQuery()
                        MsgBox("delete")
                        inserted = inserted + 1
                        con.Close()

                    ElseIf type = 2 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If


                        Dim insertcm2 As New OleDbCommand("delete *from quesionpaperlist where questiontype= " & type & "and Questionid=" & row.Cells("Questionid").Value, con)
                        insertcm2.ExecuteNonQuery()
                        MsgBox("delete")
                        inserted = inserted + 1
                        con.Close()

                    ElseIf type = 3 Then
                        If con.State = ConnectionState.Closed Then
                            con.Open()

                        End If
                        Dim insertcm3 As New OleDbCommand("delete *from quesionpaperlist where questiontype= " & type & "and Questionid=" & row.Cells("Questionid").Value, con)
                        insertcm3.ExecuteNonQuery()
                        inserted = inserted + 1
                        MsgBox("delete")
                        con.Close()

                    End If





                End If

            Next




      


        Catch ex As Exception

        End Try

    End Sub
End Class