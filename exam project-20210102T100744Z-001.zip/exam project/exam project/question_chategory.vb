﻿Imports System.Data.OleDb
Public Class question_chategory
    Dim da As New OleDbDataAdapter("select *from questioncategory", con)

    Dim questionid As Byte




    Private Sub question_chategory_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            panquecat.Enabled = False
      
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "questioncategory")
            cmb = New OleDbCommandBuilder(da)
            n = ds.Tables("questioncategory").Rows.Count - 1

            Call questioncategory(n)
            dgquestioncategory.DataSource = ds.Tables("questioncategory")

            'add items in cmbquestioncategory
            txtquestionid.Enabled = False

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try


    End Sub
    Private Sub questioncategory(ByVal q1 As Byte)
        With ds.Tables("questioncategory").Rows(q1)

            txtquestionid.Text = .Item(0)
            txtquestioncat.Text = .Item(1)
        End With
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        txtquestionid.Clear()
        txtquestioncat.Clear()
    End Sub

   

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

      
            If n < ds.Tables("questioncategory").Rows.Count Then
                n = n + 1

                Call questioncategory(n)
            Else
                MsgBox("last record")

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        Try

       
            n = 0
            Call questioncategory(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        n = ds.Tables("questioncategory").Rows.Count - 1
        Call questioncategory(n)

    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click

        Try

       
            If n > 0 Then
                n = n - 1
                Call questioncategory(n)
            Else
                MsgBox("last record")

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

       
            Dim r As DataRow
            r = ds.Tables("questioncategory").NewRow
            r.Item(0) = txtquestionid.Text
            r.Item(1) = txtquestioncat.Text
            ds.Tables("questioncategory").Rows.Add(r)
            da.Update(ds, "questioncategory")
            MsgBox("record save")

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex2 As ConstraintException
            MsgBox("not allowed same id")

        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))

       

      

        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click

        Try

            Dim d As Byte

            d = Convert.ToByte(MsgBox("are you sure ", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure"))

            If d = 1 Then
                ds.Tables("questioncategory").Rows(n).Delete()
                da.Update(ds, "questioncategory")
                MsgBox("record delete")

            Else
                MsgBox("thanks")

            End If
            n = 0

            Call questioncategory(n)

        Catch ex As RowNotInTableException
            MsgBox("record is not found")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

       
            a = 0
            ds.Tables("questioncategory").Rows(n).Item(1) = txtquestioncat.Text

            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure")
            If a = 1 Then
                da.Update(ds, "questioncategory")
                MsgBox("record updated")
            Else
                MsgBox("ok thanks")

            End If
            n = 0
            Call questioncategory(n)

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click

        Try
            panquecat.Enabled = True
            Dim eno As New Integer
            dgquestioncat.Rows.Clear()
            eno = InputBox("enter the questionid ")
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim quecm4 As New OleDbCommand("select *from questioncategory where questionid=" & eno, con)
            Dim quedr4 As OleDbDataReader
            quedr4 = quecm4.ExecuteReader
            While quedr4.Read
                dgquestioncat.Rows.Add(quedr4.Item(0), quedr4.Item(1))

            End While
            con.Close()

        Catch ex As InvalidCastException


            MsgBox("enter the number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")


        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub dgquestioncategory_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgquestioncategory.CellContentClick

    End Sub

    Private Sub txtquestionid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtquestionid.TextChanged

    End Sub

    Private Sub txtquestioncat_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtquestioncat.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")

        End If
    End Sub

    Private Sub txtquestioncat_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtquestioncat.TextChanged

    End Sub
End Class