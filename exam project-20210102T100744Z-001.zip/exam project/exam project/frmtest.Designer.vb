﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmtest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtexamid = New System.Windows.Forms.TextBox()
        Me.txtpassword = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.gbexamlogin = New System.Windows.Forms.GroupBox()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnlogin = New System.Windows.Forms.Button()
        Me.panmcq = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblsecond = New System.Windows.Forms.Label()
        Me.lblhourse = New System.Windows.Forms.Label()
        Me.lblminute = New System.Windows.Forms.Label()
        Me.lblquestiontype = New System.Windows.Forms.Label()
        Me.txtanswer = New System.Windows.Forms.TextBox()
        Me.lblsans = New System.Windows.Forms.Label()
        Me.lblans = New System.Windows.Forms.Label()
        Me.lblquestionid = New System.Windows.Forms.Label()
        Me.btncancel1 = New System.Windows.Forms.Button()
        Me.btnsubmmit = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnpexamrevious = New System.Windows.Forms.Button()
        Me.btnexamnext = New System.Windows.Forms.Button()
        Me.rb4 = New System.Windows.Forms.RadioButton()
        Me.rb3 = New System.Windows.Forms.RadioButton()
        Me.rb2 = New System.Windows.Forms.RadioButton()
        Me.rb1 = New System.Windows.Forms.RadioButton()
        Me.lblquestion = New System.Windows.Forms.Label()
        Me.Panexamcontrol = New System.Windows.Forms.Panel()
        Me.lblanswer = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.gbexamlogin.SuspendLayout()
        Me.panmcq.SuspendLayout()
        Me.Panexamcontrol.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtexamid
        '
        Me.txtexamid.Location = New System.Drawing.Point(121, 19)
        Me.txtexamid.Name = "txtexamid"
        Me.txtexamid.Size = New System.Drawing.Size(166, 20)
        Me.txtexamid.TabIndex = 1
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(121, 59)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(166, 20)
        Me.txtpassword.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(30, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Examid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Exam password"
        '
        'gbexamlogin
        '
        Me.gbexamlogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gbexamlogin.Controls.Add(Me.btncancel)
        Me.gbexamlogin.Controls.Add(Me.btnlogin)
        Me.gbexamlogin.Controls.Add(Me.txtexamid)
        Me.gbexamlogin.Controls.Add(Me.Label2)
        Me.gbexamlogin.Controls.Add(Me.txtpassword)
        Me.gbexamlogin.Controls.Add(Me.Label1)
        Me.gbexamlogin.Location = New System.Drawing.Point(147, 12)
        Me.gbexamlogin.Name = "gbexamlogin"
        Me.gbexamlogin.Size = New System.Drawing.Size(355, 133)
        Me.gbexamlogin.TabIndex = 5
        Me.gbexamlogin.TabStop = False
        Me.gbexamlogin.Text = "login"
        '
        'btncancel
        '
        Me.btncancel.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(222, 110)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(75, 23)
        Me.btncancel.TabIndex = 7
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'btnlogin
        '
        Me.btnlogin.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlogin.Location = New System.Drawing.Point(90, 104)
        Me.btnlogin.Name = "btnlogin"
        Me.btnlogin.Size = New System.Drawing.Size(75, 23)
        Me.btnlogin.TabIndex = 6
        Me.btnlogin.Text = "login"
        Me.btnlogin.UseVisualStyleBackColor = False
        '
        'panmcq
        '
        Me.panmcq.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.panmcq.Controls.Add(Me.Label5)
        Me.panmcq.Controls.Add(Me.Label3)
        Me.panmcq.Controls.Add(Me.lblsecond)
        Me.panmcq.Controls.Add(Me.lblhourse)
        Me.panmcq.Controls.Add(Me.lblminute)
        Me.panmcq.Controls.Add(Me.lblquestiontype)
        Me.panmcq.Controls.Add(Me.txtanswer)
        Me.panmcq.Controls.Add(Me.lblsans)
        Me.panmcq.Controls.Add(Me.lblans)
        Me.panmcq.Controls.Add(Me.lblquestionid)
        Me.panmcq.Controls.Add(Me.btncancel1)
        Me.panmcq.Controls.Add(Me.btnsubmmit)
        Me.panmcq.Controls.Add(Me.Label4)
        Me.panmcq.Controls.Add(Me.btnpexamrevious)
        Me.panmcq.Controls.Add(Me.btnexamnext)
        Me.panmcq.Controls.Add(Me.rb4)
        Me.panmcq.Controls.Add(Me.rb3)
        Me.panmcq.Controls.Add(Me.rb2)
        Me.panmcq.Controls.Add(Me.rb1)
        Me.panmcq.Controls.Add(Me.lblquestion)
        Me.panmcq.Location = New System.Drawing.Point(12, 176)
        Me.panmcq.Name = "panmcq"
        Me.panmcq.Size = New System.Drawing.Size(894, 257)
        Me.panmcq.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(843, 25)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(10, 13)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = ":"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(811, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(10, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = ":"
        '
        'lblsecond
        '
        Me.lblsecond.AutoSize = True
        Me.lblsecond.Location = New System.Drawing.Point(853, 25)
        Me.lblsecond.Name = "lblsecond"
        Me.lblsecond.Size = New System.Drawing.Size(0, 13)
        Me.lblsecond.TabIndex = 21
        '
        'lblhourse
        '
        Me.lblhourse.AutoSize = True
        Me.lblhourse.Location = New System.Drawing.Point(786, 25)
        Me.lblhourse.Name = "lblhourse"
        Me.lblhourse.Size = New System.Drawing.Size(26, 13)
        Me.lblhourse.TabIndex = 20
        Me.lblhourse.Text = "time"
        '
        'lblminute
        '
        Me.lblminute.AutoSize = True
        Me.lblminute.Location = New System.Drawing.Point(821, 25)
        Me.lblminute.Name = "lblminute"
        Me.lblminute.Size = New System.Drawing.Size(26, 13)
        Me.lblminute.TabIndex = 19
        Me.lblminute.Text = "time"
        '
        'lblquestiontype
        '
        Me.lblquestiontype.AutoSize = True
        Me.lblquestiontype.Location = New System.Drawing.Point(35, 75)
        Me.lblquestiontype.Name = "lblquestiontype"
        Me.lblquestiontype.Size = New System.Drawing.Size(69, 13)
        Me.lblquestiontype.TabIndex = 18
        Me.lblquestiontype.Text = "Questiontype"
        '
        'txtanswer
        '
        Me.txtanswer.Location = New System.Drawing.Point(309, 105)
        Me.txtanswer.Name = "txtanswer"
        Me.txtanswer.Size = New System.Drawing.Size(84, 20)
        Me.txtanswer.TabIndex = 17
        '
        'lblsans
        '
        Me.lblsans.AutoSize = True
        Me.lblsans.Location = New System.Drawing.Point(269, 165)
        Me.lblsans.Name = "lblsans"
        Me.lblsans.Size = New System.Drawing.Size(54, 13)
        Me.lblsans.TabIndex = 16
        Me.lblsans.Text = "submitans"
        '
        'lblans
        '
        Me.lblans.AutoSize = True
        Me.lblans.Location = New System.Drawing.Point(393, 131)
        Me.lblans.Name = "lblans"
        Me.lblans.Size = New System.Drawing.Size(41, 13)
        Me.lblans.TabIndex = 15
        Me.lblans.Text = "answer"
        '
        'lblquestionid
        '
        Me.lblquestionid.AutoSize = True
        Me.lblquestionid.Location = New System.Drawing.Point(35, 48)
        Me.lblquestionid.Name = "lblquestionid"
        Me.lblquestionid.Size = New System.Drawing.Size(39, 13)
        Me.lblquestionid.TabIndex = 14
        Me.lblquestionid.Text = "Label4"
        '
        'btncancel1
        '
        Me.btncancel1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btncancel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncancel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel1.Location = New System.Drawing.Point(709, 221)
        Me.btncancel1.Name = "btncancel1"
        Me.btncancel1.Size = New System.Drawing.Size(128, 23)
        Me.btncancel1.TabIndex = 12
        Me.btncancel1.Text = "submit exam"
        Me.btncancel1.UseVisualStyleBackColor = False
        '
        'btnsubmmit
        '
        Me.btnsubmmit.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnsubmmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsubmmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubmmit.Location = New System.Drawing.Point(564, 221)
        Me.btnsubmmit.Name = "btnsubmmit"
        Me.btnsubmmit.Size = New System.Drawing.Size(75, 23)
        Me.btnsubmmit.TabIndex = 13
        Me.btnsubmmit.Text = "Submit"
        Me.btnsubmmit.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(9, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(161, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Solve the Question"
        '
        'btnpexamrevious
        '
        Me.btnpexamrevious.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnpexamrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpexamrevious.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpexamrevious.Location = New System.Drawing.Point(135, 221)
        Me.btnpexamrevious.Name = "btnpexamrevious"
        Me.btnpexamrevious.Size = New System.Drawing.Size(75, 23)
        Me.btnpexamrevious.TabIndex = 6
        Me.btnpexamrevious.Text = "<"
        Me.btnpexamrevious.UseVisualStyleBackColor = False
        '
        'btnexamnext
        '
        Me.btnexamnext.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnexamnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnexamnext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexamnext.Location = New System.Drawing.Point(357, 221)
        Me.btnexamnext.Name = "btnexamnext"
        Me.btnexamnext.Size = New System.Drawing.Size(75, 23)
        Me.btnexamnext.TabIndex = 7
        Me.btnexamnext.Text = ">"
        Me.btnexamnext.UseVisualStyleBackColor = False
        '
        'rb4
        '
        Me.rb4.AutoSize = True
        Me.rb4.BackColor = System.Drawing.Color.Thistle
        Me.rb4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb4.Location = New System.Drawing.Point(80, 175)
        Me.rb4.Name = "rb4"
        Me.rb4.Size = New System.Drawing.Size(112, 19)
        Me.rb4.TabIndex = 4
        Me.rb4.TabStop = True
        Me.rb4.Text = "RadioButton4"
        Me.rb4.UseVisualStyleBackColor = False
        '
        'rb3
        '
        Me.rb3.AutoSize = True
        Me.rb3.BackColor = System.Drawing.Color.Thistle
        Me.rb3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb3.Location = New System.Drawing.Point(80, 141)
        Me.rb3.Name = "rb3"
        Me.rb3.Size = New System.Drawing.Size(112, 19)
        Me.rb3.TabIndex = 3
        Me.rb3.TabStop = True
        Me.rb3.Text = "RadioButton3"
        Me.rb3.UseVisualStyleBackColor = False
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.BackColor = System.Drawing.Color.Thistle
        Me.rb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb2.Location = New System.Drawing.Point(80, 114)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(112, 19)
        Me.rb2.TabIndex = 2
        Me.rb2.TabStop = True
        Me.rb2.Text = "RadioButton2"
        Me.rb2.UseVisualStyleBackColor = False
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.BackColor = System.Drawing.Color.Thistle
        Me.rb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb1.Location = New System.Drawing.Point(80, 91)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(112, 19)
        Me.rb1.TabIndex = 1
        Me.rb1.TabStop = True
        Me.rb1.Text = "RadioButton1"
        Me.rb1.UseVisualStyleBackColor = False
        '
        'lblquestion
        '
        Me.lblquestion.AutoSize = True
        Me.lblquestion.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblquestion.Location = New System.Drawing.Point(89, 48)
        Me.lblquestion.Name = "lblquestion"
        Me.lblquestion.Size = New System.Drawing.Size(49, 15)
        Me.lblquestion.TabIndex = 0
        Me.lblquestion.Text = "Label4"
        '
        'Panexamcontrol
        '
        Me.Panexamcontrol.Controls.Add(Me.lblanswer)
        Me.Panexamcontrol.Location = New System.Drawing.Point(12, 429)
        Me.Panexamcontrol.Name = "Panexamcontrol"
        Me.Panexamcontrol.Size = New System.Drawing.Size(853, 39)
        Me.Panexamcontrol.TabIndex = 16
        '
        'lblanswer
        '
        Me.lblanswer.AutoSize = True
        Me.lblanswer.Location = New System.Drawing.Point(900, 0)
        Me.lblanswer.Name = "lblanswer"
        Me.lblanswer.Size = New System.Drawing.Size(39, 13)
        Me.lblanswer.TabIndex = 14
        Me.lblanswer.Text = "Label7"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 10
        '
        'frmtest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(906, 480)
        Me.Controls.Add(Me.Panexamcontrol)
        Me.Controls.Add(Me.panmcq)
        Me.Controls.Add(Me.gbexamlogin)
        Me.Name = "frmtest"
        Me.Text = "frmtest"
        Me.gbexamlogin.ResumeLayout(False)
        Me.gbexamlogin.PerformLayout()
        Me.panmcq.ResumeLayout(False)
        Me.panmcq.PerformLayout()
        Me.Panexamcontrol.ResumeLayout(False)
        Me.Panexamcontrol.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txtexamid As System.Windows.Forms.TextBox
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents gbexamlogin As System.Windows.Forms.GroupBox
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnlogin As System.Windows.Forms.Button
    Friend WithEvents panmcq As System.Windows.Forms.Panel
    Friend WithEvents lblquestionid As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents rb4 As System.Windows.Forms.RadioButton
    Friend WithEvents rb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents lblquestion As System.Windows.Forms.Label
    Friend WithEvents Panexamcontrol As System.Windows.Forms.Panel
    Friend WithEvents lblanswer As System.Windows.Forms.Label
    Friend WithEvents btnsubmmit As System.Windows.Forms.Button
    Friend WithEvents btnpexamrevious As System.Windows.Forms.Button
    Friend WithEvents btncancel1 As System.Windows.Forms.Button
    Friend WithEvents btnexamnext As System.Windows.Forms.Button
    Friend WithEvents lblans As System.Windows.Forms.Label
    Friend WithEvents lblsans As System.Windows.Forms.Label
    Friend WithEvents txtanswer As System.Windows.Forms.TextBox
    Friend WithEvents lblquestiontype As System.Windows.Forms.Label
    Friend WithEvents lblminute As System.Windows.Forms.Label
    Friend WithEvents lblsecond As System.Windows.Forms.Label
    Friend WithEvents lblhourse As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
End Class
