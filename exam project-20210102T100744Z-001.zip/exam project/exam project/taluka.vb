﻿Imports System.Data.OleDb
Public Class taluka
    Dim da As New OleDbDataAdapter("select *from taluka", con)

    Private Sub taluka_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            pantaluka.Enabled = False
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "taluka")
            n = ds.Tables("taluka").Rows.Count - 1

            cmb = New OleDbCommandBuilder(da)
            Call taluka(n)

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If


            Dim talukacm3 As New OleDbCommand("select distname from dist", con)
            Dim talukadr3 As OleDbDataReader
            talukadr3 = talukacm3.ExecuteReader
            While talukadr3.Read
                cmbdistname.Items.Add(talukadr3.Item(0))


            End While

            dgtaluka.DataSource = ds.Tables("taluka")
            con.Close()


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Private Sub taluka(ByVal t1 As Byte)
        Try

            With ds.Tables("taluka").Rows(t1)
                txttalukaid.Text = .Item(0)
                cmbdistname.Text = .Item(1)
                txttalukaname.Text = .Item(2)

            End With

        
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        If n < ds.Tables("taluka").Rows.Count - 1 Then
            n = n + 1
            Call taluka(n)
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            pantaluka.Enabled = False
            dgsearch.Rows.Clear()
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim eno As Byte

            eno = InputBox("enter the taluka id")

            Dim talukacm4 As New OleDbCommand("select *from taluka where talukaid=" & eno, con)
            Dim talukada4 As OleDbDataReader
            talukada4 = talukacm4.ExecuteReader
            While talukada4.Read
                dgsearch.Rows.Add(talukada4.Item(0), talukada4.Item(1), talukada4.Item(2))

            End While
        Catch ex As InvalidCastException
            MsgBox("enter number")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        n = 0
        Call taluka(n)
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

       
            Dim r As DataRow
            r = ds.Tables("taluk").NewRow
            r.Item(0) = txttalukaname.Text
            r.Item(1) = cmbdistname.Text
            ds.Tables("taluka").Rows.Add(r)
            da.Update(ds, "taluka")
            MsgBox("record save")

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim distcm3 As New OleDbCommand("select *from taluka", con)
            Dim distdr3 As OleDbDataReader
            distdr3 = distcm3.ExecuteReader
            While distdr3.Read
                txttalukaid.Text = distdr3.Item(0) + 1

            End While
            con.Close()
            txttalukaname.Clear()
            cmbdistname.Text = ""
        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))
        End Try

    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try

       
            Dim t4 As Integer
            t4 = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure")
            If t4 = 1 Then
                ds.Tables("taluka").Rows(n).Delete()
                da.Update(ds, "taluka")
                MsgBox("record delete")

            Else
                MsgBox("ok")

            End If
        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))
        End Try

    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        n = ds.Tables("taluka").Rows.Count - 1
        Call taluka(n)
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

            ds.Tables("taluka").Rows(n).Item(1) = txttalukaname.Text
            ds.Tables("taluka").Rows(n).Item(2) = cmbdistname.Text
            da.Update(ds, "taluka")
            MsgBox("record updated")

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))
        End Try

    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click
        Try

       
            If n > 0 Then


                n = n - 1
                Call taluka(n)
            End If
        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))
        End Try

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub txttalukaname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttalukaname.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")
        End If
    End Sub

    Private Sub txttalukaname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttalukaname.TextChanged

    End Sub

    Private Sub cmbdistname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdistname.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Or Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

    Private Sub cmbdistname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdistname.SelectedIndexChanged

    End Sub

    Private Sub cmbdistname_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdistname.SelectedValueChanged

    End Sub
End Class