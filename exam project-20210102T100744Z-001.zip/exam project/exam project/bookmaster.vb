﻿Imports System.Data.OleDb

Public Class bookmaster
    Dim examid As Integer
    Dim publicationid As Integer
    Dim da As New OleDbDataAdapter("Select *from bookmaster", con)


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try



            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "bookmaster")
            cmb = New OleDbCommandBuilder(da)
            n = ds.Tables("bookmaster").Rows.Count - 1

            Call book(n)
            txtsubid.Enabled = False

            DataGridView1.DataSource = ds.Tables("bookmaster")
            btnsave.Enabled = False


            con.Open()  'connection open

            'retrive examnames

            'retrive publication name

            Call publicationname()
            Call examname()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Public Sub book(ByVal su1 As Byte)
        Try


            With ds.Tables("bookmaster").Rows(su1)
                txtsubid.Text = .Item(0)
                txtsubname.Text = .Item(1)
                cmbexamid.Text = .Item(2)
                cmbpublication.Text = .Item(3)


            End With
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
   
    Public Sub publicationname()
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()   'connection open

            End If
          
            Dim subjectpublicationcm As New OleDbCommand("select publicationname from publicationmaster ", con)
            Dim subjectpublicationdr As OleDbDataReader
            subjectpublicationdr = subjectpublicationcm.ExecuteReader
            While subjectpublicationdr.Read
                cmbpublication.Items.Add(subjectpublicationdr.Item(0))

            End While
            con.Close()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Try


            txtsubid.Enabled = False
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim bookcm1 As New OleDbCommand("select *from bookmaster", con)
            Dim bookdr1 As OleDbDataReader
            bookdr1 = bookcm1.ExecuteReader
            While bookdr1.Read
                txtsubid.Text = bookdr1.Item(0) + 1

            End While
            con.Close()

            txtsubname.Clear()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If txtsubname.Text = "" Then

        Else
            btnsave.Enabled = True

        End If

        Try


            Dim r As DataRow
            r = ds.Tables("bookmaster").NewRow
            r.Item(0) = Convert.ToInt32(Val(txtsubid.Text))
            r.Item(1) = Convert.ToString(txtsubname.Text)


            r.Item(2) = examid

            r.Item(3) = publicationid



            ds.Tables("bookmaster").Rows.Add(r)
            da.Update(ds, "bookmaster")
            MsgBox("save")
            n = txtsubid.Text
            Call book(n)
            DataGridView1.Update()

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex3 As ConstraintException
            MsgBox("not allowed same id")

        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))

        End Try



    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try


            ds.Tables("bookmaster").Rows(n).Item(1) = txtsubname.Text
            ds.Tables("bookmaster").Rows(n).Item(2) = examid
            ds.Tables("bookmaster").Rows(n).Item(3) = cmbpublication.Text

            da.Update(ds, "bookmaster")
            n = txtsubid.Text
            Call book(n)
            DataGridView1.Update()

            MsgBox("record updated")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Try



            Dim a As Byte
            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configuration")

            If a = 1 Then
                ds.Tables("bookmaster").Rows(n).Delete()

                da.Update(ds, "bookmaster")
                MsgBox("delete row")
                n = 1



                Call book(n)

            Else
                Call book(n)


            End If

        Catch ex As RowNotInTableException
            MsgBox("row is not available")


        End Try

    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click

        Try


            If n < ds.Tables("bookmaster").Rows.Count - 1 Then
                n = n + 1
                Call book(n)
            Else
                MsgBox("last record")

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub



    Private Sub txtsubid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsubid.KeyPress


    End Sub

    Private Sub txtsubid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsubid.TextChanged

    End Sub

    Private Sub txtsubname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsubname.KeyPress
        btnsave.Enabled = True


    End Sub

    Private Sub txtsubname_RegionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtsubname.RegionChanged

    End Sub

    Private Sub txtsubname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsubname.TextChanged

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Dim eno As Byte
        Dim r As DataRow

        Try


            eno = InputBox("enter the id")
            r = ds.Tables("bookmaster").Rows.Find(eno)
            If r Is Nothing Then

            Else
                txtsubid.Text = r.Item(0)
                txtsubname.Text = r.Item(1)
                cmbexamid.Text = r.Item(2)

                cmbpublication.Text = r.Item(3)
            End If

        Catch ex As InvalidCastException


            MsgBox("enter the number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex1 As OverflowException
            MsgBox("sorry your no is high")

        End Try
    End Sub

    Private Sub DataGridView1_AllowUserToDeleteRowsChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.AllowUserToDeleteRowsChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim r As Integer
        r = DataGridView1.CurrentRow.Index
        txtsubid.Text = DataGridView1.Item(0, r).Value
        txtsubname.Text = DataGridView1.Item(1, r).Value

        cmbpublication.Text = DataGridView1.Item(3, r).Value



    End Sub



    Private Sub cmbpublication_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbpublication.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub





    Private Sub cmbpublication_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbpublication.SelectedIndexChanged
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()
            End If

            Dim publicationcm1 As New OleDbCommand("select publisherID from publicationmaster where  publicationname like '" & cmbpublication.Text & "'", con)
            Dim publicationdr1 As OleDbDataReader
            publicationdr1 = publicationcm1.ExecuteReader
            While publicationdr1.Read
                publicationid = publicationdr1.Item(0)

            End While
            con.Close()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub



   

  


   

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub cmbexamid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbexamid.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

    Private Sub cmbexamid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbexamid.SelectedIndexChanged
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim subjectexamcm2 As New OleDbCommand("select  examid from cexammaster where examname like '" & Trim(cmbexamid.Text) & "'", con)
        Dim subjectexamdr2 As OleDbDataReader
        subjectexamdr2 = subjectexamcm2.ExecuteReader
        While subjectexamdr2.Read
            examid = subjectexamdr2.Item(0)

        End While
        con.Close()
    End Sub

    Public Sub examname()
        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim subjectexamidcm As New OleDbCommand("select examname from cexammaster", con)
        Dim subjectexamdr As OleDbDataReader
        subjectexamdr = subjectexamidcm.ExecuteReader
        While subjectexamdr.Read
            cmbexamid.Items.Add(subjectexamdr.Item(0))

        End While
        con.Close() 'connection close

    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        n = 0
        Call book(n)
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class
