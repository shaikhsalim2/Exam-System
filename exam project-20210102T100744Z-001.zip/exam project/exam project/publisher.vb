﻿Imports System.Data.OleDb
Public Class publisher
    Dim da As New OleDbDataAdapter("select *from publicationmaster", con)
    Dim examid As Integer
    Private Sub publisher_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            panpublisher.Enabled = False
        
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "publicationmaster")
            cmb = New OleDbCommandBuilder(da)
            n = ds.Tables("publicatinonmaster").Rows.Count - 1

            Call publication(n)
            dgpublication.DataSource = ds.Tables("publicationmaster")

            Dim cm As New OleDbCommand("select examname from cexammaster", con)
            Dim dr As OleDbDataReader


            con.Open()

            dr = cm.ExecuteReader
            While dr.Read


            End While
            con.Close()

            txtpublisherid.Enabled = False
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub
    Public Sub publication(ByVal p1 As Byte)
        Try


            With ds.Tables("publicationmaster").Rows(p1)
                txtpublisherid.Text = .Item(0)
                txtpublishername.Text = .Item(1)


            End With
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

        
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim publicationcm1 As New OleDbCommand("select *from publicationmaster", con)
            Dim publicationda1 As OleDbDataReader
            publicationda1 = publicationcm1.ExecuteReader
            While publicationda1.Read
                txtpublisherid.Text = publicationda1.Item(0)

            End While
            txtpublishername.Clear()
            con.Close()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try


            If txtpublishername.Text = "" Then
                btnsave.Enabled = False

            End If
            Dim r As DataRow
            r = ds.Tables("publicationmaster").NewRow
            r.Item(0) = Val(txtpublisherid.Text)
            r.Item(1) = txtpublishername.Text
            r.Item(2) = examid
            ds.Tables("publicationmaster").Rows.Add(r)
            da.Update(ds, "publicationmaster")
            MsgBox("record save")
            dgpublication.Update()

        Catch ex As ConstraintException
            MsgBox("not allowd same id")

        Catch ex2 As InvalidCastException
            MsgBox("ok")
        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex2 As Exception
            MsgBox(Convert.ToString(ex2))



        End Try

       

    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try

    
            ds.Tables("publicationmaster").Rows(n).Item(1) = txtpublishername.Text

            da.Update(ds, "publicationmaster")
            dgpublication.Update()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click

        Try


            a = 0
            a = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "ok")
            If a = 1 Then
                ds.Tables("publicationmaster").Rows(n).Delete()
                da.Update(ds, "publicationmaster")
                MsgBox("delete")
                dgpublication.Update()

            Else
                MsgBox("ok")

            End If
        Catch ex As OutOfMemoryException
            MsgBox("record not found")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try

    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

            If n < ds.Tables("publicationmaster").Rows.Count - 1 Then
                n = n + 1
                Call publication(n)
            Else
                MsgBox("last record")

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click
        Try

      
            If n > 0 Then
                n = n - 1
                Call publication(n)

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub dgpublication_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgpublication.CellContentClick
        Dim r As Integer
        r = dgpublication.CurrentRow.Index
        txtpublisherid.Text = dgpublication.Item(0, r).Value
        txtpublishername.Text = dgpublication.Item(1, r).Value



    End Sub

 



   

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        Try
            n = 0
            Call publication(n)

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))

        End Try
    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click

        Try

            n = ds.Tables("publicationmaster").Rows.Count - 1
            Call publication(n)
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            panpublisher.Enabled = True
            dgpubli.Rows.Clear()

            Dim eno As Integer
            eno = InputBox("enter publicationid")
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim publicationcm As New OleDbCommand("select *from publicationmaster where publisherid=" & eno, con)
            Dim publicationda As OleDbDataReader
            publicationda = publicationcm.ExecuteReader
            While publicationda.Read
                dgpubli.Rows.Add(publicationda.Item(0), publicationda.Item(1))
            End While



        Catch ex As InvalidCastException
            MsgBox("enter only number")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex2 As OverflowException
            MsgBox("sorry your no is high")


        End Try
    End Sub

    Private Sub txtpublishername_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpublishername.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")

        End If
    End Sub

    Private Sub txtpublishername_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpublishername.TextChanged

    End Sub
End Class