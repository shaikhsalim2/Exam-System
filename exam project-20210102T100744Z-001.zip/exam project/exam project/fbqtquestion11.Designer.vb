﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fbqtquestion11
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.marks1 = New exam_project.marks()
        Me.fbqtquestion1 = New exam_project.fbqtquestion()
        Me.fbqtquestionwithbook1 = New exam_project.fbqtquestionwithbook()
        Me.mcqquestion1 = New exam_project.mcqquestion()
        Me.mcqquestionwithexamname1 = New exam_project.mcqquestionwithexamname()
        Me.mcqquestionwithquestioncategory1 = New exam_project.mcqquestionwithquestioncategory()
        Me.examiddetails1 = New exam_project.examiddetails()
        Me.examiddetailswith1 = New exam_project.examiddetailswith()
        Me.fbqtquestionwithexamname1 = New exam_project.fbqtquestionwithexamname()
        Me.mcqquestionwithbook1 = New exam_project.mcqquestionwithbook()
        Me.studentinf1 = New exam_project.studentinf()
        Me.fbqquestioninexam1 = New exam_project.fbqquestioninexam()
        Me.fbqquestioninexamwithpaperid1 = New exam_project.fbqquestioninexamwithpaperid()
        Me.truefalsequestioninexam1 = New exam_project.truefalsequestioninexam()
        Me.mcqquestioninexamwithpaperid1 = New exam_project.mcqquestioninexamwithpaperid()
        Me.truefalsequestioninexamwithpaperid1 = New exam_project.truefalsequestioninexamwithpaperid()
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.mcqquestioninexamwithpaperid2 = New exam_project.mcqquestioninexamwithpaperid()
        Me.mcqquestioninexam2 = New exam_project.mcqquestioninexam()
        Me.fbqstudsolvequestioninexam1 = New exam_project.fbqstudsolvequestioninexam()
        Me.studsolvequestion1 = New exam_project.studsolvequestion()
        Me.mcqquestioninexam1 = New exam_project.mcqquestioninexam()
        Me.SuspendLayout()
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = 0
        Me.CrystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CrystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default
        Me.CrystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.ReportSource = Me.fbqquestioninexamwithpaperid1
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(936, 415)
        Me.CrystalReportViewer1.TabIndex = 0
        '
        'fbqtquestion11
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(936, 415)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Name = "fbqtquestion11"
        Me.Text = "fbqtquestion11"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents fbqtquestion1 As exam_project.fbqtquestion
    Friend WithEvents fbqtquestionwithbook1 As exam_project.fbqtquestionwithbook
    Friend WithEvents fbqtquestionwithexamname1 As exam_project.fbqtquestionwithexamname
    Friend WithEvents mcqquestion1 As exam_project.mcqquestion
    Friend WithEvents mcqquestionwithbook1 As exam_project.mcqquestionwithbook
    Friend WithEvents mcqquestionwithexamname1 As exam_project.mcqquestionwithexamname
    Friend WithEvents mcqquestionwithquestioncategory1 As exam_project.mcqquestionwithquestioncategory
    Friend WithEvents studentinf1 As exam_project.studentinf
    Friend WithEvents examiddetails1 As exam_project.examiddetails
    Friend WithEvents examiddetailswith1 As exam_project.examiddetailswith
    Friend WithEvents marks1 As exam_project.marks
    Friend WithEvents mcqquestioninexam1 As exam_project.mcqquestioninexam
    Friend WithEvents mcqquestioninexamwithpaperid1 As exam_project.mcqquestioninexamwithpaperid
    Friend WithEvents fbqquestioninexam1 As exam_project.fbqquestioninexam
    Friend WithEvents fbqquestioninexamwithpaperid1 As exam_project.fbqquestioninexamwithpaperid
    Friend WithEvents truefalsequestioninexam1 As exam_project.truefalsequestioninexam
    Friend WithEvents truefalsequestioninexamwithpaperid1 As exam_project.truefalsequestioninexamwithpaperid
    Friend WithEvents studsolvequestion1 As exam_project.studsolvequestion
    Friend WithEvents fbqstudsolvequestioninexam1 As exam_project.fbqstudsolvequestioninexam
    Friend WithEvents mcqquestioninexam2 As exam_project.mcqquestioninexam
    Friend WithEvents mcqquestioninexamwithpaperid2 As exam_project.mcqquestioninexamwithpaperid
End Class
