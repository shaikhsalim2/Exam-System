﻿Imports System.Data.OleDb
Imports System.Windows.Forms.Control.ControlCollection


Public Class frmtest
    Dim n As Byte
    Dim marks As Byte
    Dim paperid22 As Byte
    Dim examid22 As Byte
    Dim registerno As Byte


    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        Try


            If con.State = ConnectionState.Closed Then
                con.Open()

            End If

            Dim examlogincm1 As New OleDbCommand("select * from examid", con)
            Dim examlogindr1 As OleDbDataReader
            examlogindr1 = examlogincm1.ExecuteReader
            While examlogindr1.Read

                If examlogindr1.Item(0) = txtexamid.Text And examlogindr1.Item(1) = txtpassword.Text Then
                    registerno = examlogindr1.Item(2)
                    gbexamlogin.Visible = False
                    txtexamid.Clear()
                    txtpassword.Clear()




                    'check user solve or not

                    Try
                        Dim checkcm As New OleDbCommand("select *from result where registerno=" & registerno, con)
                        Dim checkdr As OleDbDataReader
                        checkdr = checkcm.ExecuteReader
                        While checkdr.Read
                            MsgBox("sorry you sovle questionpaper")
                            panmcq.Visible = False
                            gbexamlogin.Visible = True
                            Exit Sub

                        End While

                    Catch ex As NoNullAllowedException
                        panmcq.Visible = True
                        panmcq.Top = 30
                        Exit Try
                    Catch ex1 As NullReferenceException
                        panmcq.Visible = True
                        panmcq.Top = 30
                        Exit Try
                    Catch ex2 As Exception
                        panmcq.Visible = True
                        panmcq.Top = 30
                        Exit Try


                    End Try



                    'examid and paperid,regiser

                    Dim examidcm22 As New OleDbCommand("select examid from studentregi where registerno=" & registerno, con)
                    Dim examiddr22 As OleDbDataReader
                    examiddr22 = examidcm22.ExecuteReader
                    While examiddr22.Read
                        examid22 = examiddr22.Item(0)

                    End While



                    Dim paperidcm1 As New OleDbCommand("select top 1   *from exampaper where examid=" & examid22 & " ORDER BY RND(paperid)", con)
                    Dim paperiddr1 As OleDbDataReader

                    paperiddr1 = paperidcm1.ExecuteReader

                    While paperiddr1.Read
                        paperid22 = paperiddr1.Item(0)

                    End While

                    If paperid22 = 0 Then
                        paperid22 = 1
                    End If
                    MsgBox(paperid22)

                    'access time
                    Dim timecm As New OleDbCommand("select phourse,pminute from exampaper where paperid=" & paperid22, con)
                    Dim timedr As OleDbDataReader
                    timedr = timecm.ExecuteReader
                    While timedr.Read
                        lblhourse.Text = timedr.Item(0)
                        lblminute.Text = timedr.Item(1)
                        lblsecond.Text = 60
                    End While



                    Call questionpaper()


                    Exit While


                                End If

            End While






        con.Close()

        Catch ex As Exception

        End Try




    End Sub


    Public Sub questionpaper()
        Try


            Call Timer1_Tick()
            panmcq.Visible = True
            panmcq.Top = 30
            Dim da As New OleDbDataAdapter("select *from quesionpaperlist where paparid=" & paperid22, con)
            cmb = New OleDbCommandBuilder
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "quesionpaperlist")

            n = 0
            Call questionlist(n)


        Catch ex As Exception
            MsgBox("mot allowed")
        End Try

    End Sub



    Public Sub questionlist(ByVal rno As Byte)

      
        Try

            lblquestiontype.Visible = False

            With ds.Tables("quesionpaperlist").Rows(rno)


                If con.State = ConnectionState.Closed Then
                    con.Open()

                End If
                lblquestiontype.Text = .Item(1)

                If .Item(1) = 1 Then


                    Dim changecm As New OleDbCommand("select Questions from mcq where Questionid=" & .Item(2), con)
                    Dim changedr As OleDbDataReader
                    changedr = changecm.ExecuteReader
                    While changedr.Read
                        lblquestion.Text = changedr.Item(0)

                    End While
                    con.Close()

                ElseIf .Item(1) = 2 Then
                    Dim changefbqcm As New OleDbCommand("select queestion from fbqt where questionid=" & .Item(2), con)
                    Dim changefbqdr As OleDbDataReader
                    changefbqdr = changefbqcm.ExecuteReader
                    While changefbqdr.Read
                        lblquestion.Text = changefbqdr.Item(0)
                    End While
                    con.Close()
                ElseIf .Item(1) = 3 Then
                    Dim changetruecm As New OleDbCommand("select question from truefalse where id=" & .Item(2), con)
                    Dim changetruedr As OleDbDataReader
                    changetruedr = changetruecm.ExecuteReader
                    While changetruedr.Read
                        lblquestion.Text = changetruedr.Item(0)
                    End While
                    con.Close()
                End If


                lblquestionid.Text = .Item(2)
                If .Item(4) = "-" And .Item(5) = "-" Then
                    rb1.Visible = False
                    rb2.Visible = False
                    txtanswer.Visible = True
                Else
                    rb1.Visible = True
                    rb2.Visible = True
                    rb1.Text = .Item(4).ToString
                    rb2.Text = .Item(5).ToString
                    txtanswer.Visible = False
                End If



                If .Item(6) = "-" And .Item(7) = "-" Then


                    rb3.Visible = False
                    rb4.Visible = False

                Else
                    rb3.Visible = True
                    rb3.Text = .Item(6)
                    rb4.Text = .Item(7)
                    rb4.Visible = True

                End If
                lblans.Text = .Item(3)
            End With


        Catch ex As OleDbException
            MsgBox("srry connection problam")
       
        Catch ex3 As NullReferenceException
            MsgBox("")
        Catch ex1 As Exception

        End Try

    End Sub

    


    Private Sub panmcq_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles panmcq.Paint

    End Sub

    Private Sub btnexamnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexamnext.Click







        If n < ds.Tables("quesionpaperlist").Rows.Count - 1 Then
            n = n + 1
            Call questionlist(n)
        Else
            MsgBox(" thanks finish a exam")

        End If
    End Sub

    Private Sub btnpexamrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpexamrevious.Click



        If n > 0 Then
            n = n - 1
            Call questionlist(n)
        Else

        End If
    End Sub

    Private Sub btnsubmmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsubmmit.Click
        Try


            Dim aa As Byte = 1



            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            If txtanswer.Text = "" Then

            Else
                lblsans.Text = txtanswer.Text
            End If



            'Dim studentexamcm As New OleDbCommand("create table studentquestion ([Register] INTEGER,[Quetionid] INTEGER,[questiontype] INTEGER , [currectAnswer] varchar,[submitanswer] varchar)", con)
            'studentexamcm.ExecuteNonQuery()
            'MsgBox("table cfeate")
            'con.Close()

line:
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim checkquetioncm As New OleDbCommand("select Quetionid,questiontype from studentquestion where Register=" & registerno, con)
            Dim checkquetiondr As OleDbDataReader
            checkquetiondr = checkquetioncm.ExecuteReader
            While checkquetiondr.Read
                If lblquestionid.Text = checkquetiondr.Item(0) And lblquestiontype.Text = checkquetiondr.Item(1) Then
                    aa = aa + 1
                    Exit While
                End If
            End While

            con.Close()
            If aa = 1 Then


                Call insert()
            Else
                MsgBox("you solve")
            End If

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")



        Catch ex As Exception
            GoTo line
        End Try



    End Sub
    Public Sub insert()
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If

        Dim insertquestioncm As New OleDbCommand("insert into studentquestion values('" & registerno & "','" & lblquestionid.Text & "','" & lblquestiontype.Text & "','" & lblans.Text & "','" & lblsans.Text & "')", con)
        insertquestioncm.ExecuteNonQuery()
        MsgBox("insert ")




        If lblquestiontype.Text = 1 Then

            Dim questionno As Byte
            Dim studda As New OleDbCommand("select questionno from studmcqdata", con)
            Dim studdr As OleDbDataReader
            studdr = studda.ExecuteReader
            While studdr.Read
                questionno = studdr.Item(0)

            End While
            MsgBox(questionno)
            Dim studmcqcm As New OleDbCommand("insert into studmcqdata values('" & questionno + 1 & "','" & registerno & "','" & lblquestionid.Text & "','" & lblans.Text & "','" & lblsans.Text & "')", con)
            studmcqcm.ExecuteNonQuery()
            MsgBox("add")
        ElseIf lblquestiontype.Text = 2 Then
            Dim questionno1 As Byte
            Dim studda As New OleDbCommand("select questionno from studfbqdata", con)
            Dim studdr As OleDbDataReader
            studdr = studda.ExecuteReader
            While studdr.Read
                questionno1 = studdr.Item(0)

            End While
            MsgBox(questionno1)


          


            Dim studfbqtcm As New OleDbCommand("insert into studfbqdata values('" & questionno1 + 1 & "','" & registerno & "','" & lblquestionid.Text & "','" & lblans.Text & "','" & lblsans.Text & "')", con)
            studfbqtcm.ExecuteNonQuery()
            MsgBox("add")
        ElseIf lblquestiontype.Text = 3 Then

            Dim questionno2 As Byte
            Dim studda As New OleDbCommand("select questionno from studtruedata", con)
            Dim studdr As OleDbDataReader
            studdr = studda.ExecuteReader
            While studdr.Read
                questionno2 = studdr.Item(0)

            End While
            MsgBox(questionno2)




            Dim studtruecm As New OleDbCommand("insert into studtruedata values('" & questionno2 + 1 & "','" & registerno & "','" & lblquestionid.Text & "','" & lblans.Text & "','" & lblsans.Text & "')", con)
            studtruecm.ExecuteNonQuery()
            MsgBox("add")
        End If






        con.Close()
    End Sub
    
    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblans.Click

    End Sub

    Private Sub rb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1.CheckedChanged
       
    End Sub

    Private Sub rb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2.CheckedChanged

    End Sub

    Private Sub rb1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb1.Click
        If rb1.Checked = True Then
            lblsans.Text = rb1.Text
        End If
    End Sub

    Private Sub rb2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb2.Click
        If rb2.Checked = True Then
            lblsans.Text = rb2.Text
        End If
    End Sub

    Private Sub rb3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb3.CheckedChanged

    End Sub

    Private Sub rb3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb3.Click
        If rb3.Checked = True Then
            lblsans.Text = rb3.Text
        End If
    End Sub

    Private Sub rb4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb4.CheckedChanged

    End Sub

    Private Sub rb4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb4.Click
        If rb4.Checked = True Then
            lblsans.Text = rb4.Text
        End If
    End Sub

    Private Sub btncancel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel1.Click
        Try
            marks = 0
            If con.State = ConnectionState.Closed Then
                con.Open()

            End If
            Dim questionrecm As New OleDbCommand("select * from studentquestion where Register=" & registerno, con)
            Dim questionredr As OleDbDataReader
            questionredr = questionrecm.ExecuteReader

            While questionredr.Read

                If questionredr.Item(3) = questionredr.Item(4) Then

                    marks = marks + 2

                End If
            End While

            Dim resultcm2 As New OleDbCommand("insert into result values('" & registerno & "','" & marks & "')", con)
            resultcm2.ExecuteNonQuery()
            MsgBox("marks add")





            ds.Tables("quesionpaperlist").Clear()
            panmcq.Visible = False
            gbexamlogin.Visible = True

        Catch ex As RowNotInTableException
            MsgBox("row not found")


        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub
    Private Sub frmtest_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed


    End Sub

    Private Sub frmtest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        panmcq.Visible = False
        lblquestiontype.Visible = False

        Dim txte As New TextBox
        Me.Controls.Add(txte)




        rb1.Visible = False
        rb2.Visible = False
        rb3.Visible = False
        rb4.Visible = False
        txtanswer.Visible = False

        lblsans.Visible = False
        lblans.Visible = False

        txtanswer.Visible = False
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtanswer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtanswer.TextChanged

    End Sub

    Private Sub lblquestionid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblquestionid.Click

    End Sub

    Private Sub Label3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblquestiontype.Click

    End Sub

    Private Sub Timer1_Tick() Handles Timer1.Tick
        lblsecond.Text = Val(lblsecond.Text) - 1

        If Val(lblsecond.Text) = 0 Then
            lblsecond.Text = 60
            lblminute.Text = Val(lblminute.Text) - 1
            If Val(lblminute.Text) = 0 Then


                If Val(lblhourse.Text) = 1 Then
                    lblminute.Text = 60
                    lblhourse.Text = 0
                Else
                    lblminute.Text = "00"
                    lblhourse.Text = "00"
                    lblsecond.Text = "00"
                    MsgBox("thanks time up")
                    ds.Tables("quesionpaperlist").Clear()
                    panmcq.Visible = False
                    gbexamlogin.Visible = True

                End If

            End If
        End If

    End Sub

    Private Sub lblminute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblminute.Click

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()

    End Sub
End Class