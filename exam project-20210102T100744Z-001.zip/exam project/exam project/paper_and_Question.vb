﻿Public Class paper_and_Question

    Private Sub rbmcq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbmcq.CheckedChanged

    End Sub
End Class