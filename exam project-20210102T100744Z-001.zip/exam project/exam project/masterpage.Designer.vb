﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class masterpage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.QuestionMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MCQToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FillingTheBlankToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrueFalseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuestionCategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TalukaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DIstToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetAPapersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SeeTheResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubjectMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExamMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PublicatioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistretionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacticleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GiveTheExamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CertifiactedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserAdmiinistretivToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UseraddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SIgnOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.QuestionMasterToolStripMenuItem, Me.BookMasterToolStripMenuItem, Me.StudentInformationToolStripMenuItem, Me.CertifiactedToolStripMenuItem, Me.UserAdmiinistretivToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(700, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'QuestionMasterToolStripMenuItem
        '
        Me.QuestionMasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MCQToolStripMenuItem, Me.FillingTheBlankToolStripMenuItem, Me.TrueFalseToolStripMenuItem, Me.QuestionCategoryToolStripMenuItem, Me.TalukaToolStripMenuItem, Me.DIstToolStripMenuItem, Me.SetAPapersToolStripMenuItem, Me.SeeTheResultToolStripMenuItem})
        Me.QuestionMasterToolStripMenuItem.Name = "QuestionMasterToolStripMenuItem"
        Me.QuestionMasterToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
        Me.QuestionMasterToolStripMenuItem.Text = "Master"
        '
        'MCQToolStripMenuItem
        '
        Me.MCQToolStripMenuItem.Name = "MCQToolStripMenuItem"
        Me.MCQToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.MCQToolStripMenuItem.Text = "MCQ"
        '
        'FillingTheBlankToolStripMenuItem
        '
        Me.FillingTheBlankToolStripMenuItem.Name = "FillingTheBlankToolStripMenuItem"
        Me.FillingTheBlankToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.FillingTheBlankToolStripMenuItem.Text = "Filling the Blank"
        '
        'TrueFalseToolStripMenuItem
        '
        Me.TrueFalseToolStripMenuItem.Name = "TrueFalseToolStripMenuItem"
        Me.TrueFalseToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.TrueFalseToolStripMenuItem.Text = "True False"
        '
        'QuestionCategoryToolStripMenuItem
        '
        Me.QuestionCategoryToolStripMenuItem.Name = "QuestionCategoryToolStripMenuItem"
        Me.QuestionCategoryToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.QuestionCategoryToolStripMenuItem.Text = "question category"
        '
        'TalukaToolStripMenuItem
        '
        Me.TalukaToolStripMenuItem.Name = "TalukaToolStripMenuItem"
        Me.TalukaToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.TalukaToolStripMenuItem.Text = "Taluka"
        '
        'DIstToolStripMenuItem
        '
        Me.DIstToolStripMenuItem.Name = "DIstToolStripMenuItem"
        Me.DIstToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.DIstToolStripMenuItem.Text = "DIst"
        '
        'SetAPapersToolStripMenuItem
        '
        Me.SetAPapersToolStripMenuItem.Name = "SetAPapersToolStripMenuItem"
        Me.SetAPapersToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.SetAPapersToolStripMenuItem.Text = "set a papers"
        '
        'SeeTheResultToolStripMenuItem
        '
        Me.SeeTheResultToolStripMenuItem.Name = "SeeTheResultToolStripMenuItem"
        Me.SeeTheResultToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.SeeTheResultToolStripMenuItem.Text = "see the result"
        '
        'BookMasterToolStripMenuItem
        '
        Me.BookMasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SubjectMasterToolStripMenuItem, Me.ExamMasterToolStripMenuItem, Me.PublicatioToolStripMenuItem})
        Me.BookMasterToolStripMenuItem.Name = "BookMasterToolStripMenuItem"
        Me.BookMasterToolStripMenuItem.Size = New System.Drawing.Size(85, 20)
        Me.BookMasterToolStripMenuItem.Text = "Book Master"
        '
        'SubjectMasterToolStripMenuItem
        '
        Me.SubjectMasterToolStripMenuItem.Name = "SubjectMasterToolStripMenuItem"
        Me.SubjectMasterToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.SubjectMasterToolStripMenuItem.Text = "book master"
        '
        'ExamMasterToolStripMenuItem
        '
        Me.ExamMasterToolStripMenuItem.Name = "ExamMasterToolStripMenuItem"
        Me.ExamMasterToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.ExamMasterToolStripMenuItem.Text = "Exam Master"
        '
        'PublicatioToolStripMenuItem
        '
        Me.PublicatioToolStripMenuItem.Name = "PublicatioToolStripMenuItem"
        Me.PublicatioToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.PublicatioToolStripMenuItem.Text = "Publicatio"
        '
        'StudentInformationToolStripMenuItem
        '
        Me.StudentInformationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistretionToolStripMenuItem, Me.PacticleToolStripMenuItem, Me.GiveTheExamToolStripMenuItem})
        Me.StudentInformationToolStripMenuItem.Name = "StudentInformationToolStripMenuItem"
        Me.StudentInformationToolStripMenuItem.Size = New System.Drawing.Size(126, 20)
        Me.StudentInformationToolStripMenuItem.Text = "Student Information"
        '
        'RegistretionToolStripMenuItem
        '
        Me.RegistretionToolStripMenuItem.Name = "RegistretionToolStripMenuItem"
        Me.RegistretionToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.RegistretionToolStripMenuItem.Text = "registretion"
        '
        'PacticleToolStripMenuItem
        '
        Me.PacticleToolStripMenuItem.Name = "PacticleToolStripMenuItem"
        Me.PacticleToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.PacticleToolStripMenuItem.Text = "pactical"
        '
        'GiveTheExamToolStripMenuItem
        '
        Me.GiveTheExamToolStripMenuItem.Name = "GiveTheExamToolStripMenuItem"
        Me.GiveTheExamToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.GiveTheExamToolStripMenuItem.Text = "give the exam"
        '
        'CertifiactedToolStripMenuItem
        '
        Me.CertifiactedToolStripMenuItem.Name = "CertifiactedToolStripMenuItem"
        Me.CertifiactedToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.CertifiactedToolStripMenuItem.Text = "Certifiacted"
        '
        'UserAdmiinistretivToolStripMenuItem
        '
        Me.UserAdmiinistretivToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UseraddToolStripMenuItem, Me.SIgnOUTToolStripMenuItem})
        Me.UserAdmiinistretivToolStripMenuItem.Name = "UserAdmiinistretivToolStripMenuItem"
        Me.UserAdmiinistretivToolStripMenuItem.Size = New System.Drawing.Size(123, 20)
        Me.UserAdmiinistretivToolStripMenuItem.Text = "User admiinistretive"
        '
        'UseraddToolStripMenuItem
        '
        Me.UseraddToolStripMenuItem.Name = "UseraddToolStripMenuItem"
        Me.UseraddToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.UseraddToolStripMenuItem.Text = "Useradd"
        '
        'SIgnOUTToolStripMenuItem
        '
        Me.SIgnOUTToolStripMenuItem.Name = "SIgnOUTToolStripMenuItem"
        Me.SIgnOUTToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.SIgnOUTToolStripMenuItem.Text = "SIgnOUT"
        '
        'masterpage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(700, 401)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "masterpage"
        Me.Text = "e"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents QuestionMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MCQToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FillingTheBlankToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TrueFalseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubjectMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExamMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PublicatioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CertifiactedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserAdmiinistretivToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UseraddToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SIgnOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuestionCategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegistretionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TalukaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DIstToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PacticleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetAPapersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GiveTheExamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SeeTheResultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
