﻿Imports System.Data.OleDb
Imports System.Windows.Forms.TextBox


Public Class frmresult

    Private Sub frmresult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load






       


        lblstudentname.Text = practical.txtusername.Text
        If Val(lblmark.Text) > 5 Then
            lblstatus.Text = "congratulatiooon you are pass"
        Else
            lblstatus.Text = "so sad try again"

        End If


      
    End Sub







End Class