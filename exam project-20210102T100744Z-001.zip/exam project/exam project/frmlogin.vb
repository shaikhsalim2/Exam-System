﻿Imports System.Data.OleDb
Public Class frmlogin

    Private Sub frmlogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnlogin.Enabled = False
    End Sub

    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        'login code
        con.Open()
        Dim cm As New OleDbCommand("select *from login", con)
        Dim logindr As OleDbDataReader
        logindr = cm.ExecuteReader

        While logindr.Read


            If logindr.Item(0) = txtusername.Text And logindr.Item(1) = txtpassword.Text Then
                frmuseradd.Show()
            Else
                MsgBox("password wrong")
                Me.Close()
            End If
        End While
        'clossing the datareader logindr
        logindr.Close()
        'closing the connection
        con.Close()

    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click

        Me.Close()

    End Sub

    Private Sub txtpassword_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpassword.KeyPress
        btnlogin.Enabled = True
    End Sub

    Private Sub txtpassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpassword.TextChanged

    End Sub
End Class