﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class paper_and_Question
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.gbquestiontype = New System.Windows.Forms.GroupBox()
        Me.rbtruefalse = New System.Windows.Forms.RadioButton()
        Me.rbfbq = New System.Windows.Forms.RadioButton()
        Me.rbmcq = New System.Windows.Forms.RadioButton()
        Me.dgpaperinformation = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.gbquestiontype.SuspendLayout()
        CType(Me.dgpaperinformation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(87, 24)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 0
        '
        'gbquestiontype
        '
        Me.gbquestiontype.Controls.Add(Me.rbtruefalse)
        Me.gbquestiontype.Controls.Add(Me.rbfbq)
        Me.gbquestiontype.Controls.Add(Me.rbmcq)
        Me.gbquestiontype.Location = New System.Drawing.Point(206, 12)
        Me.gbquestiontype.Name = "gbquestiontype"
        Me.gbquestiontype.Size = New System.Drawing.Size(560, 39)
        Me.gbquestiontype.TabIndex = 22
        Me.gbquestiontype.TabStop = False
        Me.gbquestiontype.Text = "choose the question type"
        '
        'rbtruefalse
        '
        Me.rbtruefalse.AutoSize = True
        Me.rbtruefalse.BackColor = System.Drawing.Color.Thistle
        Me.rbtruefalse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtruefalse.Location = New System.Drawing.Point(435, 19)
        Me.rbtruefalse.Name = "rbtruefalse"
        Me.rbtruefalse.Size = New System.Drawing.Size(93, 19)
        Me.rbtruefalse.TabIndex = 2
        Me.rbtruefalse.TabStop = True
        Me.rbtruefalse.Text = "True False"
        Me.rbtruefalse.UseVisualStyleBackColor = False
        '
        'rbfbq
        '
        Me.rbfbq.AutoSize = True
        Me.rbfbq.BackColor = System.Drawing.Color.Thistle
        Me.rbfbq.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbfbq.Location = New System.Drawing.Point(221, 16)
        Me.rbfbq.Name = "rbfbq"
        Me.rbfbq.Size = New System.Drawing.Size(52, 19)
        Me.rbfbq.TabIndex = 1
        Me.rbfbq.TabStop = True
        Me.rbfbq.Text = "FBQ"
        Me.rbfbq.UseVisualStyleBackColor = False
        '
        'rbmcq
        '
        Me.rbmcq.AutoSize = True
        Me.rbmcq.BackColor = System.Drawing.Color.Thistle
        Me.rbmcq.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbmcq.Location = New System.Drawing.Point(25, 21)
        Me.rbmcq.Name = "rbmcq"
        Me.rbmcq.Size = New System.Drawing.Size(52, 19)
        Me.rbmcq.TabIndex = 0
        Me.rbmcq.TabStop = True
        Me.rbmcq.Text = "mcq"
        Me.rbmcq.UseVisualStyleBackColor = False
        '
        'dgpaperinformation
        '
        Me.dgpaperinformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgpaperinformation.Location = New System.Drawing.Point(12, 85)
        Me.dgpaperinformation.Name = "dgpaperinformation"
        Me.dgpaperinformation.Size = New System.Drawing.Size(926, 397)
        Me.dgpaperinformation.TabIndex = 23
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 15)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "lblpaperid"
        '
        'paper_and_Question
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(931, 479)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgpaperinformation)
        Me.Controls.Add(Me.gbquestiontype)
        Me.Controls.Add(Me.ComboBox1)
        Me.Name = "paper_and_Question"
        Me.Text = "paper_and_Question"
        Me.gbquestiontype.ResumeLayout(False)
        Me.gbquestiontype.PerformLayout()
        CType(Me.dgpaperinformation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents gbquestiontype As System.Windows.Forms.GroupBox
    Friend WithEvents rbtruefalse As System.Windows.Forms.RadioButton
    Friend WithEvents rbfbq As System.Windows.Forms.RadioButton
    Friend WithEvents rbmcq As System.Windows.Forms.RadioButton
    Friend WithEvents dgpaperinformation As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
