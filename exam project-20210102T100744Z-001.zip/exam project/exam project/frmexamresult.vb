﻿Imports System.Data.OleDb
Public Class frmexamresult
    Dim resultda As New OleDbDataAdapter("select examresult *from", con)

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtmarks.TextChanged

    End Sub

    Private Sub frmexamresult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            resultda.Fill(ds, "examresult")
            cmb = New OleDbCommandBuilder(resultda)
            resultda.MissingSchemaAction = MissingSchemaAction.AddWithKey
            n = 0
            Call examresultdata(n)

        Catch ex As Exception
            MsgBox("ok")
        End Try
    End Sub

    Public Sub examresultdata(ByVal rno As Byte)
        Try

            With ds.Tables("examresult").Rows(rno)
                txtregisterno.Text = .Item(0)
                txttotalmarks.Text = .Item(1)
                txtmarks.Text = .Item(2)

            End With

        Catch ex As Exception
            MsgBox("ok")
        End Try

    End Sub

    Private Sub txtregisterno_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtregisterno.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txtregisterno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtregisterno.TextChanged
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If

        Dim regicm As New OleDbCommand("select firstname,secondname,lastname from studentregi where registerno=" & txtregisterno.Text, con)
        Dim regidr As OleDbDataReader
        regidr = regicm.ExecuteReader
        While regidr.Read
            txtfname.Text = regidr.Item(0)
            txtmname.Text = regidr.Item(1)
            txtlname.Text = regidr.Item(2)
        End While

        Dim questionrecm As New OleDbCommand("select * from studentquestion where Register=" & txtregisterno.Text, con)
        Dim questionredr As OleDbDataReader
        questionredr = questionrecm.ExecuteReader

        While questionredr.Read
            If questionredr.Item(2) = 1 Then

            Dim convertidcm As New OleDbCommand("select questions from mcq where questionid=" & questionredr.Item(1), con)
            Dim convertiddr As OleDbDataReader
            convertiddr = convertidcm.ExecuteReader
            While convertiddr.Read
                DataGridView1.Rows.Add(convertiddr.Item(0), questionredr.Item(3), questionredr.Item(4))

                End While

            ElseIf questionredr.Item(2) = 2 Then
                Dim convertidcm1 As New OleDbCommand("select queestion from fbqt where questionID=" & questionredr.Item(1), con)
                Dim convertiddr1 As OleDbDataReader
                convertiddr1 = convertidcm1.ExecuteReader
                While convertiddr1.Read
                    DataGridView1.Rows.Add(convertiddr1.Item(0), questionredr.Item(3), questionredr.Item(4))

                End While
            ElseIf questionredr.Item(2) = 3 Then
                Dim convertidcm3 As New OleDbCommand("select question from truefalse where id=" & questionredr.Item(1), con)
                Dim convertiddr3 As OleDbDataReader
                convertiddr3 = convertidcm3.ExecuteReader
                While convertiddr3.Read
                    DataGridView1.Rows.Add(convertiddr3.Item(0), questionredr.Item(3), questionredr.Item(4))

                End While


            End If


            If questionredr.Item(3) = questionredr.Item(4) Then

                txtmarks.Text = Val(txtmarks.Text) + 2

            End If

        End While


        con.Close()

        'Dim datagriedcm As New OleDbCommand("select currectAnswer,submitanswer from studentquestion where Register=" & txtregisterno.Text, con)





    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click

        '  Try






    End Sub
End Class