﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mcq
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.btnupdated = New System.Windows.Forms.Button()
        Me.btnnext = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtquestion = New System.Windows.Forms.TextBox()
        Me.txtquestionid = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.cmbsubjectid = New System.Windows.Forms.ComboBox()
        Me.dgmcq = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmbquestioncategory = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnlast = New System.Windows.Forms.Button()
        Me.labelcurrectanswer = New System.Windows.Forms.Label()
        Me.txtoption4 = New System.Windows.Forms.TextBox()
        Me.txtoption2 = New System.Windows.Forms.TextBox()
        Me.txtoption1 = New System.Windows.Forms.TextBox()
        Me.txtoption3 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtanswer = New System.Windows.Forms.TextBox()
        Me.rb4 = New System.Windows.Forms.RadioButton()
        Me.rb3 = New System.Windows.Forms.RadioButton()
        Me.rb2 = New System.Windows.Forms.RadioButton()
        Me.rb1 = New System.Windows.Forms.RadioButton()
        Me.btnfirst = New System.Windows.Forms.Button()
        CType(Me.dgmcq, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(44, 348)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 23)
        Me.btnadd.TabIndex = 10
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(544, 348)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 12
        Me.btnsave.Tag = "11"
        Me.btnsave.Text = "save"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'btnupdated
        '
        Me.btnupdated.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnupdated.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnupdated.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdated.Location = New System.Drawing.Point(47, 414)
        Me.btnupdated.Name = "btnupdated"
        Me.btnupdated.Size = New System.Drawing.Size(75, 23)
        Me.btnupdated.TabIndex = 13
        Me.btnupdated.Tag = "13"
        Me.btnupdated.Text = "update"
        Me.btnupdated.UseVisualStyleBackColor = False
        '
        'btnnext
        '
        Me.btnnext.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnnext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnext.Location = New System.Drawing.Point(298, 348)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(75, 23)
        Me.btnnext.TabIndex = 11
        Me.btnnext.Text = "Next"
        Me.btnnext.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(29, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "subid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Question"
        '
        'txtquestion
        '
        Me.txtquestion.BackColor = System.Drawing.SystemColors.Window
        Me.txtquestion.Location = New System.Drawing.Point(96, 82)
        Me.txtquestion.Multiline = True
        Me.txtquestion.Name = "txtquestion"
        Me.txtquestion.Size = New System.Drawing.Size(601, 73)
        Me.txtquestion.TabIndex = 4
        Me.txtquestion.Tag = ""
        '
        'txtquestionid
        '
        Me.txtquestionid.Location = New System.Drawing.Point(141, 39)
        Me.txtquestionid.Name = "txtquestionid"
        Me.txtquestionid.Size = New System.Drawing.Size(100, 20)
        Me.txtquestionid.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(16, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 16)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Questionid"
        '
        'btnsearch
        '
        Me.btnsearch.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearch.Location = New System.Drawing.Point(544, 414)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(75, 23)
        Me.btnsearch.TabIndex = 15
        Me.btnsearch.Tag = "14"
        Me.btnsearch.Text = "search"
        Me.btnsearch.UseVisualStyleBackColor = False
        '
        'Btndelete
        '
        Me.Btndelete.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btndelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btndelete.Location = New System.Drawing.Point(298, 414)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(75, 23)
        Me.Btndelete.TabIndex = 14
        Me.Btndelete.Tag = "13"
        Me.Btndelete.Text = "delete"
        Me.Btndelete.UseVisualStyleBackColor = False
        '
        'cmbsubjectid
        '
        Me.cmbsubjectid.DisplayMember = "subjectid"
        Me.cmbsubjectid.FormattingEnabled = True
        Me.cmbsubjectid.Location = New System.Drawing.Point(141, 2)
        Me.cmbsubjectid.Name = "cmbsubjectid"
        Me.cmbsubjectid.Size = New System.Drawing.Size(121, 21)
        Me.cmbsubjectid.TabIndex = 1
        Me.cmbsubjectid.ValueMember = "subjectid"
        '
        'dgmcq
        '
        Me.dgmcq.BackgroundColor = System.Drawing.Color.LavenderBlush
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgmcq.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgmcq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgmcq.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgmcq.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgmcq.Location = New System.Drawing.Point(47, 454)
        Me.dgmcq.Name = "dgmcq"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgmcq.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgmcq.Size = New System.Drawing.Size(821, 150)
        Me.dgmcq.TabIndex = 26
        '
        'Column1
        '
        Me.Column1.HeaderText = "Column1"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Column2"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Column3"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Column4"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "Column5"
        Me.Column5.Name = "Column5"
        '
        'Column6
        '
        Me.Column6.HeaderText = "Column6"
        Me.Column6.Name = "Column6"
        '
        'cmbquestioncategory
        '
        Me.cmbquestioncategory.FormattingEnabled = True
        Me.cmbquestioncategory.Location = New System.Drawing.Point(569, 6)
        Me.cmbquestioncategory.Name = "cmbquestioncategory"
        Me.cmbquestioncategory.Size = New System.Drawing.Size(128, 21)
        Me.cmbquestioncategory.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(370, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 16)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Question Category"
        '
        'btnlast
        '
        Me.btnlast.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnlast.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlast.Location = New System.Drawing.Point(431, 348)
        Me.btnlast.Name = "btnlast"
        Me.btnlast.Size = New System.Drawing.Size(75, 23)
        Me.btnlast.TabIndex = 29
        Me.btnlast.Text = "Last"
        Me.btnlast.UseVisualStyleBackColor = False
        '
        'labelcurrectanswer
        '
        Me.labelcurrectanswer.AutoSize = True
        Me.labelcurrectanswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelcurrectanswer.Location = New System.Drawing.Point(152, 129)
        Me.labelcurrectanswer.Name = "labelcurrectanswer"
        Me.labelcurrectanswer.Size = New System.Drawing.Size(111, 16)
        Me.labelcurrectanswer.TabIndex = 18
        Me.labelcurrectanswer.Text = "Currect Answer"
        '
        'txtoption4
        '
        Me.txtoption4.Location = New System.Drawing.Point(459, 72)
        Me.txtoption4.Multiline = True
        Me.txtoption4.Name = "txtoption4"
        Me.txtoption4.Size = New System.Drawing.Size(188, 45)
        Me.txtoption4.TabIndex = 8
        '
        'txtoption2
        '
        Me.txtoption2.Location = New System.Drawing.Point(459, 12)
        Me.txtoption2.Multiline = True
        Me.txtoption2.Name = "txtoption2"
        Me.txtoption2.Size = New System.Drawing.Size(188, 45)
        Me.txtoption2.TabIndex = 6
        '
        'txtoption1
        '
        Me.txtoption1.Location = New System.Drawing.Point(90, 18)
        Me.txtoption1.Multiline = True
        Me.txtoption1.Name = "txtoption1"
        Me.txtoption1.Size = New System.Drawing.Size(164, 40)
        Me.txtoption1.TabIndex = 5
        Me.txtoption1.Tag = "5"
        '
        'txtoption3
        '
        Me.txtoption3.Location = New System.Drawing.Point(90, 72)
        Me.txtoption3.Multiline = True
        Me.txtoption3.Name = "txtoption3"
        Me.txtoption3.Size = New System.Drawing.Size(164, 39)
        Me.txtoption3.TabIndex = 7
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtanswer)
        Me.Panel1.Controls.Add(Me.rb4)
        Me.Panel1.Controls.Add(Me.rb3)
        Me.Panel1.Controls.Add(Me.rb2)
        Me.Panel1.Controls.Add(Me.rb1)
        Me.Panel1.Controls.Add(Me.txtoption1)
        Me.Panel1.Controls.Add(Me.txtoption3)
        Me.Panel1.Controls.Add(Me.txtoption2)
        Me.Panel1.Controls.Add(Me.txtoption4)
        Me.Panel1.Controls.Add(Me.labelcurrectanswer)
        Me.Panel1.Location = New System.Drawing.Point(12, 161)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(692, 167)
        Me.Panel1.TabIndex = 30
        '
        'txtanswer
        '
        Me.txtanswer.Location = New System.Drawing.Point(269, 125)
        Me.txtanswer.Multiline = True
        Me.txtanswer.Name = "txtanswer"
        Me.txtanswer.Size = New System.Drawing.Size(164, 39)
        Me.txtanswer.TabIndex = 19
        '
        'rb4
        '
        Me.rb4.AutoSize = True
        Me.rb4.BackColor = System.Drawing.Color.Thistle
        Me.rb4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb4.Location = New System.Drawing.Point(354, 73)
        Me.rb4.Name = "rb4"
        Me.rb4.Size = New System.Drawing.Size(73, 17)
        Me.rb4.TabIndex = 12
        Me.rb4.TabStop = True
        Me.rb4.Text = "Option 4"
        Me.rb4.UseVisualStyleBackColor = False
        '
        'rb3
        '
        Me.rb3.AutoSize = True
        Me.rb3.BackColor = System.Drawing.Color.Thistle
        Me.rb3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb3.Location = New System.Drawing.Point(5, 89)
        Me.rb3.Name = "rb3"
        Me.rb3.Size = New System.Drawing.Size(79, 19)
        Me.rb3.TabIndex = 11
        Me.rb3.TabStop = True
        Me.rb3.Text = "Option 3"
        Me.rb3.UseVisualStyleBackColor = False
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.BackColor = System.Drawing.Color.Thistle
        Me.rb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb2.Location = New System.Drawing.Point(354, 18)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(79, 19)
        Me.rb2.TabIndex = 10
        Me.rb2.TabStop = True
        Me.rb2.Text = "Option 2"
        Me.rb2.UseVisualStyleBackColor = False
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.BackColor = System.Drawing.Color.Thistle
        Me.rb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb1.Location = New System.Drawing.Point(5, 31)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(79, 19)
        Me.rb1.TabIndex = 9
        Me.rb1.TabStop = True
        Me.rb1.Text = "Option 1"
        Me.rb1.UseVisualStyleBackColor = False
        '
        'btnfirst
        '
        Me.btnfirst.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnfirst.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnfirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfirst.Location = New System.Drawing.Point(431, 414)
        Me.btnfirst.Name = "btnfirst"
        Me.btnfirst.Size = New System.Drawing.Size(75, 23)
        Me.btnfirst.TabIndex = 31
        Me.btnfirst.Text = "First"
        Me.btnfirst.UseVisualStyleBackColor = False
        '
        'mcq
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(948, 626)
        Me.Controls.Add(Me.btnfirst)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnlast)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmbquestioncategory)
        Me.Controls.Add(Me.dgmcq)
        Me.Controls.Add(Me.cmbsubjectid)
        Me.Controls.Add(Me.Btndelete)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtquestionid)
        Me.Controls.Add(Me.txtquestion)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnnext)
        Me.Controls.Add(Me.btnupdated)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.btnadd)
        Me.Name = "mcq"
        Me.Text = "mcq"
        CType(Me.dgmcq, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnupdated As System.Windows.Forms.Button
    Friend WithEvents btnnext As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtquestion As System.Windows.Forms.TextBox
    Friend WithEvents txtquestionid As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents Btndelete As System.Windows.Forms.Button
    Friend WithEvents cmbsubjectid As System.Windows.Forms.ComboBox
    Friend WithEvents dgmcq As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmbquestioncategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnlast As System.Windows.Forms.Button
    Friend WithEvents labelcurrectanswer As System.Windows.Forms.Label
    Friend WithEvents txtoption4 As System.Windows.Forms.TextBox
    Friend WithEvents txtoption2 As System.Windows.Forms.TextBox
    Friend WithEvents txtoption1 As System.Windows.Forms.TextBox
    Friend WithEvents txtoption3 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents rb4 As System.Windows.Forms.RadioButton
    Friend WithEvents rb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents txtanswer As System.Windows.Forms.TextBox
    Friend WithEvents btnfirst As System.Windows.Forms.Button


End Class
