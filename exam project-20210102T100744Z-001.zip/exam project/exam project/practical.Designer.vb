﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class practical
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panchecked = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblinstruct = New System.Windows.Forms.Label()
        Me.rbtruefalse = New System.Windows.Forms.RadioButton()
        Me.rbfbq = New System.Windows.Forms.RadioButton()
        Me.rbmcq = New System.Windows.Forms.RadioButton()
        Me.panselect = New System.Windows.Forms.Panel()
        Me.lblcoosequestiontype = New System.Windows.Forms.Label()
        Me.lbllevel = New System.Windows.Forms.Label()
        Me.cmblavel = New System.Windows.Forms.ComboBox()
        Me.lblinstruct2 = New System.Windows.Forms.Label()
        Me.btnstart = New System.Windows.Forms.Button()
        Me.btnstartexam = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbquestioncat = New System.Windows.Forms.ComboBox()
        Me.cmbbook = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbcexamname = New System.Windows.Forms.ComboBox()
        Me.panpassword = New System.Windows.Forms.Panel()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnlogin = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtpassword = New System.Windows.Forms.TextBox()
        Me.txtusername = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnlast = New System.Windows.Forms.Button()
        Me.btnnext = New System.Windows.Forms.Button()
        Me.btnprevious = New System.Windows.Forms.Button()
        Me.btnfirst = New System.Windows.Forms.Button()
        Me.txtcorrectanswer = New System.Windows.Forms.TextBox()
        Me.btncamcel = New System.Windows.Forms.Button()
        Me.lblinformation = New System.Windows.Forms.Label()
        Me.lblquestion = New System.Windows.Forms.Label()
        Me.rb1 = New System.Windows.Forms.RadioButton()
        Me.rb2 = New System.Windows.Forms.RadioButton()
        Me.rb3 = New System.Windows.Forms.RadioButton()
        Me.rb4 = New System.Windows.Forms.RadioButton()
        Me.txtfillanswer = New System.Windows.Forms.TextBox()
        Me.panmcq = New System.Windows.Forms.Panel()
        Me.lblquestiontype = New System.Windows.Forms.Label()
        Me.lblquestionid = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panpractcontrol = New System.Windows.Forms.Panel()
        Me.btntest = New System.Windows.Forms.Button()
        Me.Panexamcontrol = New System.Windows.Forms.Panel()
        Me.btnresult = New System.Windows.Forms.Button()
        Me.lblanswer = New System.Windows.Forms.Label()
        Me.btnsubmmit = New System.Windows.Forms.Button()
        Me.btnpexamrevious = New System.Windows.Forms.Button()
        Me.btncancel1 = New System.Windows.Forms.Button()
        Me.btnexamnext = New System.Windows.Forms.Button()
        Me.panchecked.SuspendLayout()
        Me.panselect.SuspendLayout()
        Me.panpassword.SuspendLayout()
        Me.panmcq.SuspendLayout()
        Me.Panpractcontrol.SuspendLayout()
        Me.Panexamcontrol.SuspendLayout()
        Me.SuspendLayout()
        '
        'panchecked
        '
        Me.panchecked.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.panchecked.Controls.Add(Me.Button3)
        Me.panchecked.Controls.Add(Me.lblinstruct)
        Me.panchecked.Controls.Add(Me.rbtruefalse)
        Me.panchecked.Controls.Add(Me.rbfbq)
        Me.panchecked.Controls.Add(Me.rbmcq)
        Me.panchecked.Location = New System.Drawing.Point(7, 42)
        Me.panchecked.Name = "panchecked"
        Me.panchecked.Size = New System.Drawing.Size(963, 73)
        Me.panchecked.TabIndex = 0
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(754, 43)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(70, 30)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Cancel"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'lblinstruct
        '
        Me.lblinstruct.AutoSize = True
        Me.lblinstruct.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblinstruct.ForeColor = System.Drawing.Color.Black
        Me.lblinstruct.Location = New System.Drawing.Point(9, 0)
        Me.lblinstruct.Name = "lblinstruct"
        Me.lblinstruct.Size = New System.Drawing.Size(180, 20)
        Me.lblinstruct.TabIndex = 3
        Me.lblinstruct.Text = "Select Question Type"
        '
        'rbtruefalse
        '
        Me.rbtruefalse.AutoSize = True
        Me.rbtruefalse.BackColor = System.Drawing.Color.Thistle
        Me.rbtruefalse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtruefalse.Location = New System.Drawing.Point(560, 43)
        Me.rbtruefalse.Name = "rbtruefalse"
        Me.rbtruefalse.Size = New System.Drawing.Size(108, 19)
        Me.rbtruefalse.TabIndex = 2
        Me.rbtruefalse.TabStop = True
        Me.rbtruefalse.Text = "TRUE FALSE"
        Me.rbtruefalse.UseVisualStyleBackColor = False
        '
        'rbfbq
        '
        Me.rbfbq.AutoSize = True
        Me.rbfbq.BackColor = System.Drawing.Color.Thistle
        Me.rbfbq.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbfbq.Location = New System.Drawing.Point(301, 43)
        Me.rbfbq.Name = "rbfbq"
        Me.rbfbq.Size = New System.Drawing.Size(132, 19)
        Me.rbfbq.TabIndex = 1
        Me.rbfbq.TabStop = True
        Me.rbfbq.Text = "FILL THE BLANK"
        Me.rbfbq.UseVisualStyleBackColor = False
        '
        'rbmcq
        '
        Me.rbmcq.AutoSize = True
        Me.rbmcq.BackColor = System.Drawing.Color.Thistle
        Me.rbmcq.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbmcq.Location = New System.Drawing.Point(15, 43)
        Me.rbmcq.Name = "rbmcq"
        Me.rbmcq.Size = New System.Drawing.Size(56, 19)
        Me.rbmcq.TabIndex = 0
        Me.rbmcq.TabStop = True
        Me.rbmcq.Text = "MCQ"
        Me.rbmcq.UseVisualStyleBackColor = False
        '
        'panselect
        '
        Me.panselect.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.panselect.Controls.Add(Me.lblcoosequestiontype)
        Me.panselect.Controls.Add(Me.lbllevel)
        Me.panselect.Controls.Add(Me.cmblavel)
        Me.panselect.Controls.Add(Me.lblinstruct2)
        Me.panselect.Controls.Add(Me.btnstart)
        Me.panselect.Controls.Add(Me.btnstartexam)
        Me.panselect.Controls.Add(Me.Label3)
        Me.panselect.Controls.Add(Me.Label2)
        Me.panselect.Controls.Add(Me.cmbquestioncat)
        Me.panselect.Controls.Add(Me.cmbbook)
        Me.panselect.Controls.Add(Me.Label1)
        Me.panselect.Controls.Add(Me.cmbcexamname)
        Me.panselect.Location = New System.Drawing.Point(7, 121)
        Me.panselect.Name = "panselect"
        Me.panselect.Size = New System.Drawing.Size(963, 103)
        Me.panselect.TabIndex = 1
        '
        'lblcoosequestiontype
        '
        Me.lblcoosequestiontype.AutoSize = True
        Me.lblcoosequestiontype.Location = New System.Drawing.Point(813, 7)
        Me.lblcoosequestiontype.Name = "lblcoosequestiontype"
        Me.lblcoosequestiontype.Size = New System.Drawing.Size(126, 13)
        Me.lblcoosequestiontype.TabIndex = 18
        Me.lblcoosequestiontype.Text = "choose the question type"
        '
        'lbllevel
        '
        Me.lbllevel.AutoSize = True
        Me.lbllevel.Location = New System.Drawing.Point(531, 72)
        Me.lbllevel.Name = "lbllevel"
        Me.lbllevel.Size = New System.Drawing.Size(38, 13)
        Me.lbllevel.TabIndex = 17
        Me.lbllevel.Text = "Levels"
        '
        'cmblavel
        '
        Me.cmblavel.FormattingEnabled = True
        Me.cmblavel.Location = New System.Drawing.Point(671, 74)
        Me.cmblavel.Name = "cmblavel"
        Me.cmblavel.Size = New System.Drawing.Size(121, 21)
        Me.cmblavel.TabIndex = 16
        '
        'lblinstruct2
        '
        Me.lblinstruct2.AutoSize = True
        Me.lblinstruct2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblinstruct2.ForeColor = System.Drawing.Color.Black
        Me.lblinstruct2.Location = New System.Drawing.Point(3, 0)
        Me.lblinstruct2.Name = "lblinstruct2"
        Me.lblinstruct2.Size = New System.Drawing.Size(357, 20)
        Me.lblinstruct2.TabIndex = 8
        Me.lblinstruct2.Text = "Select Your Exam ,Book &Question Category"
        '
        'btnstart
        '
        Me.btnstart.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnstart.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnstart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstart.Location = New System.Drawing.Point(798, 45)
        Me.btnstart.Name = "btnstart"
        Me.btnstart.Size = New System.Drawing.Size(75, 23)
        Me.btnstart.TabIndex = 7
        Me.btnstart.Text = "Start"
        Me.btnstart.UseVisualStyleBackColor = False
        '
        'btnstartexam
        '
        Me.btnstartexam.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnstartexam.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnstartexam.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartexam.Location = New System.Drawing.Point(816, 72)
        Me.btnstartexam.Name = "btnstartexam"
        Me.btnstartexam.Size = New System.Drawing.Size(110, 23)
        Me.btnstartexam.TabIndex = 9
        Me.btnstartexam.Text = "Start exam"
        Me.btnstartexam.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(531, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "select Question category"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(275, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "select Book"
        '
        'cmbquestioncat
        '
        Me.cmbquestioncat.FormattingEnabled = True
        Me.cmbquestioncat.Location = New System.Drawing.Point(671, 45)
        Me.cmbquestioncat.Name = "cmbquestioncat"
        Me.cmbquestioncat.Size = New System.Drawing.Size(121, 21)
        Me.cmbquestioncat.TabIndex = 3
        '
        'cmbbook
        '
        Me.cmbbook.FormattingEnabled = True
        Me.cmbbook.Location = New System.Drawing.Point(389, 48)
        Me.cmbbook.Name = "cmbbook"
        Me.cmbbook.Size = New System.Drawing.Size(121, 21)
        Me.cmbbook.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "select CExam "
        '
        'cmbcexamname
        '
        Me.cmbcexamname.FormattingEnabled = True
        Me.cmbcexamname.Location = New System.Drawing.Point(105, 45)
        Me.cmbcexamname.Name = "cmbcexamname"
        Me.cmbcexamname.Size = New System.Drawing.Size(121, 21)
        Me.cmbcexamname.TabIndex = 0
        '
        'panpassword
        '
        Me.panpassword.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.panpassword.Controls.Add(Me.btncancel)
        Me.panpassword.Controls.Add(Me.btnlogin)
        Me.panpassword.Controls.Add(Me.Label6)
        Me.panpassword.Controls.Add(Me.Label5)
        Me.panpassword.Controls.Add(Me.txtpassword)
        Me.panpassword.Controls.Add(Me.txtusername)
        Me.panpassword.Location = New System.Drawing.Point(217, 4)
        Me.panpassword.Name = "panpassword"
        Me.panpassword.Size = New System.Drawing.Size(409, 100)
        Me.panpassword.TabIndex = 15
        '
        'btncancel
        '
        Me.btncancel.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(176, 66)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(113, 31)
        Me.btncancel.TabIndex = 7
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'btnlogin
        '
        Me.btnlogin.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlogin.Location = New System.Drawing.Point(28, 69)
        Me.btnlogin.Name = "btnlogin"
        Me.btnlogin.Size = New System.Drawing.Size(113, 31)
        Me.btnlogin.TabIndex = 6
        Me.btnlogin.Text = "Login"
        Me.btnlogin.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(23, 44)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "password"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 11)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "username"
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(110, 40)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(150, 20)
        Me.txtpassword.TabIndex = 1
        '
        'txtusername
        '
        Me.txtusername.Location = New System.Drawing.Point(110, 4)
        Me.txtusername.Name = "txtusername"
        Me.txtusername.Size = New System.Drawing.Size(150, 20)
        Me.txtusername.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(472, 64)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(147, 36)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "show answer"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(181, 70)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(147, 36)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "check answer"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btnlast
        '
        Me.btnlast.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnlast.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlast.Location = New System.Drawing.Point(575, 22)
        Me.btnlast.Name = "btnlast"
        Me.btnlast.Size = New System.Drawing.Size(75, 23)
        Me.btnlast.TabIndex = 8
        Me.btnlast.Text = ">>"
        Me.btnlast.UseVisualStyleBackColor = False
        '
        'btnnext
        '
        Me.btnnext.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnnext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnext.Location = New System.Drawing.Point(385, 22)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(75, 23)
        Me.btnnext.TabIndex = 7
        Me.btnnext.Text = ">"
        Me.btnnext.UseVisualStyleBackColor = False
        '
        'btnprevious
        '
        Me.btnprevious.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnprevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnprevious.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprevious.Location = New System.Drawing.Point(210, 22)
        Me.btnprevious.Name = "btnprevious"
        Me.btnprevious.Size = New System.Drawing.Size(75, 23)
        Me.btnprevious.TabIndex = 6
        Me.btnprevious.Text = "<"
        Me.btnprevious.UseVisualStyleBackColor = False
        '
        'btnfirst
        '
        Me.btnfirst.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnfirst.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnfirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfirst.Location = New System.Drawing.Point(80, 22)
        Me.btnfirst.Name = "btnfirst"
        Me.btnfirst.Size = New System.Drawing.Size(75, 23)
        Me.btnfirst.TabIndex = 5
        Me.btnfirst.Text = "<<"
        Me.btnfirst.UseVisualStyleBackColor = False
        '
        'txtcorrectanswer
        '
        Me.txtcorrectanswer.Location = New System.Drawing.Point(688, 73)
        Me.txtcorrectanswer.Name = "txtcorrectanswer"
        Me.txtcorrectanswer.Size = New System.Drawing.Size(94, 20)
        Me.txtcorrectanswer.TabIndex = 11
        '
        'btncamcel
        '
        Me.btncamcel.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btncamcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncamcel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncamcel.Location = New System.Drawing.Point(23, 77)
        Me.btncamcel.Name = "btncamcel"
        Me.btncamcel.Size = New System.Drawing.Size(75, 23)
        Me.btncamcel.TabIndex = 12
        Me.btncamcel.Text = "Cancel"
        Me.btncamcel.UseVisualStyleBackColor = False
        '
        'lblinformation
        '
        Me.lblinformation.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblinformation.AutoSize = True
        Me.lblinformation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblinformation.ForeColor = System.Drawing.Color.Fuchsia
        Me.lblinformation.Location = New System.Drawing.Point(340, -23)
        Me.lblinformation.Name = "lblinformation"
        Me.lblinformation.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lblinformation.Size = New System.Drawing.Size(104, 16)
        Me.lblinformation.TabIndex = 0
        Me.lblinformation.Text = "all the best guys"
        '
        'lblquestion
        '
        Me.lblquestion.AutoSize = True
        Me.lblquestion.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblquestion.Location = New System.Drawing.Point(89, 48)
        Me.lblquestion.Name = "lblquestion"
        Me.lblquestion.Size = New System.Drawing.Size(49, 15)
        Me.lblquestion.TabIndex = 0
        Me.lblquestion.Text = "Label4"
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.BackColor = System.Drawing.Color.MistyRose
        Me.rb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb1.Location = New System.Drawing.Point(80, 91)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(112, 19)
        Me.rb1.TabIndex = 1
        Me.rb1.TabStop = True
        Me.rb1.Text = "RadioButton1"
        Me.rb1.UseVisualStyleBackColor = False
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.BackColor = System.Drawing.Color.MistyRose
        Me.rb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb2.Location = New System.Drawing.Point(80, 114)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(112, 19)
        Me.rb2.TabIndex = 2
        Me.rb2.TabStop = True
        Me.rb2.Text = "RadioButton2"
        Me.rb2.UseVisualStyleBackColor = False
        '
        'rb3
        '
        Me.rb3.AutoSize = True
        Me.rb3.BackColor = System.Drawing.Color.MistyRose
        Me.rb3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb3.Location = New System.Drawing.Point(80, 141)
        Me.rb3.Name = "rb3"
        Me.rb3.Size = New System.Drawing.Size(112, 19)
        Me.rb3.TabIndex = 3
        Me.rb3.TabStop = True
        Me.rb3.Text = "RadioButton3"
        Me.rb3.UseVisualStyleBackColor = False
        '
        'rb4
        '
        Me.rb4.AutoSize = True
        Me.rb4.BackColor = System.Drawing.Color.MistyRose
        Me.rb4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb4.Location = New System.Drawing.Point(80, 175)
        Me.rb4.Name = "rb4"
        Me.rb4.Size = New System.Drawing.Size(112, 19)
        Me.rb4.TabIndex = 4
        Me.rb4.TabStop = True
        Me.rb4.Text = "RadioButton4"
        Me.rb4.UseVisualStyleBackColor = False
        '
        'txtfillanswer
        '
        Me.txtfillanswer.Location = New System.Drawing.Point(301, 113)
        Me.txtfillanswer.Multiline = True
        Me.txtfillanswer.Name = "txtfillanswer"
        Me.txtfillanswer.Size = New System.Drawing.Size(311, 45)
        Me.txtfillanswer.TabIndex = 5
        '
        'panmcq
        '
        Me.panmcq.BackColor = System.Drawing.Color.DarkGray
        Me.panmcq.Controls.Add(Me.lblquestiontype)
        Me.panmcq.Controls.Add(Me.lblquestionid)
        Me.panmcq.Controls.Add(Me.Label4)
        Me.panmcq.Controls.Add(Me.txtfillanswer)
        Me.panmcq.Controls.Add(Me.rb4)
        Me.panmcq.Controls.Add(Me.rb3)
        Me.panmcq.Controls.Add(Me.rb2)
        Me.panmcq.Controls.Add(Me.rb1)
        Me.panmcq.Controls.Add(Me.lblquestion)
        Me.panmcq.Location = New System.Drawing.Point(7, 239)
        Me.panmcq.Name = "panmcq"
        Me.panmcq.Size = New System.Drawing.Size(965, 207)
        Me.panmcq.TabIndex = 2
        '
        'lblquestiontype
        '
        Me.lblquestiontype.AutoSize = True
        Me.lblquestiontype.Location = New System.Drawing.Point(20, 70)
        Me.lblquestiontype.Name = "lblquestiontype"
        Me.lblquestiontype.Size = New System.Drawing.Size(39, 13)
        Me.lblquestiontype.TabIndex = 15
        Me.lblquestiontype.Text = "Label7"
        '
        'lblquestionid
        '
        Me.lblquestionid.AutoSize = True
        Me.lblquestionid.Location = New System.Drawing.Point(35, 48)
        Me.lblquestionid.Name = "lblquestionid"
        Me.lblquestionid.Size = New System.Drawing.Size(39, 13)
        Me.lblquestionid.TabIndex = 14
        Me.lblquestionid.Text = "Label4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(9, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(161, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Solve the Question"
        '
        'Panpractcontrol
        '
        Me.Panpractcontrol.BackColor = System.Drawing.Color.MistyRose
        Me.Panpractcontrol.Controls.Add(Me.btnfirst)
        Me.Panpractcontrol.Controls.Add(Me.btnprevious)
        Me.Panpractcontrol.Controls.Add(Me.txtcorrectanswer)
        Me.Panpractcontrol.Controls.Add(Me.btncamcel)
        Me.Panpractcontrol.Controls.Add(Me.Button2)
        Me.Panpractcontrol.Controls.Add(Me.btnnext)
        Me.Panpractcontrol.Controls.Add(Me.btnlast)
        Me.Panpractcontrol.Controls.Add(Me.Button1)
        Me.Panpractcontrol.Location = New System.Drawing.Point(7, 464)
        Me.Panpractcontrol.Name = "Panpractcontrol"
        Me.Panpractcontrol.Size = New System.Drawing.Size(963, 108)
        Me.Panpractcontrol.TabIndex = 14
        '
        'btntest
        '
        Me.btntest.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btntest.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntest.Location = New System.Drawing.Point(22, 2)
        Me.btntest.Name = "btntest"
        Me.btntest.Size = New System.Drawing.Size(113, 31)
        Me.btntest.TabIndex = 3
        Me.btntest.Text = " Give the Test"
        Me.btntest.UseVisualStyleBackColor = False
        '
        'Panexamcontrol
        '
        Me.Panexamcontrol.BackColor = System.Drawing.Color.MistyRose
        Me.Panexamcontrol.Controls.Add(Me.btnresult)
        Me.Panexamcontrol.Controls.Add(Me.lblanswer)
        Me.Panexamcontrol.Controls.Add(Me.btnsubmmit)
        Me.Panexamcontrol.Controls.Add(Me.btnpexamrevious)
        Me.Panexamcontrol.Controls.Add(Me.btncancel1)
        Me.Panexamcontrol.Controls.Add(Me.btnexamnext)
        Me.Panexamcontrol.Location = New System.Drawing.Point(7, 588)
        Me.Panexamcontrol.Name = "Panexamcontrol"
        Me.Panexamcontrol.Size = New System.Drawing.Size(963, 68)
        Me.Panexamcontrol.TabIndex = 15
        '
        'btnresult
        '
        Me.btnresult.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnresult.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnresult.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnresult.Location = New System.Drawing.Point(798, 37)
        Me.btnresult.Name = "btnresult"
        Me.btnresult.Size = New System.Drawing.Size(141, 23)
        Me.btnresult.TabIndex = 15
        Me.btnresult.Text = "show the  reusult"
        Me.btnresult.UseVisualStyleBackColor = False
        '
        'lblanswer
        '
        Me.lblanswer.AutoSize = True
        Me.lblanswer.Location = New System.Drawing.Point(900, 0)
        Me.lblanswer.Name = "lblanswer"
        Me.lblanswer.Size = New System.Drawing.Size(39, 13)
        Me.lblanswer.TabIndex = 14
        Me.lblanswer.Text = "Label7"
        '
        'btnsubmmit
        '
        Me.btnsubmmit.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnsubmmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsubmmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubmmit.Location = New System.Drawing.Point(534, 22)
        Me.btnsubmmit.Name = "btnsubmmit"
        Me.btnsubmmit.Size = New System.Drawing.Size(75, 23)
        Me.btnsubmmit.TabIndex = 13
        Me.btnsubmmit.Text = "Submit"
        Me.btnsubmmit.UseVisualStyleBackColor = False
        '
        'btnpexamrevious
        '
        Me.btnpexamrevious.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnpexamrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpexamrevious.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpexamrevious.Location = New System.Drawing.Point(137, 22)
        Me.btnpexamrevious.Name = "btnpexamrevious"
        Me.btnpexamrevious.Size = New System.Drawing.Size(75, 23)
        Me.btnpexamrevious.TabIndex = 6
        Me.btnpexamrevious.Text = "<"
        Me.btnpexamrevious.UseVisualStyleBackColor = False
        '
        'btncancel1
        '
        Me.btncancel1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btncancel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncancel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel1.Location = New System.Drawing.Point(671, 37)
        Me.btncancel1.Name = "btncancel1"
        Me.btncancel1.Size = New System.Drawing.Size(75, 23)
        Me.btncancel1.TabIndex = 12
        Me.btncancel1.Text = "Cancel"
        Me.btncancel1.UseVisualStyleBackColor = False
        '
        'btnexamnext
        '
        Me.btnexamnext.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnexamnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnexamnext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexamnext.Location = New System.Drawing.Point(301, 22)
        Me.btnexamnext.Name = "btnexamnext"
        Me.btnexamnext.Size = New System.Drawing.Size(75, 23)
        Me.btnexamnext.TabIndex = 7
        Me.btnexamnext.Text = ">"
        Me.btnexamnext.UseVisualStyleBackColor = False
        '
        'practical
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(982, 683)
        Me.Controls.Add(Me.Panexamcontrol)
        Me.Controls.Add(Me.Panpractcontrol)
        Me.Controls.Add(Me.panpassword)
        Me.Controls.Add(Me.btntest)
        Me.Controls.Add(Me.lblinformation)
        Me.Controls.Add(Me.panmcq)
        Me.Controls.Add(Me.panselect)
        Me.Controls.Add(Me.panchecked)
        Me.Name = "practical"
        Me.Text = "practical"
        Me.panchecked.ResumeLayout(False)
        Me.panchecked.PerformLayout()
        Me.panselect.ResumeLayout(False)
        Me.panselect.PerformLayout()
        Me.panpassword.ResumeLayout(False)
        Me.panpassword.PerformLayout()
        Me.panmcq.ResumeLayout(False)
        Me.panmcq.PerformLayout()
        Me.Panpractcontrol.ResumeLayout(False)
        Me.Panpractcontrol.PerformLayout()
        Me.Panexamcontrol.ResumeLayout(False)
        Me.Panexamcontrol.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents panchecked As System.Windows.Forms.Panel
    Friend WithEvents rbtruefalse As System.Windows.Forms.RadioButton
    Friend WithEvents rbfbq As System.Windows.Forms.RadioButton
    Friend WithEvents rbmcq As System.Windows.Forms.RadioButton
    Friend WithEvents panselect As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbcexamname As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbquestioncat As System.Windows.Forms.ComboBox
    Friend WithEvents cmbbook As System.Windows.Forms.ComboBox
    Friend WithEvents btnlast As System.Windows.Forms.Button
    Friend WithEvents btnnext As System.Windows.Forms.Button
    Friend WithEvents btnprevious As System.Windows.Forms.Button
    Friend WithEvents btnfirst As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnstart As System.Windows.Forms.Button
    Friend WithEvents txtcorrectanswer As System.Windows.Forms.TextBox
    Friend WithEvents btncamcel As System.Windows.Forms.Button
    Friend WithEvents lblinformation As System.Windows.Forms.Label
    Friend WithEvents lblquestion As System.Windows.Forms.Label
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb4 As System.Windows.Forms.RadioButton
    Friend WithEvents txtfillanswer As System.Windows.Forms.TextBox
    Friend WithEvents panmcq As System.Windows.Forms.Panel
    Friend WithEvents lblinstruct As System.Windows.Forms.Label
    Friend WithEvents lblinstruct2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btntest As System.Windows.Forms.Button
    Friend WithEvents panpassword As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
    Friend WithEvents txtusername As System.Windows.Forms.TextBox
    Friend WithEvents btnlogin As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnstartexam As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Panpractcontrol As System.Windows.Forms.Panel
    Friend WithEvents Panexamcontrol As System.Windows.Forms.Panel
    Friend WithEvents btnpexamrevious As System.Windows.Forms.Button
    Friend WithEvents btncancel1 As System.Windows.Forms.Button
    Friend WithEvents btnexamnext As System.Windows.Forms.Button
    Friend WithEvents cmblavel As System.Windows.Forms.ComboBox
    Friend WithEvents btnsubmmit As System.Windows.Forms.Button
    Friend WithEvents lblanswer As System.Windows.Forms.Label
    Friend WithEvents btnresult As System.Windows.Forms.Button
    Friend WithEvents lblquestionid As System.Windows.Forms.Label
    Friend WithEvents lbllevel As System.Windows.Forms.Label
    Friend WithEvents lblcoosequestiontype As System.Windows.Forms.Label
    Friend WithEvents lblquestiontype As System.Windows.Forms.Label
End Class
