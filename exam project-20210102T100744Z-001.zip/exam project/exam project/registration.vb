﻿Imports System.Data.OleDb
Imports System.Text.RegularExpressions
Public Class registration
    Dim da As New OleDbDataAdapter("select *from studentregi", con)
    Dim distid As Integer
    Dim talukaid As Integer

    Private Sub registration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds, "studentregi")
            cmb = New OleDbCommandBuilder(da)
            n = ds.Tables("studentregi").Rows.Count - 1
            Call regi(n)


            btnsave.Enabled = False


            If con.State = ConnectionState.Closed Then   'add dist in cmb dist
                con.Open()
            End If
            Dim distcm As New OleDbCommand("select distname from dist", con)
            Dim distdr As OleDbDataReader
            distdr = distcm.ExecuteReader

            While distdr.Read
                cmbdist.Items.Add(distdr.Item(0))

            End While
            distdr.Close()
            distcm.Cancel()
            con.Close() 'connection close
           
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try






       
    End Sub


   


    Private Sub regi(ByVal r1 As Byte)
        Try

            With ds.Tables("studentregi").Rows(r1)
                txtregisterno.Text = .Item(0)
                txtfirst.Text = .Item(1)
                txtsecond.Text = .Item(2)
                txtlast.Text = .Item(3)
                cmbexamid.Text = .Item(4)
                dtpdob.Text = .Item(5)
                cmbdist.Text = .Item(6)
                cmbtaluka.Text = .Item(7)


                txtvillage.Text = .Item(8)
                txtphoneno.Text = .Item(9)
                txtemailid.Text = .Item(10)
            End With
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

     
            If con.State = ConnectionState.Closed Then  'automatic generet number
                con.Open()  'connection open
            End If

            Dim regicm3 As New OleDbCommand("select *from studentregi", con)
            Dim regidr3 As OleDbDataReader
            regidr3 = regicm3.ExecuteReader
            While regidr3.Read
                txtregisterno.Text = regidr3.Item(0) + 1

            End While
            con.Close() 'connection close

            txtregisterno.Enabled = False
            txtfirst.Clear()
            txtsecond.Clear()
            txtlast.Clear()
            cmbexamid.Text = ""
            cmbdist.Text = ""
            cmbtaluka.Text = ""
            txtvillage.Clear()
            txtphoneno.Clear()
            txtemailid.Clear()

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
      
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

    

            Dim r As DataRow
            r = ds.Tables("studentregi").NewRow
            r.Item(0) = txtregisterno.Text
            r.Item(1) = txtfirst.Text
            r.Item(2) = txtsecond.Text
            r.Item(3) = txtlast.Text
            r.Item(4) = cmbexamid.Text
            r.Item(5) = dtpdob.Value
            r.Item(6) = distid
            r.Item(7) = talukaid
            r.Item(8) = txtvillage.Text
            r.Item(9) = txtphoneno.Text
            r.Item(10) = txtemailid.Text
            ds.Tables("studentregi").Rows.Add(r)
            da.Update(ds, "studentregi")
            MsgBox("record save")

        Catch ex As IndexOutOfRangeException
            MsgBox("ok")
        Catch ex As ConstraintException
            MsgBox("not allowed dublicate value this id allredy present")

        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try

            Dim t As Short
            t = MsgBox("are you sure", MsgBoxStyle.OkCancel + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Critical, "configure")
            If t = 1 Then
                ds.Tables("studentregi").Rows(n).Delete()
                da.Update(ds, "studentregi")
                MsgBox("record delete")
                Call regi(n - 1)
            Else
                MsgBox("ok")
                Call regi(n)

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        txtregisterno.Enabled = False

        Try

    
            ds.Tables("studentregi").Rows(n).Item(1) = txtfirst.Text
            ds.Tables("studentregi").Rows(n).Item(2) = txtemailid.Text
            ds.Tables("studentregi").Rows(n).Item(3) = txtlast.Text
            ds.Tables("studentregi").Rows(n).Item(4) = cmbexamid.Text
            ds.Tables("studentregi").Rows(n).Item(5) = dtpdob.Value
            ds.Tables("studentregi").Rows(n).Item(6) = distid
            ds.Tables("studentregi").Rows(n).Item(7) = talukaid
            ds.Tables("studentregi").Rows(n).Item(8) = txtvillage.Text
            ds.Tables("studentregi").Rows(n).Item(9) = txtphoneno.Text
            ds.Tables("studentregi").Rows(n).Item(10) = txtemailid.Text
            da.Update(ds, "studentregi")
            MsgBox("record updated")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click


        Try

      
            Dim e3 As Integer
            e3 = InputBox("enetr the registeno")
            Dim r As DataRow
            r = ds.Tables("studentregi").Rows.Find(e3)
            If r Is Nothing Then
                MsgBox("record not found")
            Else
                txtregisterno.Text = r.Item(0)
                txtfirst.Text = r.Item(1)
                txtemailid.Text = r.Item(2)
                txtlast.Text = r.Item(3)
                cmbexamid.Text = r.Item(4)
                dtpdob.Value = r.Item(5)
                cmbdist.Text = r.Item(6)
                cmbtaluka.Text = r.Item(7)
                txtvillage.Text = r.Item(8)
                txtphoneno.Text = r.Item(9)
                txtemailid.Text = r.Item(10)

            End If
        Catch ex As InvalidCastException
            MsgBox("enter only number")

        Catch ex1 As OverflowException
            MsgBox("sorry your no is high")

        Catch ex1 As RowNotInTableException
            MsgBox("row is not presented")

        Catch ex4 As Exception
            MsgBox(Convert.ToString(ex4))



        End Try
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        Try

    
            If n < ds.Tables("studentregi").Rows.Count - 1 Then
                n = n + 1
                Call regi(n)

            End If
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try
    End Sub

    Private Sub btnfirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfirst.Click
        n = 0
        Call regi(n)
        MsgBox("first record")

    End Sub

    Private Sub btnlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlast.Click
        Try

     
            n = ds.Tables("studentregi").Rows.Count - 1
            Call regi(n)
            MsgBox("last record")
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try

    End Sub

    Private Sub txtemailid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtemailid.KeyPress
     
    End Sub

    Private Sub txtemailid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtemailid.TextChanged
       





    End Sub

    Private Sub btnprevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevious.Click

    End Sub

    Private Sub cmbdist_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdist.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

    Private Sub cmbdist_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdist.SelectedIndexChanged
        Try

       
            cmbtaluka.Items.Clear()

            If con.State = ConnectionState.Closed Then   'add dist in cmb dist
                con.Open()
            End If
            Dim distcm2 As New OleDbCommand("select distid from dist where distname like '" & Trim(cmbdist.Text) & "'", con)
            Dim distdr2 As OleDbDataReader
            distdr2 = distcm2.ExecuteReader
            While distdr2.Read
                distid = distdr2.Item(0)


            End While
            con.Close()

            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim talukacm As New OleDbCommand("select talukaname from taluka where distid=" & distid, con)
            Dim talukadr As OleDbDataReader
            talukadr = talukacm.ExecuteReader
            While talukadr.Read
                cmbtaluka.Items.Add(talukadr.Item(0))

            End While
            con.Close()
        Catch ex As Exception
            MsgBox(Convert.ToString(ex))
        End Try


    End Sub

    Private Sub txtphoneno_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtphoneno.KeyPress

        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter number")

        End If
    End Sub

    Private Sub txtphoneno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtphoneno.TextChanged

    End Sub

    Private Sub txtphoneno_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtphoneno.Validating
        If Trim(txtphoneno.Text) = "" Then
            e.Cancel = True
            MsgBox("plese enter phone no")

        End If
    End Sub

    Private Sub cmbtaluka_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtaluka.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

  
    Private Sub cmbtaluka_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbtaluka.SelectedIndexChanged
   

        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim talukacm2 As New OleDbCommand("select talukaid from taluka where talukaname like '" & cmbtaluka.Text & "'", con)
        Dim talukadr2 As OleDbDataReader
        talukadr2 = talukacm2.ExecuteReader
        While talukadr2.Read
            talukaid = talukadr2.Item(0)

        End While
        con.Close()
       
    End Sub

    Private Sub txtfirst_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtfirst.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")

        End If
    End Sub

    Private Sub txtfirst_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtfirst.TextChanged

    End Sub

    Private Sub btnsave_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsave.Disposed
     
    End Sub

    Private Sub txtemailid_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtemailid.Validated
       

    End Sub
   

 

    Private Sub btnsearch_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsearch.Validated
        If txtemailid.Text.Length = 0 Then
            MsgBox("E-mail address is required.")


        End If

        ' Confirm that there is an "@" and a "." in the e-mail address, and in the correct order.

        Dim errorMessage As String

        errorMessage = "E-mail address must be valid e-mail address format." + ControlChars.Cr + _
          "For example 'someone@example.com' "


    End Sub

    Private Sub txtregisterno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtregisterno.TextChanged

    End Sub

    Private Sub txtsecond_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsecond.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")

        End If
    End Sub

    Private Sub txtsecond_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsecond.TextChanged

    End Sub

    Private Sub txtlast_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtlast.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")

        End If
    End Sub

    Private Sub txtlast_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtlast.TextChanged

    End Sub

    Private Sub txtvillage_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtvillage.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("only enter character")

        End If
    End Sub

    Private Sub txtvillage_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtvillage.TextChanged

    End Sub

    Private Sub cmbexamid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbexamid.KeyPress
        If (Asc(e.KeyChar)) = 8 Then
            Exit Sub
        End If
        If Char.IsLetter(e.KeyChar) = True And Char.IsDigit(e.KeyChar) = True Then
            e.Handled = True
            MsgBox("donot enter plese only select")

        End If
    End Sub

    Private Sub cmbexamid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbexamid.SelectedIndexChanged

    End Sub
End Class