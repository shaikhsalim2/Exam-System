﻿Imports System.Data.OleDb

Public Class frmuseradd
    Dim da As New OleDbDataAdapter("select *from login", con)

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub frmlogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        da.MissingSchemaAction = MissingSchemaAction.AddWithKey
        da.Fill(ds, "login")
        cmb = New OleDbCommandBuilder(da)
        n = ds.Tables("login").Rows.Count - 1
        Call login(n)
        btnadd.Enabled = False


    End Sub
    Private Sub login(ByVal u1 As Integer)
        With ds.Tables("login").Rows(u1)
            txtusername.Text = .Item(0)
            txtpassword.Text = .Item(1)

        End With
    End Sub



    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        txtusername.Clear()
        txtpassword.Clear()

    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim r As DataRow
        r = ds.Tables("login").NewRow
        r.Item(0) = txtusername.Text
        r.Item(1) = txtpassword.Text
        ds.Tables("login").Rows.Add(r)
        da.Update(ds, "login")
        MsgBox("record save")
    End Sub

    Private Sub txtpassword_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpassword.KeyPress
        btnadd.Enabled = True
    End Sub

    Private Sub txtpassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpassword.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub
End Class